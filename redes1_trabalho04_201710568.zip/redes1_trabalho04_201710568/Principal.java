import controlador.Controlador;
import camadas.*;
import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/*********************************************
Nome: Tharcio Thalles Almeida Silva
Data de inicio: 01 04 2019
data de termino: 13 04 2019
objetivo: simular as janelas delizantes
********************************************/

public class Principal extends Application{

	public static Scene aplicacao;

  @Override
  public void start(Stage primaryStage) throws IOException {
    Parent fxmlAplicacao = FXMLLoader.load(getClass().getResource("/tela/Aplicacao.fxml"));
    aplicacao = new Scene(fxmlAplicacao);
    primaryStage.setScene(aplicacao);
    primaryStage.show();
  }//Fim metodo start

  public static void main(String args[]){
    launch(args);
  }//Fim main

}//Fim classe Principal