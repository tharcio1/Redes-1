package camadas;

import static camadas.CamadaEnlaceDadosTransmissora.verificaAck;
import static camadas.CamadaEnlaceDadosTransmissora.stopAndWait;
public class Timer extends Thread{
	int contador = 0;
	public void run(){
		try{
			sleep(1000);
		}catch(InterruptedException e){
			e.printStackTrace();
		}
		//if(verificaAck = false){
			stopAndWait.release();
		//}//fim if
	}//fim run
}//fim classe Timer