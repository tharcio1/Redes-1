package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
// import static controlador.Controlador.tipoDeDecodificacao;

public class CamadaDeAplicacaoReceptora{

  AplicacaoReceptora aplicacaoReceptora = new AplicacaoReceptora();
  //AplicacaoTransmissora aplicacaoTrans  = new AplicacaoTransmissora();
  MetodosBit manipulador = new MetodosBit();
  Controlador control;

  public void camadaAplicacaoReceptora(int quadro[]){
    int n = 0;
    int c = 0;
    int j = 0;
    
    String mensagem = "";
    String mensagemf = "";
    int inteiro = 0;

    while(n < quadro.length * 4){
      inteiro = manipulador.retornaPrimeiroByte(quadro[j]);
      if(inteiro != 0){
        quadro[j] <<= 8;
        mensagem += (char) inteiro;
        n++;
        if(n != 0 && n % 4 == 0){
          if(j < quadro.length - 1){
            j++;
          }//Fim if
        }//Fim if
      }//Fim if
      else{
        quadro[j] <<= 8;
        n++;
        if(n != 0 && n % 4 == 0){
          if(j < quadro.length - 1){
            j++;
          }//Fim if
        }//Fim if
      }//Fim else
    }//Fim while
    System.out.println("mensagem: " + mensagem);
    aplicacaoReceptora.aplicacaoReceptora(mensagem);      
  }//Fim metodo camadaAplicacaoReceptora

  public void setControlador(Controlador controlador){
    control = controlador;
  }//Fim metodo setControlador

}//Fim classe CamadaDeAplicacaoReceptora