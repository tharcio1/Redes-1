package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static camadas.CamadaDeAplicacaoTransmissora.enlaceTransmissora;

public class AplicacaoTransmissora{
  public static Controlador control;
  static CamadaDeAplicacaoTransmissora camadaTransmissora = new CamadaDeAplicacaoTransmissora();

  public void aplicacaoTransmissora(String mensagem){
    enlaceTransmissora.contaErros = 0;
    camadaTransmissora.camadaAplicacaoTransmissora(mensagem);
  } //Fim metodo AplicacaoTransmissora

  public void setControlador(Controlador controlador){
    control = controlador;
  }//Fim metodo setControlador

}//Fim classe AplicacaoTransmissora