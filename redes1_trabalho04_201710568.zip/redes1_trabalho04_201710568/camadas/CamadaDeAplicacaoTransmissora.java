package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static controlador.Controlador.tipoDeDecodificacao;
import static camadas.CamadaFisicaReceptora.enlaceReceptora;

public class CamadaDeAplicacaoTransmissora{
  // CamadaFisicaTransmissora camadaFisica = new CamadaFisicaTransmissora();
  static CamadaEnlaceDadosTransmissora enlaceTransmissora = new CamadaEnlaceDadosTransmissora();
  MetodosBit manipulador = new MetodosBit();

  public void camadaAplicacaoTransmissora(String mensagem,String host){
    int[] quadro;
    int vetor[] = new int[mensagem.length()];

    for(int i = 0; i < mensagem.length(); i++){
      vetor[i] = mensagem.charAt(i);
    }//Fim for

    quadro = manipulador.inteiroEmBits(vetor);

    if(host == "host1"){
      enlaceTransmissora.CamadaEnlaceDadosTransmissora(quadro);
    }else if(host == "host2"){
      enlaceReceptora.CamadaEnlaceDadosTransmissora(quadro);
    }//fim else if
    
  }//Fim metodo CamadaDeAplicacaoTransmissora

}//Fim classe CamadaDeAplicacaoTransmissora