package camadas;
import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static camadas.AplicacaoTransmissora.control;
import static camadas.CamadaDeAplicacaoTransmissora.enlaceTransmissora;
import static camadas.CamadaFisicaReceptora.enlaceReceptora;
import static camadas.CamadaEnlaceDadosReceptora.camadaApliReceptora;

public class CamadaEnlaceDadosTransmissora{
  // Controlador control;
  static CamadaFisicaTransmissora camadaFisTransmissora = new CamadaFisicaTransmissora();
  MetodosBit manipulador = new MetodosBit();
  int tipoDeEnquadramento = 0;
  int tipoDeControleDeErro = control.tipoControleDeErro; //alterar de acordo com o teste
  static boolean host1Enviando = false;
  static boolean verificaAck = false;
  static Semaphore stopAndWait = new Semaphore(0);
  static int contaErros = 0;
  LblImg retransmitindoLblImg = new LblImg();

  public CamadaEnlaceDadosTransmissora(){
  
  }//Fim metodo construtor
  
  public void CamadaEnlaceDadosTransmissora(int quadro[]){
    int quadroEnquadrado [];

    quadroEnquadrado = CamadaEnlaceDadosTransmissoraEnquadramento(quadro); 
    quadroEnquadrado = camadaEnlaceDadosTransmissoraControleDeErro(quadroEnquadrado);
    camadaDeEnlaceDadosTransmissoraControleDeFluxo(quadroEnquadrado);

    //camadaFisTransmissora.CamadaFisicaTransmissora(quadroEnquadrado);
  }//fim metodo CamadaEnlanceDadosTransmissora

  public void enviarAck(){
    int ack[] = new int[1];
    //envia ack falando que quadro chegou correto
    host1Enviando = true;
    enlaceReceptora.host2Enviando = false;
    //envia nak
    ack[0] = manipulador.devolveAck();
    camadaFisTransmissora.binariaDireta(ack);
  }  

  public void enviarNak(){
    int nak[] = new int[1];
    //envia nak falando que quadro chegou com erro
    host1Enviando = true;
    enlaceReceptora.host2Enviando = false;
    //envia nak
    nak[0] = manipulador.devolveNAK();
    camadaFisTransmissora.binariaDireta(nak);
  }

  public void camadaDeEnlaceDadosTransmissoraControleDeFluxo(int quadro []) {
    int tipoDeControleDeFluxo = 3; //alterar de acordo com o teste
    switch (tipoDeControleDeFluxo) {
      case 0 : //protocolo simplex sem restricoes
      //codigo
      break;
      case 1 : //protocolo simplex stop-and-wait
      //codigo
      break;
      case 2 : //protocolo simplex para um canal com ruído
      //codigo
      
      case 3 : //protocolo de janela deslizante de 1 bit
        //codigo
        camadaEnlaceDadosTransmissoraJanelaDeslizanteUmBit(quadro);
      break;
      case 4 : //protocolo de janela deslizante go-back-n
      //codigo
      break;
      case 5 : //protocolo de janela deslizante com retransmissão seletiva
      //codigo
      break;
    }//fim do switch/case
  }//fim do metodo CamadaEnlaceDadosTransmissoraControleDeFluxo


  public void camadaEnlaceDadosTransmissoraSimplexSemRestricoes (int quadro []) {
    //implementacao do algoritmo
  }//fim do metodo CamadaEnlaceDadosTransmissoraSimplexSemRestricoes
  public void camadaEnlaceDadosTransmissoraSimplexStopAndWait (int quadro []) {
    //implementacao do algoritmo
  }//fim do metodo CamadaEnlaceDadosTransmissoraSimplexStopAndWait
  public void camadaEnlaceDadosTransmissoraSimplexCanalComRuido (int quadro []) {
    //implementacao do algoritmo
  }//fim do metodo CamadaEnlaceDadosTransmissoraSimplexCanalComRuido
  public void camadaEnlaceDadosTransmissoraJanelaDeslizanteUmBit (int quadro []){
    //implementacao do algoritmo
    //timer comeca a contar, timer termina, se a variavel controleReenvio tiver false eh pq nao recebeu o quadro ou deu falha na soma de verificacao
    //entao reenvia, se tiver true eh pq estava tudo ok, entao envia o proximo quadro
    int tamQuadro = quadro.length;
    int quadroNumeroN[] = new int[1];
    int numIndice = 0;
    while(tamQuadro > 0){
      //instancia o timer
      Timer tempo = new Timer("host1");
      //envia quadro pro receptor
      quadroNumeroN[0] = quadro[numIndice];
      int tempkkk = quadroNumeroN[0];
      enlaceReceptora.host2Enviando = false;
      host1Enviando = true;
      camadaFisTransmissora.CamadaFisicaTransmissora(quadroNumeroN);
      //chamada do metodo ativa timer
      tempo.start();
      // da um acquire 
      try{
        stopAndWait.acquire();
      }catch(InterruptedException e){
        e.printStackTrace();
      }
      //timer termina ou ack chega
      if(verificaAck == true){
        numIndice++;
        tamQuadro--;
        verificaAck = false;
      }//fim if
      else{
        if(contaErros == 0){
          LblImg ativar = new LblImg();
          ativar.start();
        }//fim if
        contaErros++;
      }
      //verifica se a variavel verificaAck eh false, se for reenvia e nao diminui tamQuadro, se for true envia o proximo quadro e diminui tamQuadro
    }//fim while
    //envia um indice do quadro, ativa timer espera confirmação, nao chegou ? reenvia o quadro
    //vai no quadro o que ja ta adicionando, o nº do quadro que esta sendo enviado, e a confirmacao do quadro do host2
  }//fim do metodo CamadaEnlaceDadosTransmissoraJanelaDeslizanteUmBit
  public void camadaEnlaceDadosTransmissoraJanelaDeslizanteGoBackN (int quadro []) {
    //implementacao do algoritmo
  }//fim do metodo CamadaEnlaceDadosTransmissoraJanelaDeslizanteGoBackN
  public void camadaEnlaceDadosTransmissoraJanelaDeslizanteComRetransmissaoSeletiva (int
  quadro []) {
    //implementacao do algoritmo
  }//fim do CamadaEnlaceDadosTransmissoraJanelaDeslizanteComRetransmissaoSeletiva

  public void verificaAckOuCGU(int quadro[]){
    if(quadro.length == 1){
      //reativa transmissor pra enviar o prox quadro
      int ack = manipulador.devolveAck();
      int quadroAck = manipulador.retornaPrimeiroByte(ack);

      int nak = manipulador.devolveNAK();
      int quadroNak = manipulador.retornaPrimeiroByte(nak);

      int quadroRecebido = manipulador.retornaPrimeiroByte(quadro[0]);

      if(quadroRecebido == quadroAck){
        verificaAck = true;
        //reativa transmissor
        //enlaceTranmissora.stopAndWait.release();
      }//fim if
      else if(quadroRecebido == quadroNak){
        verificaAck = false;
      }//fim else
      else{
        //carga util
        host1Enviando = true;
        enlaceReceptora.host2Enviando = false;
        CamadaEnlaceDadosReceptora(quadro);
        //envia ack
        /*ack[0] = manipulador.devolveAck();
        camadaFisTransmissora.binariaDireta(ack);*/
      }//fim else
    }//fim if
    else{
      //mensagem do host2

      //envia ack falando que quadro chegou
      //carga util
      enlaceReceptora.host2Enviando = false;
      host1Enviando = true;
      CamadaEnlaceDadosReceptora(quadro);
      //envia ack
      /*ack[0] = manipulador.devolveAck();
      camadaFisTransmissora.binariaDireta(ack);*/

    }//fim else

  }//fim metodo verificaAckOuCGU

  public int[] CamadaEnlaceDadosTransmissoraEnquadramento(int quadro[]){
    tipoDeEnquadramento = control.tipoDeEnquadramento; //alterar de acordo com o teste
    int quadroEnquadrado [];
    int temp[] = new int[2];
    switch (tipoDeEnquadramento) {
      case 0 : //contagem de caracteres
        quadroEnquadrado = CamadaDeEnlaceDadosTransmissoraEnquadramentoContagemDeCaracteres(quadro);
        return quadroEnquadrado;
      case 1 : //insercao de bytes
        quadroEnquadrado = CamadaDeEnlaceDadosTransmissoraEnquadramentoInsercaoDeBytes(quadro);
        return quadroEnquadrado;
      case 2 : //insercao de bits
        quadroEnquadrado = CamadaDeEnlaceDadosTransmissoraEnquadramentoInsercaoDeBits(quadro);
        return quadroEnquadrado;
      case 3 : //violacao da camada fisica
        quadroEnquadrado = CamadaDeEnlaceDadosTransmissoraEnquadramentoViolacaoDaCamadaFisica(quadro);
        return quadroEnquadrado;
    }//fim do switch/case
    return temp;
  }//fim do metodo CamadaEnlaceTransmissoraEnquadramento


  public int[] camadaEnlaceDadosTransmissoraControleDeErro (int quadro []) {
    int quadroNovo [];
    switch (tipoDeControleDeErro){
      case 0 : //bit de paridade par
        quadroNovo = camadaEnlaceDadosTransmissoraControleDeErroBitParidadePar(quadro);
        return quadroNovo;
      case 1 : //bit de paridade impar
        quadroNovo = camadaEnlaceDadosTransmissoraControleDeErroBitParidadeImpar(quadro);
        return quadroNovo;
      case 2 : //CRC
        quadroNovo = camadaEnlaceDadosTransmissoraControleDeErroCRC(quadro);
        return quadroNovo;
      case 3 : //codigo de Hamming
        return quadro;
    }//fim do switch/case
    return quadro;
  }//fim do metodo camadaEnlaceDadosTransmissoraControleDeErro

  public int[] camadaEnlaceDadosTransmissoraControleDeErroCRC(int quadro []){
    int quadroNovo[] = new int[quadro.length * 2];
    int crc32 = manipulador.devolveCrc(); // correspondente ao valor decimal do binario do crc32
    int resto = 0;
    int inteiro = 0;
    int bit = 0;
    boolean verif = false;
    int cont = 0;

    for(int j = 0; j < quadroNovo.length; j++){
      if(j % 2 == 0 && j != 0){
        quadroNovo[j] = quadro[cont];
        quadroNovo[j] = manipulador.moverBitsEsquerda(quadroNovo[j]);
        cont++;
      }else if(j == 0){
        quadroNovo[j] = quadro[j];
        quadroNovo[j] = manipulador.moverBitsEsquerda(quadroNovo[j]);
        cont++;
      }//Fim else if
    }//Fim for

    for(int i = 0; i < quadro.length; i++){
      resto = 0;
      crc32 = manipulador.devolveCrc(); // correspondente ao valor decimal do binario do crc32
      int contador = 0;
      inteiro = quadro[i];

      if(tipoDeEnquadramento == 0){
        inteiro <<= 16;
        inteiro = manipulador.moverBitsEsquerda(inteiro);
      }else if(tipoDeEnquadramento == 1){
        inteiro = manipulador.colocarBitNaPosicao(inteiro,0,24);
        inteiro = manipulador.colocarBitNaPosicao(inteiro,0,23);
        inteiro = manipulador.colocarBitNaPosicao(inteiro,0,22);
        inteiro = manipulador.colocarBitNaPosicao(inteiro,0,21);
        inteiro = manipulador.colocarBitNaPosicao(inteiro,0,20);
        inteiro = manipulador.colocarBitNaPosicao(inteiro,0,19);
        inteiro = manipulador.colocarBitNaPosicao(inteiro,0,18);
        inteiro = manipulador.colocarBitNaPosicao(inteiro,0,17);
        inteiro <<= 8;
        inteiro = manipulador.moverBitsEsquerda(inteiro);
      }else if(tipoDeEnquadramento == 2){
        int mask    = 1;
        int bit2    = 0;
        int bit3    = 0;
        int bitUm   = 0;
        int umBitaFrente = 0;
        int umBitaFrente2 = 0;

        inteiro = manipulador.colocarBitNaPosicao(inteiro,0,24);
        inteiro = manipulador.colocarBitNaPosicao(inteiro,0,23);
        inteiro = manipulador.colocarBitNaPosicao(inteiro,0,22);
        inteiro = manipulador.colocarBitNaPosicao(inteiro,0,21);
        inteiro = manipulador.colocarBitNaPosicao(inteiro,0,20);
        inteiro = manipulador.colocarBitNaPosicao(inteiro,0,19);
        inteiro = manipulador.colocarBitNaPosicao(inteiro,0,18);
        inteiro = manipulador.colocarBitNaPosicao(inteiro,0,17);
        inteiro <<= 8;
        // int temp = manipulador.retornaPrimeiroByte(quadro[j]);
        // manipulador.devolveBits(temp);
        if(manipulador.retornaPrimeiroByte2(inteiro) == 0){
          inteiro >>= 16;
          umBitaFrente = inteiro >> 1;
          umBitaFrente2 = umBitaFrente >> 1;
          while(true){
            bit = (inteiro & mask) == 0 ? 0 : 1;
            bit2 = (umBitaFrente & mask) == 0 ? 0 : 1;
            bit3 = (umBitaFrente2 & mask) == 0 ? 0 : 1;
            if(bit == 0 && bit2 == 0 && bit3 == 1){
              inteiro >>= 1;
              break;
            }else{
              inteiro >>= 1;
              umBitaFrente >>=1;
              umBitaFrente2>>=2;
            }//Fim else
          }//fim while
        }else{
          inteiro >>= 24;
        }//Fim else
        inteiro = manipulador.moverBitsEsquerda(inteiro);
      }else if(tipoDeEnquadramento == 3){
        int mask = 1 << 31;
        contador = 0;
        inteiro <<= 8;

        int novoInt = 0;

        while(contador < 8){
          bit = (inteiro & mask) == 0 ? 0 : 1;
          // manipulador.devolveBits(novoQuadro[indiceNvQ]);
          // System.out.println("valor bit: " + bit);
          novoInt <<= 1;
          novoInt |= bit;
          inteiro <<= 2;
          contador++;
        }//Fim while
        inteiro = novoInt;
        contador = 0;
        inteiro = manipulador.moverBitsEsquerda(inteiro);
      }//Fim else if tipo 3
      verif = false;
      if((manipulador.retornarBitNaPosicao(inteiro,0)) == 0){
        inteiro <<= 1; //comecando do primeiro bit mais redundante
        verif = true;
      }//Fim if
      contador = 0;
      while(contador < 32){
        // System.out.println("posicao 0: " + manipulador.retornarBitNaPosicao(inteiro,0));
        // System.out.println("posicao 1: " + manipulador.retornarBitNaPosicao(inteiro,1));
        // manipulador.devolveBits(inteiro);
        bit = ((manipulador.retornarBitNaPosicao(inteiro,0)) ^ (manipulador.retornarBitNaPosicao(crc32,0))) == 0 ? 0:1;
        // System.out.println("VALOR BIT: " + bit + " valores do bit: " + manipulador.retornarBitNaPosicao(inteiro,0) + " xor " + (manipulador.retornarBitNaPosicao(crc32,0)));
        resto <<= 1;
        resto |= bit;
        // System.out.println("valor do resto: ");
        // manipulador.devolveBits(resto);
        // System.out.println("valor inteiro: ");
        // manipulador.devolveBits(inteiro);
        // System.out.println("valor crcd : ");
        // manipulador.devolveBits(crc32);
        // System.out.println("valor do resto: ");
        // manipulador.devolveBits(resto);
        crc32 <<= 1;
        inteiro <<= 1;
        contador++;
        if(verif == true && contador == 31){
          bit = manipulador.retornarBitNaPosicao(crc32,0);
          resto <<= 1;
          resto |= bit;
          for(int c = 0; c < quadroNovo.length; c++){
            if(quadroNovo[c] == 0){
              quadroNovo[c] = resto;
              break;
            }//Fim if
          }//fim for c
          break;
        }//Fim if
      }//Fim while
      if(verif == false){
        for(int c = 0; c < quadroNovo.length; c++){
          if(quadroNovo[c] == 0){
            quadroNovo[c] = resto;
            break;
          }//Fim if
        }//fim for c
      }//fim if
    }//Fim for
    return quadroNovo;
  }//fim do metodo camadaEnlaceDadosTransmissoraControledeErroCRC

  public int[] camadaEnlaceDadosTransmissoraControleDeErroBitParidadePar(int quadro []){
    int bits1Areduzir = 0;
    if(tipoDeEnquadramento == 0){
      bits1Areduzir = 3;
    }else if(tipoDeEnquadramento == 1){
      bits1Areduzir = 10;
    }else if(tipoDeEnquadramento == 2){
      bits1Areduzir = 12;
    }//fim else if

    if(tipoDeEnquadramento == 3){
      int novoQuadro [] = new int[quadro.length];
      int bit =0;
      int mask = 1 << 31;
      int inteiro = 0;
      for(int j = 0; j < quadro.length; j++){ 
        int temp = 0; 
        int contador = 0;
        inteiro = quadro[j];
        inteiro <<= 8;
        while(contador < 32){
          bit = (inteiro & mask) == 0 ? 0 : 1;
          // manipulador.devolveBits(novoQuadro[indiceNvQ]);
          // System.out.println("valor bit: " + bit);
          novoQuadro[j] <<= 1;
          novoQuadro[j] = novoQuadro[j] | bit;
          inteiro <<= 2;
          contador++;
        }//Fim while
      }//fim for
      for(int i = 0; i < quadro.length; i++){
        quadro[i] = manipulador.moverBitsEsquerda(quadro[i]);
        if((manipulador.quantidadeBits1Inteiro(novoQuadro[i])) % 2 == 0){
          //insere 0 mas ja tem zero no bit posterior a mensagem logo nao precisa mexer
        }else{
          //insere 1 na posicao apos os bits da mensagem
          quadro[i] = manipulador.colocarBitNaPosicao(quadro[i],1,25);
        }//Fim else
      }//Fim for
    }else{
      for(int i = 0; i < quadro.length; i++){
        quadro[i] = manipulador.moverBitsEsquerda(quadro[i]);
        if((manipulador.quantidadeBits1Inteiro(quadro[i]) - bits1Areduzir) % 2 == 0){
          //insere 0 mas ja tem zero no bit posterior a mensagem logo nao precisa mexer
        }else{
          //insere 1 na posicao apos os bits da mensagem
          quadro[i] = manipulador.colocarBitNaPosicao(quadro[i],1,25);
        }//fim else
      }//fim for
    }//fim else
    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraControledeErroBitParidadePar

  public int[] camadaEnlaceDadosTransmissoraControleDeErroBitParidadeImpar(int quadro []){
    int bits1Areduzir = 0;
    if(tipoDeEnquadramento == 0){
      bits1Areduzir = 3;
    }else if(tipoDeEnquadramento == 1){
      bits1Areduzir = 10;
    }else if(tipoDeEnquadramento == 2){
      bits1Areduzir = 12;
    }//fim else if

    if(tipoDeEnquadramento == 3){
      int novoQuadro [] = new int[quadro.length];
      int bit =0;
      int mask = 1 << 31;
      int inteiro = 0;
      for(int j = 0; j < quadro.length; j++){ 
        int temp = 0; 
        int contador = 0;
        inteiro = quadro[j];
        inteiro <<= 8;
        while(contador < 32){
          bit = (inteiro & mask) == 0 ? 0 : 1;
          // manipulador.devolveBits(novoQuadro[indiceNvQ]);
          // System.out.println("valor bit: " + bit);
          novoQuadro[j] <<= 1;
          novoQuadro[j] = novoQuadro[j] | bit;
          inteiro <<= 2;
          contador++;
        }//Fim while
      }//fim for
      for(int i = 0; i < quadro.length; i++){
        quadro[i] = manipulador.moverBitsEsquerda(quadro[i]);
        if((manipulador.quantidadeBits1Inteiro(novoQuadro[i])) % 2 != 0){
          //insere 0 mas ja tem zero no bit posterior a mensagem logo nao precisa mexer
        }else{
          //insere 1 na posicao apos os bits da mensagem
          quadro[i] = manipulador.colocarBitNaPosicao(quadro[i],1,25);
        }//Fim else
      }//Fim for
    }else{
      for(int i = 0; i < quadro.length; i++){
        quadro[i] = manipulador.moverBitsEsquerda(quadro[i]);
        if((manipulador.quantidadeBits1Inteiro(quadro[i]) - bits1Areduzir) % 2 != 0){
          //insere 0 mas ja tem zero no bit posterior a mensagem logo nao precisa mexer
        }else{
          //insere 1 na posicao apos os bits da mensagem
          quadro[i] = manipulador.colocarBitNaPosicao(quadro[i],1,25);
        }//Fim else
      }//Fim for
    }//fim else
    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraControledeErroBitParidadeImpar


  public int[] CamadaDeEnlaceDadosTransmissoraEnquadramentoContagemDeCaracteres(int quadro []){
    int indiceNvQ = 0;
    int cont = 0;
    int cont2 = 0;
    int inteiro = 0;
    int mask = 1 << 31;
    int bit = 0;
    int novoInteiro = 0;
    int acumulador = 0;
    int qtdIndices = 0;

    int [] informacaoDeControle = new int[quadro.length];

    for(int i = 0; i < quadro.length; i++){
      informacaoDeControle[i] = (manipulador.retornaBitsSignificativos(quadro[i]))/8;
      acumulador += informacaoDeControle[i];
      // System.out.println("informacao: ");
      // System.out.println(informacaoDeControle[i]);
    }//Fim for

    // System.out.println();

    // System.out.println("valor acumulado: " + acumulador);

    /*if(acumulador > 3){
      while(acumulador > 3){
        acumulador -= 3;
        qtdIndices++;
      }//Fim while
      qtdIndices += 1;
    }else{
      qtdIndices = 1;
    }//Fim else*/

    if(acumulador > 2){
      while(acumulador > 2){
        acumulador -= 2;
        qtdIndices++;
      }//Fim while
      qtdIndices += 1;
    }else{
      qtdIndices = 1;
    }//Fim else

    int[] novoQuadro = new int[qtdIndices];

     // System.out.println("quantidade de indicies: " + qtdIndices);
     // System.out.println("valor do ultimo quadro: " + acumulador);

    // System.out.println("---------------");

    //quadro = manipulador.moverParaEsquerda(quadro);

    for(int m = 0; m < quadro.length; m++){
      quadro[m] = manipulador.moverBitsEsquerda(quadro[m]);
      // manipulador.devolveBits(quadro[m]);
    }// fim for

    // System.out.println("---------------");

    // System.out.println("");
    // System.out.println("NO ENLACE TRANSMISSOR: ");
    // System.out.println("");

    for(int j = 0; j < quadro.length; j++){
      cont = 0;
      inteiro = quadro[j];
      // manipulador.devolveBits(inteiro);
      while(cont < 32){
        bit = (inteiro & mask) == 0 ? 0 : 1;
        // manipulador.devolveBits(inteiro);
        // System.out.println("valor bit: " + bit);
        novoInteiro <<= 1;
        novoInteiro = novoInteiro | bit;
        // System.out.println("");
        // System.out.println("inteiro: " + cont);
        // manipulador.devolveBits(inteiro);
        // System.out.println("");
        // System.out.println("novoInteiro: " + cont2);
        // manipulador.devolveBits(novoInteiro);
        // System.out.println("");
        inteiro <<= 1;
        cont++;
        cont2++;
        if(cont2 % 16 == 0 && cont2 != 0){

          // System.out.println("quadro que entrou(24): " + manipulador.devolveBits(novoInteiro));

          //49 em decimal referencia 1 em ascll
          //50 em decimal referencia 2 em ascll
          //51 em decimal referencia 3 em ascll
          if(indiceNvQ == novoQuadro.length - 1){
            if(acumulador == 1){
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 49; //adicionando informacao de controle 1
              // manipulador.devolveBits(novoQuadro[indiceNvQ]);
            }else if(acumulador == 2){
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 50; //adicionando informacao de controle 2 
              // manipulador.devolveBits(novoQuadro[indiceNvQ]);
            }else if(acumulador == 3){
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 51; //adicionando informacao de controle 3
              // manipulador.devolveBits(novoQuadro[indiceNvQ]);
            }//Fim else if
          }else{
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 50; //adicionando informacao de controle 2
            // manipulador.devolveBits(novoQuadro[indiceNvQ]);
          }//Fim else

          int contador = 0;
          
          // novoInteiro = manipulador.moverParaEsquerdaInteiro(novoInteiro);
          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);

          // System.out.println("Valor do novo inteiro: ");
          // manipulador.devolveBits(novoInteiro);

          while(contador < 16){
            bit = (novoInteiro & mask) == 0 ? 0 : 1;
            // manipulador.devolveBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }//Fim while

          // System.out.println("quadro que saiu(24): " + manipulador.devolveBits(novoQuadro[indiceNvQ]));

          if(indiceNvQ < qtdIndices - 1){
            // System.out.println("ENTREI E SUBI O INDICE");
            indiceNvQ += 1;
          }else{
            // System.out.println("ultimo quadro codificado break");
            break;
          }//Fim else
          novoInteiro = 0;
          cont2 = 0;
          // System.out.println("VALOR DO CONT: " + cont);
        }//Fim if
        if(cont == 32 && j == quadro.length - 1 && novoInteiro != 0){
          // System.out.println("quadro que entrou(32): " + manipulador.devolveBits(novoInteiro));
          int contador = 0;
          if(acumulador == 1){
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 49; //adicionando informacao de controle 1
            // manipulador.devolveBits(novoQuadro[indiceNvQ]);
          }else if(acumulador == 2){
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 50; //adicionando informacao de controle 2 
            // manipulador.devolveBits(novoQuadro[indiceNvQ]);
          }else if(acumulador == 3){
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 51; //adicionando informacao de controle 3
            // manipulador.devolveBits(novoQuadro[indiceNvQ]);
          }//Fim else if
          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);
          // System.out.println("Valor do novo inteiro: ");
          // manipulador.devolveBits(novoInteiro);

          while(contador < (acumulador * 8)){
            bit = (novoInteiro & mask) == 0 ? 0 : 1;
            // manipulador.devolveBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }//Fim while
          // System.out.println("antes: ");
          // manipulador.devolveBits(novoQuadro[indiceNvQ]);
          // System.out.println("depois: ");
          if(acumulador * 8 == 8){
            novoQuadro[indiceNvQ] <<= 16;
          }else if(acumulador * 8 == 16){
            novoQuadro[indiceNvQ] <<= 8;
          }//Fim else if
          // System.out.println("quadro que saiu(32): " + manipulador.devolveBits(novoQuadro[indiceNvQ]));
          // manipulador.devolveBits(novoQuadro[indiceNvQ]);
        }//Fim if
      }//Fim while
    }//Fim for

   return novoQuadro;
  }//Fim metodo CamadaDeEnlaceDadosTransmissoraEnquadramentoContagemDeCaracteres

  public int[] CamadaDeEnlaceDadosTransmissoraEnquadramentoInsercaoDeBytes (int quadro []) {
    int indiceNvQ = 0;
    int cont = 0;
    int cont2 = 0;
    int inteiro = 0;
    int mask = 1 << 31;
    int bit = 0;
    int novoInteiro = 0;
    int acumulador = 0;
    int qtdIndices = 0;

    //se achar o byte de flag dentro da mensagem adiciona um escape
    //se achar o byte de escape dentro da mensagem adiciona outro escape
    // byte de flag = a
    // byte de escape = esc

    int [] informacaoDeControle = new int[quadro.length];

    for(int i = 0; i < quadro.length; i++){
      informacaoDeControle[i] = (manipulador.retornaBitsSignificativos(quadro[i]))/8;
      acumulador += informacaoDeControle[i];
      // System.out.println("informacao: ");
      // System.out.println(informacaoDeControle[i]);
    }//Fim for

    // System.out.println("valor acumulado: " + acumulador);

    /*if(acumulador > 2){
      while(acumulador > 2){
        acumulador -= 2;
        qtdIndices++;
      }//Fim while
      qtdIndices += 1;
    }else{
      qtdIndices = 1;
    }//Fim else*/

    qtdIndices = acumulador;

    int[] novoQuadro = new int[acumulador];

     // System.out.println("quantidade de indicies: " + qtdIndices);
     // System.out.println("valor do ultimo quadro: " + acumulador);

    // System.out.println("---------------");

    //quadro = manipulador.moverParaEsquerda(quadro);

    for(int m = 0; m < quadro.length; m++){
      quadro[m] = manipulador.moverBitsEsquerda(quadro[m]);
      // manipulador.devolveBits(quadro[m]);
    }// fim for

    // System.out.println("---------------");

    // System.out.println("");
    // System.out.println("NO ENLACE TRANSMISSOR: ");
    // System.out.println("");

    for(int j = 0; j < quadro.length; j++){
      cont = 0;
      inteiro = quadro[j];
      // manipulador.devolveBits(inteiro);
      while(cont < 32){
        bit = (inteiro & mask) == 0 ? 0 : 1;
        // manipulador.devolveBits(inteiro);
        // System.out.println("valor bit: " + bit);
        novoInteiro <<= 1;
        novoInteiro = novoInteiro | bit;
        // System.out.println("");
        // System.out.println("inteiro: " + cont);
        // manipulador.devolveBits(inteiro);
        // System.out.println("");
        // System.out.println("novoInteiro: " + cont2);
        // manipulador.devolveBits(novoInteiro);
        // System.out.println("");
        inteiro <<= 1;
        cont++;
        cont2++;
        if(cont2 % 8 == 0 && cont2 != 0){
          // System.out.println("quadro que entrou(24): " + manipulador.devolveBits(novoInteiro));

          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 31;

          int contador = 0;
          
          // novoInteiro = manipulador.moverParaEsquerdaInteiro(novoInteiro);
          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);

          // System.out.println("Valor do novo inteiro: ");
          // manipulador.devolveBits(novoInteiro);

          while(contador < 8){
            bit = (novoInteiro & mask) == 0 ? 0 : 1;
            // manipulador.devolveBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }//Fim while
          int flag = 31;
          contador = 0;
          // System.out.println("quadro que saiu(24): " + manipulador.devolveBits(novoQuadro[indiceNvQ]));
          flag = manipulador.moverBitsEsquerda(flag);
          while(contador < 8){
            bit = (flag & mask) == 0 ? 0 : 1;
            // manipulador.devolveBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            flag <<= 1;
            contador++;
          }//Fim while

          novoQuadro[indiceNvQ] <<= 8;

          if(indiceNvQ < qtdIndices - 1){
            // System.out.println("ENTREI E SUBI O INDICE");
            indiceNvQ += 1;
          }else{
            // System.out.println("ultimo quadro codificado break");
            break;
          }//Fim else
          novoInteiro = 0;
          cont2 = 0;
        }//Fim else if
        if(cont == 32 && j == quadro.length - 1 && novoInteiro != 0){
          // System.out.println("quadro que entrou(32): " + manipulador.devolveBits(novoInteiro));
          int contador = 0;
          
          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 31; // inserindo bit de flag no começo

          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);
          // System.out.println("Valor do novo inteiro: ");
          // manipulador.devolveBits(novoInteiro);

          while(contador < 8){
            bit = (novoInteiro & mask) == 0 ? 0 : 1;
            // manipulador.devolveBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }//Fim while

          int flag = 31;
          contador = 0;
          // System.out.println("quadro que saiu(24): " + manipulador.devolveBits(novoQuadro[indiceNvQ]));
          flag = manipulador.moverBitsEsquerda(flag);
          while(contador < 8){
            bit = (flag & mask) == 0 ? 0 : 1;
            // manipulador.devolveBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            flag <<= 1;
            contador++;
          }//Fim while

          // System.out.println("antes: ");
          // manipulador.devolveBits(novoQuadro[indiceNvQ]);
          // System.out.println("depois: ");
          novoQuadro[indiceNvQ] <<= 8;


          // System.out.println("quadro que saiu(32): " + manipulador.devolveBits(novoQuadro[indiceNvQ]));
          // manipulador.devolveBits(novoQuadro[indiceNvQ]);
        }//Fim if
      }//Fim while
    }//Fim for

    return novoQuadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraInsercaoDeBytes
  public int[] CamadaDeEnlaceDadosTransmissoraEnquadramentoInsercaoDeBits (int quadro []) {
    int indiceNvQ = 0;
    int cont = 0;
    int cont2 = 0;
    int inteiro = 0;
    int mask = 1 << 31;
    int bit = 0;
    int novoInteiro = 0;
    int acumulador = 0;
    int qtdIndices = 0;

    //se achar o byte de flag dentro da mensagem adiciona um escape
    //se achar o byte de escape dentro da mensagem adiciona outro escape
    // byte de flag = a
    // byte de escape = esc

    int [] informacaoDeControle = new int[quadro.length];

    for(int i = 0; i < quadro.length; i++){
      informacaoDeControle[i] = (manipulador.retornaBitsSignificativos(quadro[i]))/8;
      acumulador += informacaoDeControle[i];
      // System.out.println("informacao: ");
      // System.out.println(informacaoDeControle[i]);
    }//Fim for

    // System.out.println("valor acumulado: " + acumulador);

    /*if(acumulador > 2){
      while(acumulador > 2){
        acumulador -= 2;
        qtdIndices++;
      }//Fim while
      qtdIndices += 1;
    }else{
      qtdIndices = 1;
    }//Fim else*/

    qtdIndices = acumulador;

    int[] novoQuadro = new int[acumulador];

     // System.out.println("quantidade de indicies: " + qtdIndices);
     // System.out.println("valor do ultimo quadro: " + acumulador);

    // System.out.println("---------------");

    //quadro = manipulador.moverParaEsquerda(quadro);

    for(int m = 0; m < quadro.length; m++){
      quadro[m] = manipulador.moverBitsEsquerda(quadro[m]);
      // manipulador.devolveBits(quadro[m]);
    }// fim for

    // System.out.println("---------------");

    // System.out.println("");
    // System.out.println("NO ENLACE TRANSMISSOR: ");
    // System.out.println("");

    for(int j = 0; j < quadro.length; j++){
      cont = 0;
      inteiro = quadro[j];
      // manipulador.devolveBits(inteiro);
      while(cont < 32){
        bit = (inteiro & mask) == 0 ? 0 : 1;
        // manipulador.devolveBits(inteiro);
        // System.out.println("valor bit: " + bit);
        novoInteiro <<= 1;
        novoInteiro = novoInteiro | bit;
        inteiro <<= 1;
        cont++;
        cont2++;
        if(cont2 % 8 == 0 && cont2 != 0){
          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 126;
          int contador = 0;
          
          // novoInteiro = manipulador.moverParaEsquerdaInteiro(novoInteiro);
          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);

          // System.out.println("Valor do novo inteiro: ");
          // manipulador.devolveBits(novoInteiro);

          int contaUm = 0;

          // novoQuadro[indiceNvQ] <<= 1;
          // novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 0;

          if(manipulador.verificaCincoBitsSequenciais(novoInteiro,1) == true){
            novoQuadro[indiceNvQ] <<= 7;
            while(contador < 8){
              bit = (novoInteiro & mask) == 0 ? 0 : 1;
              // manipulador.devolveBits(novoQuadro[indiceNvQ]);
              // System.out.println("valor bit: " + bit);
              novoQuadro[indiceNvQ] <<= 1;
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
              novoInteiro <<= 1;
              contador++;
              if(bit == 1){
                contaUm++;
                if(contaUm == 5){
                  novoQuadro[indiceNvQ] <<= 1;
                  novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 0;
                  contaUm = 0;
                }//Fim if
              }//Fim if
            }//Fim while
          }else{
            while(contador < 8){
              bit = (novoInteiro & mask) == 0 ? 0 : 1;
              // manipulador.devolveBits(novoQuadro[indiceNvQ]);
              // System.out.println("valor bit: " + bit);
              novoQuadro[indiceNvQ] <<= 1;
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
              novoInteiro <<= 1;
              contador++;
            }//Fim while
          }//fim else

          int flag = 126;
          contador = 0;
          // System.out.println("quadro que saiu(24): " + manipulador.devolveBits(novoQuadro[indiceNvQ]));
          flag = manipulador.moverBitsEsquerda(flag);
          while(contador < 8){
            bit = (flag & mask) == 0 ? 0 : 1;
            // manipulador.devolveBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            flag <<= 1;
            contador++;
          }//Fim while

          // manipulador.moverBitsEsquerda(novoQuadro[indiceNvQ]);

          if(indiceNvQ < qtdIndices - 1){
            // System.out.println("ENTREI E SUBI O INDICE");
            indiceNvQ += 1;
          }else{
            break;
          }//Fim else
          novoInteiro = 0;
          cont2 = 0;
        }//Fim if
        if(cont == 32 && j == quadro.length - 1 && novoInteiro != 0){
          // System.out.println("quadro que entrou(32): " + manipulador.devolveBits(novoInteiro));
          int contador = 0;
          
          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 126; // inserindo bit de flag no começo
          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);
          // System.out.println("Valor do novo inteiro: ");
          // manipulador.devolveBits(novoInteiro);

          int contaUm = 0;

          if(manipulador.verificaCincoBitsSequenciais(novoInteiro,1) == true){
            novoQuadro[indiceNvQ] <<= 7;
            while(contador < 8){
              bit = (novoInteiro & mask) == 0 ? 0 : 1;
              // manipulador.devolveBits(novoQuadro[indiceNvQ]);
              // System.out.println("valor bit: " + bit);
              novoQuadro[indiceNvQ] <<= 1;
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
              novoInteiro <<= 1;
              
              contador++;
              if(bit == 1){
                contaUm++;
                if(contaUm == 5){
                  novoQuadro[indiceNvQ] <<= 1;
                  novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 0;
                  contaUm = 0;
                }//Fim if
              }//Fim if
            }//Fim while
          }else{
            while(contador < 8){
              bit = (novoInteiro & mask) == 0 ? 0 : 1;
              // manipulador.devolveBits(novoQuadro[indiceNvQ]);
              // System.out.println("valor bit: " + bit);
              novoQuadro[indiceNvQ] <<= 1;
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
              novoInteiro <<= 1;
              contador++;
            }//Fim while
          }//fim else

          int flag = 126;
          contador = 0;
          // System.out.println("quadro que saiu(24): " + manipulador.devolveBits(novoQuadro[indiceNvQ]));
          flag = manipulador.moverBitsEsquerda(flag);
          while(contador < 8){
            bit = (flag & mask) == 0 ? 0 : 1;
            // manipulador.devolveBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            flag <<= 1;
            contador++;
          }//Fim while

          // System.out.println("antes: ");
          // manipulador.devolveBits(novoQuadro[indiceNvQ]);
          // System.out.println("depois: ");
          
          novoQuadro[indiceNvQ] <<= 8;

          // System.out.println("quadro que saiu(32): " + manipulador.devolveBits(novoQuadro[indiceNvQ]));
          // manipulador.devolveBits(novoQuadro[indiceNvQ]);
        }//Fim if
      }//Fim while
    }//Fim for

    for(int i =0; i < novoQuadro.length; i++){
      novoQuadro[i] = manipulador.moverBitsEsquerda(novoQuadro[i]);
    }//FIm for

    return novoQuadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraInsercaoDeBits
  public int[] CamadaDeEnlaceDadosTransmissoraEnquadramentoViolacaoDaCamadaFisica(int quadro []) {

    int indiceNvQ = 0;
    int cont = 0;
    int cont2 = 0;
    int inteiro = 0;
    int mask = 1 << 31;
    int bit = 0;
    int novoInteiro = 0;
    int acumulador = 0;
    int qtdIndices = 0;

    int [] informacaoDeControle = new int[quadro.length];

    for(int i = 0; i < quadro.length; i++){
      informacaoDeControle[i] = (manipulador.retornaBitsSignificativos(quadro[i]))/8;
      acumulador += informacaoDeControle[i];
      // System.out.println("informacao: ");
      // System.out.println(informacaoDeControle[i]);
    }//Fim for


    // System.out.println("valor acumulado: " + acumulador);

    /*if(acumulador > 2){
      while(acumulador > 2){
        acumulador -= 2;
        qtdIndices++;
      }//Fim while
      qtdIndices += 1;
    }else{
      qtdIndices = 1;
    }//Fim else*/

    qtdIndices = acumulador;

    int[] novoQuadro = new int[acumulador];

     // System.out.println("quantidade de indicies: " + qtdIndices);
     // System.out.println("valor do ultimo quadro: " + acumulador);

    // System.out.println("---------------");

    //quadro = manipulador.moverParaEsquerda(quadro);

    for(int m = 0; m < quadro.length; m++){
      quadro[m] = manipulador.moverBitsEsquerda(quadro[m]);
      // manipulador.devolveBits(quadro[m]);
    }// fim for

    // System.out.println("---------------");

    // System.out.println("");
    // System.out.println("NO ENLACE TRANSMISSOR: ");
    // System.out.println("");

    for(int j = 0; j < quadro.length; j++){
      cont = 0;
      inteiro = quadro[j];
      // manipulador.devolveBits(inteiro);
      while(cont < 32){
        bit = (inteiro & mask) == 0 ? 0 : 1;
        // manipulador.devolveBits(inteiro);
        // System.out.println("valor bit: " + bit);
        novoInteiro <<= 1;
        novoInteiro = novoInteiro | bit;
        inteiro <<= 1;
        cont++;
        cont2++;
        if(cont2 % 8 == 0 && cont2 != 0){

          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 3; //adiciona 11 para limitar o inicio do quadro
          int contador = 0;
          
          // novoInteiro = manipulador.moverParaEsquerdaInteiro(novoInteiro);
          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);

          int contaUm = 0;

          // novoQuadro[indiceNvQ] <<= 1;
          // novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 0;

          novoQuadro[indiceNvQ] <<= 6;

          while(contador < 8){
            bit = (novoInteiro & mask) == 0 ? 1 : 2;
            // manipulador.devolveBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[indiceNvQ] <<= 2;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }//Fim while

          novoQuadro[indiceNvQ] <<= 8;

          // manipulador.moverBitsEsquerda(novoQuadro[indiceNvQ]);

          if(indiceNvQ < qtdIndices - 1){
            // System.out.println("ENTREI E SUBI O INDICE");
            indiceNvQ += 1;
          }else{
            break;
          }//Fim else
          novoInteiro = 0;
          cont2 = 0;
        }//Fim if
        if(cont == 32 && j == quadro.length - 1 && novoInteiro != 0){

          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 3;
          int contador = 0;
          
          // novoInteiro = manipulador.moverParaEsquerdaInteiro(novoInteiro);
          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);

          // System.out.println("Valor do novo inteiro: ");
          // manipulador.devolveBits(novoInteiro);

          int contaUm = 0;

          novoQuadro[indiceNvQ] <<= 8;

          while(contador < 8){
            bit = (novoInteiro & mask) == 0 ? 1 : 2;
            // manipulador.devolveBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[indiceNvQ] <<= 2;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }//Fim while

          novoQuadro[indiceNvQ] <<= 8;

          // manipulador.moverBitsEsquerda(novoQuadro[indiceNvQ]);

          if(indiceNvQ < qtdIndices - 1){
            // System.out.println("ENTREI E SUBI O INDICE");
            indiceNvQ += 1;
          }else{
            break;
          }//Fim else
          novoInteiro = 0;
          cont2 = 0;
          // System.out.println("quadro que saiu(32): " + manipulador.devolveBits(novoQuadro[indiceNvQ]));
          // manipulador.devolveBits(novoQuadro[indiceNvQ]);
        }//Fim if
      }//Fim while
    }//Fim for

    for(int i =0; i < novoQuadro.length; i++){
      novoQuadro[i] = manipulador.moverBitsEsquerda(novoQuadro[i]);
    }//FIm for

    return novoQuadro;

  }//fim do metodo CamadaEnlaceDadosTransmissoraViolacaoDaCamadaFisica

  /*public void setControlador (Controlador controlador){
    control = controlador;
  }//fim metodo setControlador*/

  /* ********************************RECEBER QUADROS:***************************************** */

  public void CamadaEnlaceDadosReceptora(int quadro[]){
    int quadroEnquadrado [];
    quadroEnquadrado = camadaEnlaceDadosReceptoraEnquadramento(quadro); 
    quadroEnquadrado = camadaEnlaceDadosReceptoraControleDeErro(quadroEnquadrado);
    //camadaDeEnlaceDadosReceptoraControleDeFluxo(quadroEnquadrado);

    if(quadroEnquadrado.length == 1){
      int verificaNak = manipulador.devolveNAK();
      verificaNak = manipulador.retornaPrimeiroByte(verificaNak);
      int quadroEnquadradoPrimeiroByte = manipulador.retornaPrimeiroByte(quadroEnquadrado[0]);
      if(quadroEnquadradoPrimeiroByte == verificaNak){
        enviarNak();
      }else{
        //envia ack
        enviarAck();
        camadaApliReceptora.camadaAplicacaoReceptora(quadroEnquadrado);  
      }//fim else
    }else{
      //envia ack
      enviarAck();
      camadaApliReceptora.camadaAplicacaoReceptora(quadroEnquadrado);
    }//fim else
  }//fim metodo CamadaEnlanceDadosTransmissora

  public int[] camadaEnlaceDadosReceptoraEnquadramento(int quadro[]){
    int quadroEnquadrado[];
    tipoDeEnquadramento = control.tipoDeEnquadramento; //alterar de acordo com o teste  
    switch (tipoDeEnquadramento){
      case 0 : //contagem de caracteres
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoContagemDeCaracteres(quadro);
        return quadroEnquadrado;
      case 1 : //insercao de bytes
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBytes(quadro);
        return quadroEnquadrado;
      case 2 : //insercao de bits
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBits(quadro);
        return quadroEnquadrado;
      case 3 : //violacao da camada fisica
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoViolacaoDaCamadaFisica(quadro);
        return quadroEnquadrado;
    }//fim do switch/case
    return quadro;
  }//fim do metodo CamadaEnlaceTransmissoraEnquadramento

  public int[] camadaEnlaceDadosReceptoraControleDeErro (int quadro []) {
    int quadroNovo [];
    switch (tipoDeControleDeErro) {
      case 0 : //bit de paridade par
        quadroNovo = camadaEnlaceDadosReceptoraControleDeErroBitDeParidadePar(quadro);
        return quadroNovo;
      case 1 : //bit de paridade impar
        quadroNovo = camadaEnlaceDadosReceptoraControleDeErroBitDeParidadeImpar(quadro);
        return quadroNovo;
      case 2 : //CRC
        quadroNovo = camadaEnlaceDadosReceptoraControleDeErroCRC(quadro);
        return quadroNovo;
      case 3 : //codigo de hamming
        return quadro; // colocar quadro novo
    }//fim do switch/case
      return quadro; 
  }//fim do metodo CamadaEnlaceDadosReceptoraControleDeErro


 public int[] camadaEnlaceDadosReceptoraControleDeErroCRC(int quadro[]){
   int crc32 = manipulador.devolveCrc(); // correspondente ao valor decimal do binario do crc32
   int resto = 0;
   int inteiro = 0;
   int bit = 0;
   boolean verif = false;
   int cont = 0;
   int quadrosCRC [] = new int[quadro.length/2];

   for(int i = 0; i < quadro.length; i++){
    if(i % 2 == 0){
      resto = 0;
      crc32 = manipulador.devolveCrc(); // correspondente ao valor decimal do binario do crc32
      int contador = 0;
      inteiro = quadro[i];
      verif = false;
      if((manipulador.retornarBitNaPosicao(inteiro,0)) == 0){
        inteiro <<= 1; //comecando do primeiro bit mais redundante
        verif = true;
      }//Fim if
      contador = 0;
      while(contador < 32){
        // System.out.println("posicao 0: " + manipulador.retornarBitNaPosicao(inteiro,0));
        // System.out.println("posicao 1: " + manipulador.retornarBitNaPosicao(inteiro,1));
        // manipulador.devolveBits(inteiro);
        bit = ((manipulador.retornarBitNaPosicao(inteiro,0)) ^ (manipulador.retornarBitNaPosicao(crc32,0))) == 0 ? 0:1;
        // System.out.println("VALOR BIT: " + bit + " valores do bit: " + manipulador.retornarBitNaPosicao(inteiro,0) + " xor " + (manipulador.retornarBitNaPosicao(crc32,0)));
        resto <<= 1;
        resto |= bit;
        // System.out.println("valor do resto: ");
        // manipulador.devolveBits(resto);
        // System.out.println("valor inteiro: ");
        // manipulador.devolveBits(inteiro);
        // System.out.println("valor crcd : ");
        // manipulador.devolveBits(crc32);
        // System.out.println("valor do resto: ");
        // manipulador.devolveBits(resto);
        crc32 <<= 1;
        inteiro <<= 1;
        contador++;
        if(verif == true && contador == 31){
          bit = manipulador.retornarBitNaPosicao(crc32,0);
          resto <<= 1;
          resto |= bit;
          quadrosCRC[cont] = resto;
          cont++;
          break;
        }//Fim if
      }//Fim while
      if(verif == false){ 
        quadrosCRC[i] = resto;
        break;
      }//fim if
    }//Fim if
  }//Fim for
  int quadrosCrcOriginal [] = new int [quadrosCRC.length];
  int contCrc = 0;
  for(int i =0; i < quadro.length; i++){
    if(i % 2 != 0){
      quadrosCrcOriginal[contCrc] = quadro[i]; //resto gerado na divisao do transmissor
      contCrc++;
    }//fim if
  }//Fim for

  int inteiroCrc1 = 0; //crc gerado na transmissora
  int inteiroCrc2 = 0; //crc gerado na receptora
  int contaIndice = 0;
  int indiceQuadro= 0;
  int quadrosAtransmitir [] = new int[quadro.length];
  for(int i = 0; i < quadrosCRC.length;i++){
    int contador = 0;
    resto        = 0;
    inteiroCrc1  = quadrosCrcOriginal[i];
    inteiroCrc2  = quadrosCRC[i];
    while(contador < 32){
      // System.out.println("posicao 0: " + manipulador.retornarBitNaPosicao(inteiro,0));
      // System.out.println("posicao 1: " + manipulador.retornarBitNaPosicao(inteiro,1));
      // manipulador.devolveBits(inteiro);
      bit = ((manipulador.retornarBitNaPosicao(inteiroCrc1,0)) ^ (manipulador.retornarBitNaPosicao(inteiroCrc2,0))) == 0 ? 0:1;
      resto <<= 1;
      resto |= bit;
      // System.out.println("valor inteiro: ");
      // manipulador.devolveBits(inteiro);
      // System.out.println("valor crcd : ");
      // manipulador.devolveBits(crc32);
      // System.out.println("valor do resto: ");
      // manipulador.devolveBits(resto);
      inteiroCrc1 <<= 1;
      inteiroCrc2 <<= 1;
      contador++;
    }//Fim while
    if(resto == 0){
      quadrosAtransmitir[contaIndice] = quadro[indiceQuadro];
      contaIndice++;
      indiceQuadro += 2;
    }//fim if
    else{
      int quadroNak[] = new int[1];
      //quadrosAtransmitir[contaIndice] = manipulador.devolveNAK();
      quadroNak[0] = manipulador.devolveNAK();
      
      contaIndice++;
      indiceQuadro += 2;
      return quadroNak;
    }//Fim else
  }//fim for
  return quadrosAtransmitir;
 }//fim metodo camadaEnlanceDadosReceptoraControleDeErroCRC

 public int[] camadaEnlaceDadosReceptoraControleDeErroBitDeParidadePar(int quadro []){
  int quadrosAtransmitir [] = new int[quadro.length];
  for(int i = 0; i < quadro.length; i++){
    if((manipulador.quantidadeBits1Inteiro(quadro[i])) % 2 == 0){
      quadro[i] >>= 16; 
      quadro[i] = manipulador.moverBitsEsquerda(quadro[i]);
      quadrosAtransmitir[i] = quadro[i];
    }else{
      quadrosAtransmitir[i] = manipulador.devolveNAK();
      int quadroComErro[] = new int[1];
      quadroComErro[0] = manipulador.devolveNAK();
      return quadroComErro;
    }//Fim else
  }//Fim for
  return quadrosAtransmitir;
 }//fim do metodo CamadaEnlaceDadosReceptoraControleDeErroBitDeParidadePar

 public int[] camadaEnlaceDadosReceptoraControleDeErroBitDeParidadeImpar(int quadro []) {
  int quadrosAtransmitir [] = new int[quadro.length];
  for(int i = 0; i < quadro.length; i++){
    if((manipulador.quantidadeBits1Inteiro(quadro[i])) % 2 != 0){
      quadro[i] >>= 16; 
      quadro[i] = manipulador.moverBitsEsquerda(quadro[i]);
      quadrosAtransmitir[i] = quadro[i];
    }else{
      quadrosAtransmitir[i] = manipulador.devolveNAK();
      int quadroComErro[] = new int[1];
      quadroComErro[0] = manipulador.devolveNAK();
      return quadroComErro;
    }//Fim else
  }//Fim for
  return quadrosAtransmitir;
 }//fim do metodo CamadaEnlaceDadosReceptoraControleDeErroBitDeParidadeImpar
 
 public void camadaEnlaceDadosReceptoraControleDeErroCodigoDeHamming (int quadro []) {
 //implementacao do algoritmo para VERIFICAR SE HOUVE ERRO
 }//fim do metodo CamadaEnlaceDadosReceptoraControleDeErroCodigoDeHamming

  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoContagemDeCaracteres(int quadro []) {
    if(tipoDeControleDeErro == 2){  
      for(int j = 0; j < quadro.length; j++){
        if(j % 2 == 0){
          quadro[j] <<= 8;
        }//fim if
      }//Fim for
    }else{
      for(int j = 0; j < quadro.length; j++){
        quadro[j] <<= 8;
      }//Fim for
    }//fim else
    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraContagemDeCaracteres

  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBytes (int quadro []) {
    if(tipoDeControleDeErro == 2){
      for(int j = 0; j < quadro.length; j++){
        if(j % 2 == 0){
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,24);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,23);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,22);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,21);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,20);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,19);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,18);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,17);
          quadro[j] <<= 8;
        }//fim if
      }//Fim for
    }else{
      for(int j = 0; j < quadro.length; j++){
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,24);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,23);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,22);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,21);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,20);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,19);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,18);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,17);
        quadro[j] <<= 8;
      }//Fim for
    }//fim else

    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraInsercaoDeBytes

  //manipulador.verificaCincoBitsSequenciais(quadro[j]);
      // manipulador.devolveBits(quadro[j]);
  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBits (int quadro []) {
    int mask    = 1;
    int bit     = 0;
    int bit2    = 0;
    int bit3    = 0;
    int bitUm   = 0;
    int inteiro = 0;
    int umBitaFrente = 0;
    int umBitaFrente2 = 0;

    if(tipoDeControleDeErro == 2){
      for(int j = 0; j < quadro.length; j++){
        if(j % 2 == 0){
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,24);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,23);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,22);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,21);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,20);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,19);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,18);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,17);
          quadro[j] <<= 8;
          // int temp = manipulador.retornaPrimeiroByte(quadro[j]);
          // manipulador.devolveBits(temp);
          if(manipulador.retornaPrimeiroByte2(quadro[j]) == 0){
            quadro[j] >>= 16;
            inteiro = quadro[j];
            umBitaFrente = inteiro >> 1;
            umBitaFrente2 = umBitaFrente >> 1;
            while(true){
              bit = (inteiro & mask) == 0 ? 0 : 1;
              bit2 = (umBitaFrente & mask) == 0 ? 0 : 1;
              bit3 = (umBitaFrente2 & mask) == 0 ? 0 : 1;
              if(bit == 0 && bit2 == 0 && bit3 == 1){
                inteiro >>= 1;
                quadro[j] = inteiro;
                break;
              }else{
                inteiro >>= 1;
                umBitaFrente >>=1;
                umBitaFrente2>>=2;
              }//Fim else
            }//fim while
          }else{
            quadro[j] >>= 24;
          }//Fim else
        }//fim if
      }//Fim for
    }else{
      for(int j = 0; j < quadro.length; j++){
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,24);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,23);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,22);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,21);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,20);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,19);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,18);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j],0,17);
        quadro[j] <<= 8;
        // int temp = manipulador.retornaPrimeiroByte(quadro[j]);
        // manipulador.devolveBits(temp);
        if(manipulador.retornaPrimeiroByte2(quadro[j]) == 0){
          quadro[j] >>= 16;
          inteiro = quadro[j];
          umBitaFrente = inteiro >> 1;
          umBitaFrente2 = umBitaFrente >> 1;
          while(true){
            bit = (inteiro & mask) == 0 ? 0 : 1;
            bit2 = (umBitaFrente & mask) == 0 ? 0 : 1;
            bit3 = (umBitaFrente2 & mask) == 0 ? 0 : 1;
            if(bit == 0 && bit2 == 0 && bit3 == 1){
              inteiro >>= 1;
              quadro[j] = inteiro;
              break;
            }else{
              inteiro >>= 1;
              umBitaFrente >>=1;
              umBitaFrente2>>=2;
            }//Fim else
          }//fim while
        }//fim if
      }//Fim for
    }//fim else
    if(tipoDeControleDeErro == 2){
      for(int i =0; i < quadro.length; i++){
        if(i % 2 == 0){
          quadro[i] = manipulador.moverBitsEsquerda(quadro[i]);
        }//fim if
        else{
        }//fim else
      }//Fim for
    }else{
      for(int i =0; i < quadro.length; i++){
        quadro[i] = manipulador.moverBitsEsquerda(quadro[i]);
      }//fim for
    }//fim else
    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraInsercaoDeBits


  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoViolacaoDaCamadaFisica(int quadro []) {
    int[] novoQuadro = new int [quadro.length];
    int contador = 0;
    int bit = 0;
    int mask = 1 << 31;


    if(tipoDeControleDeErro == 2){
      for(int j = 0; j < quadro.length; j++){
        if(j % 2 == 0){  
          contador = 0;
          quadro[j] <<= 8;
          while(contador < 8){
            bit = (quadro[j] & mask) == 0 ? 0 : 1;
            // manipulador.devolveBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[j] <<= 1;
            novoQuadro[j] = novoQuadro[j] | bit;
            quadro[j] <<= 2;
            contador++;
          }//Fim while
        }//Fim if  
      }//Fim for
    }else{
      for(int j = 0; j < quadro.length; j++){ 
        int temp = 0; 
        contador = 0;
        quadro[j] <<= 8;
        temp = manipulador.retornarBitNaPosicao(quadro[j],16);
        while(contador < 32){
          bit = (quadro[j] & mask) == 0 ? 0 : 1;
          // manipulador.devolveBits(novoQuadro[indiceNvQ]);
          // System.out.println("valor bit: " + bit);
          novoQuadro[j] <<= 1;
          novoQuadro[j] = novoQuadro[j] | bit;
          quadro[j] <<= 2;
          contador++;
        }//Fim while
        novoQuadro[j] = manipulador.colocarBitNaPosicao(novoQuadro[j],0,9);
        novoQuadro[j] = manipulador.colocarBitNaPosicao(novoQuadro[j],temp,17);
      }//Fim for
    }//fim else
    if(tipoDeControleDeErro == 2){
      for(int i =0; i < quadro.length; i++){
        if(i % 2 == 0){
          novoQuadro[i] = manipulador.moverBitsEsquerda(novoQuadro[i]);
        }//fim if
        else{
          novoQuadro[i] = quadro[i];
        }//Fim else
      }//Fim for
    }else{
      for(int i =0; i < quadro.length; i++){
        novoQuadro[i] = manipulador.moverBitsEsquerda(novoQuadro[i]);
      }//Fim for
    }//Fim else
    return novoQuadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraViolacaoDaCamadaFisica
}//fim classe CamadaEnlaceDadosTransmissora