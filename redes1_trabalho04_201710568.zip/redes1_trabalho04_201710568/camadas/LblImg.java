package camadas;

import static camadas.AplicacaoTransmissora.control;

public class LblImg extends Thread{
	public void run(){
		//control.reenviandoImg.setVisible(true);
        control.lblReenviando.setVisible(true);
	}
}