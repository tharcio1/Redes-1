package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static controlador.Controlador.tipoDeDecodificacao;
import static camadas.CamadaEnlaceDadosReceptora.host2Enviando;
import static camadas.CamadaEnlaceDadosTransmissora.host1Enviando;
//import static camadas.AplicacaoTransmissora.enlaceTransmissora;

public class CamadaFisicaReceptora{

  // CamadaDeAplicacaoReceptora aplicacaoReceptora = new CamadaDeAplicacaoReceptora();
  static CamadaEnlaceDadosReceptora enlaceReceptora = new CamadaEnlaceDadosReceptora();
  CamadaEnlaceDadosTransmissora enlaceTransmissora = new CamadaEnlaceDadosTransmissora();
  MetodosBit manipulador = new MetodosBit();

	public void camadaFisicaReceptora(int quadro[]) {
    int fluxoBrutoDeBits[];
    switch (tipoDeDecodificacao) {
      case 0 : //decodificao binaria
        fluxoBrutoDeBits = camadaFisicaReceptoraDecodificacaoBinaria(quadro);
        //if controlerrenvio = true sabe que eh ack e envia para transmissora
        if(host2Enviando == true){
          enlaceTransmissora.verificaAckOuCGU(quadro);
        }
        else if(host1Enviando == true){
          enlaceReceptora.verificaAckOuCGU(quadro);
        }
        break;
      case 1 : //decodificacao manchester
        fluxoBrutoDeBits = camadaFisicaReceptoraDecodificacaoManchester(quadro);
        enlaceReceptora.CamadaEnlaceDadosReceptora(fluxoBrutoDeBits);
        break;
      case 2 : //codificacao manchester diferencial
        fluxoBrutoDeBits = camadaFisicaReceptoraDecodificacaoManchesterDiferencial(quadro);
        enlaceReceptora.CamadaEnlaceDadosReceptora(fluxoBrutoDeBits);
        break;
    }//fim do switch case
  }//fim metodo CamadaFisicaReceptora

  public int[] camadaFisicaReceptoraDecodificacaoBinaria(int quadro[]){
    //implementacao do algoritmo para decodificar
    
    return quadro;
  }//Fim metodo CamadaFisicaReceptoraCodificacaoBinaria
 
  public int[] camadaFisicaReceptoraDecodificacaoManchester(int quadro[]){
    //implementacao do algoritmo para decodificar
    int[] novoQuadro = new int[quadro.length/2];
    int indiceNvQ = 0;
    int cont = 0;
    int cont2 = 0;
    int inteiro = 0;
    int mask = 1 << 31;
    int bit = 0;
    int novoInteiro = 0;


    for(int j = 0; j < quadro.length; j++){
      cont = 0;
      inteiro = quadro[j];
      while(cont < 16){
        bit = (inteiro & mask) == 0 ? 0 : 1;
        // System.out.println("valor bit: " + bit);
        novoInteiro <<= 1;
        novoInteiro = novoInteiro | bit;
        inteiro <<= 2;
        cont++;
        cont2++;
        if(cont2 % 32 == 0 && cont2 != 0){
          novoQuadro[indiceNvQ] = novoInteiro;
          if(indiceNvQ < (quadro.length / 2) - 1){
            indiceNvQ += 1;
          }//Fim if
          novoInteiro = 0;
          cont2 = 0;
        }//Fim if
      }//Fim while
    }//Fim for

    return novoQuadro;
  }//Fim metodo camadaFisicaReceptoraDecodificacaoManchester

  public int[] camadaFisicaReceptoraDecodificacaoManchesterDiferencial(int quadro[]){
    //implementacao do algoritmo para decodificar

    int[] novoQuadro = new int[quadro.length/2];
    int indiceNvQ = 0;
    int cont = 0;
    int cont2 = 0;
    int inteiro = 0;
    int mask = 1 << 31;
    int bit = 0;
    int novoInteiro = 0;


    for(int j = 0; j < quadro.length; j++){
      cont = 0;
      inteiro = quadro[j];
      while(cont < 16){
        bit = (inteiro & mask) == 0 ? 0 : 1;
        novoInteiro <<= 1;
        novoInteiro = novoInteiro | bit;
        inteiro <<= 2;
        cont++;
        cont2++;
        if(cont2 % 32 == 0 && cont2 != 0){
          novoQuadro[indiceNvQ] = novoInteiro;
          if(indiceNvQ < (quadro.length / 2) - 1){
            indiceNvQ += 1;
          }//Fim if
          novoInteiro = 0;
          cont2 = 0;
        }//Fim if
      }//Fim while
    }//Fim for

    return novoQuadro;
  }//Fim metodo camadaFisicaReceptoraDecodificacaoManchesterDiferencial

}//Fim classe CamadaFisicaReceptora