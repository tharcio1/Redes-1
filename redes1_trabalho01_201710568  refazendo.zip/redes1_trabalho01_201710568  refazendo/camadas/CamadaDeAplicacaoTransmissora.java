public class CamadaDeAplicacaoTransmissora{
	
}