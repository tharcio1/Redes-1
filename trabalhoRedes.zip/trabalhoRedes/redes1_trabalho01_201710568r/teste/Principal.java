public class Principal{
	public static void main(String args[]){
    	int aux = 0;
    	int v = 0;

    	String mensagem = "abcd";

    	int[] vetor = new int[mensagem.length()];
    
    	for (int i=0; i<mensagem.length(); i++) {
      		vetor[i] = mensagem.charAt(i);
      		System.out.println(vetor[i]);
    	}
	}
}