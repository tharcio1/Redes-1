int indiceNvQ = 0;
int cont = 0;
int cont2 = 0;
int inteiro = 0;
int mask = 1 << 31;
int bit = 0;
int novoInteiro = 0;
int acumulador = 0;
int qtdIndices = 0;

//se achar o byte de flag dentro da mensagem adiciona um escape
//se achar o byte de escape dentro da mensagem adiciona outro escape
// byte de flag = a
// byte de escape = esc

int [] informacaoDeControle = new int[quadro.length];

for(int i = 0; i < quadro.length; i++){
  informacaoDeControle[i] = (manipulador.quantidadeDeBits(quadro[i]))/8;
  acumulador += informacaoDeControle[i];
  // System.out.println("informacao: ");
  // System.out.println(informacaoDeControle[i]);
}//Fim for

// System.out.println("--------------enlaceTransmissora------------");
for(int i = 0; i < quadro.length; i++){
  manipulador.imprimirBits(quadro[i]);
}
// System.out.println();

// System.out.println("valor acumulado: " + acumulador);

if(acumulador > 2){
  while(acumulador > 2){
    acumulador -= 2;
    qtdIndices++;
  }//Fim while
  qtdIndices += 1;
}else{
  qtdIndices = 1;
}//Fim else

int[] novoQuadro = new int[qtdIndices];

 // System.out.println("quantidade de indicies: " + qtdIndices);
 // System.out.println("valor do ultimo quadro: " + acumulador);

for(int a = 0; a < quadro.length; a++){
  // System.out.println("quadros: ");
  manipulador.imprimirBits(quadro[a]);
}
// System.out.println("---------------");

//quadro = manipulador.moverParaEsquerda(quadro);

for(int m = 0; m < quadro.length; m++){
  quadro[m] = manipulador.deslocarBits(quadro[m]);
  // manipulador.imprimirBits(quadro[m]);
}// fim for

// System.out.println("---------------");

// System.out.println("");
// System.out.println("NO ENLACE TRANSMISSOR: ");
// System.out.println("");

for(int j = 0; j < quadro.length; j++){
  cont = 0;
  inteiro = quadro[j];
  // manipulador.imprimirBits(inteiro);
  while(cont < 32){
    bit = (inteiro & mask) == 0 ? 0 : 1;
    // manipulador.imprimirBits(inteiro);
    // System.out.println("valor bit: " + bit);
    novoInteiro <<= 1;
    novoInteiro = novoInteiro | bit;
    // System.out.println("");
    // System.out.println("inteiro: " + cont);
    // manipulador.imprimirBits(inteiro);
    // System.out.println("");
    // System.out.println("novoInteiro: " + cont2);
    // manipulador.imprimirBits(novoInteiro);
    // System.out.println("");
    inteiro <<= 1;
    cont++;
    cont2++;
    if(cont2 % 16 == 0 && cont2 != 0){

      // System.out.println("quadro que entrou(24): " + manipulador.imprimirBits(novoInteiro));

      novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 31;

      int contador = 0;
      
      // novoInteiro = manipulador.moverParaEsquerdaInteiro(novoInteiro);
      novoInteiro = manipulador.deslocarBits(novoInteiro);

      // System.out.println("Valor do novo inteiro: ");
      // manipulador.imprimirBits(novoInteiro);

      while(contador < 16){
        bit = (novoInteiro & mask) == 0 ? 0 : 1;
        // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
        // System.out.println("valor bit: " + bit);
        novoQuadro[indiceNvQ] <<= 1;
        novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
        novoInteiro <<= 1;
        contador++;
      }//Fim while
      int flag = 31;
      contador = 0;
      // System.out.println("quadro que saiu(24): " + manipulador.imprimirBits(novoQuadro[indiceNvQ]));
      while(contador < 8){
        bit = (flag & mask) == 0 ? 0 : 1;
        // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
        // System.out.println("valor bit: " + bit);
        novoQuadro[indiceNvQ] <<= 1;
        novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
        flag <<= 1;
        contador++;
      }//Fim while


      if(indiceNvQ < qtdIndices - 1){
        // System.out.println("ENTREI E SUBI O INDICE");
        indiceNvQ += 1;
      }else{
        // System.out.println("ultimo quadro codificado break");
        break;
      }//Fim else
      novoInteiro = 0;
      cont2 = 0;
      // System.out.println("VALOR DO CONT: " + cont);
    }//Fim if
    if(cont == 32 && j == quadro.length - 1 && novoInteiro != 0){
      // System.out.println("quadro que entrou(32): " + manipulador.imprimirBits(novoInteiro));
      int contador = 0;
      
      novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 31; // inserindo bit de flag no começo

      int contador = 0;

      novoInteiro = manipulador.deslocarBits(novoInteiro);
      // System.out.println("Valor do novo inteiro: ");
      // manipulador.imprimirBits(novoInteiro);

      while(contador < (acumulador * 8)){
        bit = (novoInteiro & mask) == 0 ? 0 : 1;
        // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
        // System.out.println("valor bit: " + bit);
        novoQuadro[indiceNvQ] <<= 1;
        novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
        novoInteiro <<= 1;
        contador++;
      }//Fim while

      int flag = 31;
      contador = 0;
      // System.out.println("quadro que saiu(24): " + manipulador.imprimirBits(novoQuadro[indiceNvQ]));
      while(contador < 8){
        bit = (flag & mask) == 0 ? 0 : 1;
        // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
        // System.out.println("valor bit: " + bit);
        novoQuadro[indiceNvQ] <<= 1;
        novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
        flag <<= 1;
        contador++;
      }//Fim while

      // System.out.println("antes: ");
      // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
      // System.out.println("depois: ");
      if(acumulador * 8 == 8){
        novoQuadro[indiceNvQ] <<= 8;
      }//Fim if

      // System.out.println("quadro que saiu(32): " + manipulador.imprimirBits(novoQuadro[indiceNvQ]));
      // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
    }//Fim if
  }//Fim while
}//Fim for
System.out.println("novo quadro na enlace transmissora: ");
for(int i =0; i < novoQuadro.length; i++){
   manipulador.imprimirBits(novoQuadro[i]);
}//FIm for