package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;

public class AplicacaoReceptora{
  Controlador control;
  TextField mensagemTF;
  public AplicacaoReceptora(){

  }

  public AplicacaoReceptora(TextField msg){
    mensagemTF = msg;
  }

  public void aplicacaoReceptora(String mensagem){
  	System.out.println("CAMADA DE APLICACAO");
    System.out.println(mensagem);
    // mensagemTF.setText("deu certo");
    // control.mensagemRecebida.setText(mensagem);
    //control.mensagemRecebidaTela.setText(mensagem);//fica na tv do gato
  }//Fim metodo aplicacaoReceptora

  public void setControlador(Controlador controlador){
  	System.out.println("O CONTROLADOR CHEGOU NA CAMADA DE AplicacaoReceptora");
    control = controlador;
    // control.mensagemDecodificada.setText("ricardo");
    // System.out.println(control.mensagemDecodificada.getText());
  }//Fim metodo setControlador

}//Fim classe AplicacaoReceptora