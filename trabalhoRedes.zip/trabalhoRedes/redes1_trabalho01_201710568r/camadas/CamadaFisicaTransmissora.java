package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static controlador.Controlador.tipoDeDecodificacao;

public class CamadaFisicaTransmissora{

  MeioDeComunicacao meio = new MeioDeComunicacao();
  ManipuladorDeBit manipulador = new ManipuladorDeBit();

  public void CamadaFisicaTransmissora(int quadro[]) {
    int fluxoBrutoDeBits[];
    switch (tipoDeDecodificacao) {
      case 0 : //codificao binaria
        fluxoBrutoDeBits = CamadaFisicaTransmissoraCodificacaoBinaria(quadro);
        meio.meioDeComunicacao(fluxoBrutoDeBits);
        break;
      case 1 : //codificacao manchester
        fluxoBrutoDeBits = CamadaFisicaTransmissoraCodificacaoManchester(quadro);
        meio.meioDeComunicacao(fluxoBrutoDeBits);
        break;
      case 2 : //codificacao manchester diferencial
        fluxoBrutoDeBits = CamadaFisicaTransmissoraCodificacaoManchesterDiferencial(quadro);
        meio.meioDeComunicacao(fluxoBrutoDeBits);
        break;
    }//fim do switch/case
  }//fim metodo CamadaFisicaTransmissora

  private int[] CamadaFisicaTransmissoraCodificacaoBinaria(int quadro[]){

  	return quadro;
  }//fim do metodo CamadaFisicaTransmissoraCodificacaoBinaria

  private int[] CamadaFisicaTransmissoraCodificacaoManchester (int quadro []) {
    //implementacao do algoritmo para CODIFICAR
    // System.out.println("manchester: ");
  	int[] novoQuadro = new int[quadro.length * 2];
  	int mask = 1 << 31;
  	int inteiro = 0;
  	int cont = 0;
  	int bit = 0;
  	int inteiroManchester = 0;
  	int indiceManch = 0;
  	int umBitaFrente = 0; //pega o bit n + 1 do quadro

  	for(int j = 0; j < quadro.length; j++){
  		cont = 0;
    	inteiro = quadro[j];
    	umBitaFrente = inteiro;
    	umBitaFrente <<= 1;

      /*while(manipulador.getPrimeiroByte(inteiro) == 0){
        inteiro <<= 8;
      }//Fim while*/

    	/*while((umBitaFrente & mask) == 0){
    		// System.out.println("dentro do while: ");
    		umBitaFrente <<=1;
    		inteiro <<= 1;
    		// manipulador.imprimirBits(inteiro);
    	}
    	// manipulador.imprimirBits(inteiro);*/
	    while(cont < 32){
	    	bit = (inteiro & mask) == 0 ? 1 : 2;
	    	// manipulador.imprimirBits(inteiro);
	    	// System.out.println("valor bit: " + bit);
	    	inteiroManchester <<= 2;
	    	inteiroManchester = inteiroManchester | bit;
	    	// System.out.println("");
	    	// System.out.println("inteiroManchester: ");
	    	// manipulador.imprimirBits(inteiroManchester);
	    	// System.out.println("");
	    	inteiro <<= 1;
	    	cont++;
	    	if(cont % 16 == 0 && cont != 0){
	    		novoQuadro[indiceManch] = inteiroManchester;
	    		if(indiceManch < (quadro.length * 2) - 1){
	    			indiceManch += 1;
	    		}//Fim if
	    		inteiroManchester = 0;
	    	}//Fim if
	    }//Fim while
	  }//Fim for
	   System.out.println("NOVO QUADRO FISICA: ");
	   manipulador.imprimirBits(novoQuadro[0]);
	   manipulador.imprimirBits(novoQuadro[1]);
  	return novoQuadro;
  }//fim do metodo CamadaFisicaTransmissoraCodificacaoManchester
  
  private int[] CamadaFisicaTransmissoraCodificacaoManchesterDiferencial(int quadro[]){
    //implementacao do algoritmo para CODIFICAR
    
  	//implementacao do algoritmo para CODIFICAR
    // System.out.println("manchester: ");
  	int[] novoQuadro = new int[quadro.length * 2];
  	int mask = 1 << 31;
  	int inteiro = 0;
  	int cont = 0;
  	int bit = 0;
  	int inteiroManchesterDif = 0;
  	int indiceManch = 0;
  	int umBitaFrente = 0; //pega o bit n + 1 do quadro

  	for(int j = 0; j < quadro.length; j++){
  		cont = 0;
    	inteiro = quadro[j];
    	umBitaFrente = inteiro;
    	umBitaFrente <<= 1;

      /*while(manipulador.getPrimeiroByte(inteiro) == 0){
        inteiro <<= 8;
      }//Fim while*/

      // manipulador.imprimirBits(inteiro);
	    while(cont < 32){
	    	bit = (inteiro & mask) == 0 ? 1 : 3;
	    	// manipulador.imprimirBits(inteiro);
	    	// System.out.println("valor bit: " + bit);
	    	inteiroManchesterDif <<= 2;
	    	inteiroManchesterDif = inteiroManchesterDif | bit;
	    	// System.out.println("");
	    	// System.out.println("inteiroManchester: ");
	    	// manipulador.imprimirBits(inteiroManchester);
	    	// System.out.println("");
	    	inteiro <<= 1;
	    	cont++;
	    	if(cont % 16 == 0 && cont != 0){
	    		novoQuadro[indiceManch] = inteiroManchesterDif;
	    		if(indiceManch < (quadro.length * 2) - 1){
	    			indiceManch += 1;
	    		}//Fim if
	    		inteiroManchesterDif = 0;
	    	}//Fim if
	    }//Fim while
	  }//Fim for
	   System.out.println("NOVO QUADRO manch dif: ");
	   manipulador.imprimirBits(novoQuadro[0]);
	   manipulador.imprimirBits(novoQuadro[1]);
  	return novoQuadro;
  }//fim do metodo CamadaFisicaTransmissoraCodificacaoManchesterDiferencial

}//im classe CamadaFisicaTransmissora