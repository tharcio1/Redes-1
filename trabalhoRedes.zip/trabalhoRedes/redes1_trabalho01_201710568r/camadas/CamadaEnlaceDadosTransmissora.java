package camadas;
import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static controlador.Controlador.tipoDeDecodificacao;

public class CamadaEnlaceDadosTransmissora{
  // Controlador control;
  CamadaFisicaTransmissora camadaFisTransmissora = new CamadaFisicaTransmissora();
  MetodosBit manipulador = new MetodosBit();
  int tipoDeEnquadramento = 3; //alterar de acordo com o teste
  int tipoDeControleDeErro = 2; //alterar de acordo com o teste

  public CamadaEnlaceDadosTransmissora(){
  
  }//Fim metodo construtor
  
  public void CamadaEnlaceDadosTransmissora(int quadro[]){
    int quadroEnquadrado [];

    quadroEnquadrado = CamadaEnlaceDadosTransmissoraEnquadramento(quadro); 
    quadroEnquadrado = camadaEnlaceDadosTransmissoraControleDeErro(quadroEnquadrado);
    //CamadaDeEnlaceDadosTransmissoraControleDeFluxo(quadro);

    camadaFisTransmissora.CamadaFisicaTransmissora(quadroEnquadrado);
  }//fim metodo CamadaEnlanceDadosTransmissora
  
  public int[] CamadaEnlaceDadosTransmissoraEnquadramento(int quadro[]){
    int quadroEnquadrado [];
    int temp[] = new int[2];
    switch (tipoDeEnquadramento) {
      case 0 : //contagem de caracteres
        quadroEnquadrado = CamadaDeEnlaceDadosTransmissoraEnquadramentoContagemDeCaracteres(quadro);
        return quadroEnquadrado;
      case 1 : //insercao de bytes
        quadroEnquadrado = CamadaDeEnlaceDadosTransmissoraEnquadramentoInsercaoDeBytes(quadro);
        return quadroEnquadrado;
      case 2 : //insercao de bits
        quadroEnquadrado = CamadaDeEnlaceDadosTransmissoraEnquadramentoInsercaoDeBits(quadro);
        return quadroEnquadrado;
      case 3 : //violacao da camada fisica
        quadroEnquadrado = CamadaDeEnlaceDadosTransmissoraEnquadramentoViolacaoDaCamadaFisica(quadro);
        return quadroEnquadrado;
    }//fim do switch/case
    return temp;
  }//fim do metodo CamadaEnlaceTransmissoraEnquadramento

  public int[] camadaEnlaceDadosTransmissoraControleDeErro (int quadro []) {
    int quadroNovo [];
    switch (tipoDeControleDeErro){
      case 0 : //bit de paridade par
        quadroNovo = camadaEnlaceDadosTransmissoraControleDeErroBitParidadePar(quadro);
        return quadroNovo;
      case 1 : //bit de paridade impar
        quadroNovo = camadaEnlaceDadosTransmissoraControleDeErroBitParidadeImpar(quadro);
        return quadroNovo;
      case 2 : //CRC
        quadroNovo = camadaEnlaceDadosTransmissoraControleDeErroCRC(quadro);
        return quadroNovo;
      case 3 : //codigo de Hamming
      
        return quadro;
    }//fim do switch/case
    return quadro;
  }//fim do metodo camadaEnlaceDadosTransmissoraControleDeErro

  public int[] camadaEnlaceDadosTransmissoraControleDeErroCRC(int quadro []){
    int quadroNovo[] = new int[quadro.length * 2];
    int crc32 = manipulador.devolveCrc(); // correspondente ao valor decimal do binario do crc32
    int resto = 0;
    int inteiro = 0;
    int bit = 0;
    boolean verif = false;
    int cont = 0;

    for(int j = 0; j < quadroNovo.length; j++){
      if(j % 2 == 0 && j != 0){
        quadroNovo[j] = quadro[cont];
        quadroNovo[j] = manipulador.deslocarBits(quadroNovo[j]);
        cont++;
      }else if(j == 0){
        quadroNovo[j] = quadro[j];
        quadroNovo[j] = manipulador.deslocarBits(quadroNovo[j]);
        cont++;
      }//Fim else if
    }//Fim for
    System.out.println("como ficou: ");
    for(int s = 0; s < quadroNovo.length; s++){
      manipulador.imprimirBits(quadroNovo[s]);
    }
    System.out.println("-----------------------------------");

    for(int i = 0; i < quadro.length; i++){
      resto = 0;
      crc32 = manipulador.devolveCrc(); // correspondente ao valor decimal do binario do crc32
      int contador = 0;
      inteiro = quadro[i];

      if(tipoDeEnquadramento == 0){
        inteiro <<= 16;
        inteiro = manipulador.deslocarBits(inteiro);
        System.out.println("tipo enquadramento = 0");
        manipulador.imprimirBits(inteiro);
        System.out.println("----------------------------------");
      }else if(tipoDeEnquadramento == 1){
        inteiro = manipulador.adicionarBitNaPosicao(inteiro,0,24);
        inteiro = manipulador.adicionarBitNaPosicao(inteiro,0,23);
        inteiro = manipulador.adicionarBitNaPosicao(inteiro,0,22);
        inteiro = manipulador.adicionarBitNaPosicao(inteiro,0,21);
        inteiro = manipulador.adicionarBitNaPosicao(inteiro,0,20);
        inteiro = manipulador.adicionarBitNaPosicao(inteiro,0,19);
        inteiro = manipulador.adicionarBitNaPosicao(inteiro,0,18);
        inteiro = manipulador.adicionarBitNaPosicao(inteiro,0,17);
        inteiro <<= 8;
        inteiro = manipulador.deslocarBits(inteiro);
      }else if(tipoDeEnquadramento == 2){
        int mask    = 1;
        int bit2    = 0;
        int bit3    = 0;
        int bitUm   = 0;
        int umBitaFrente = 0;
        int umBitaFrente2 = 0;

        inteiro = manipulador.adicionarBitNaPosicao(inteiro,0,24);
        inteiro = manipulador.adicionarBitNaPosicao(inteiro,0,23);
        inteiro = manipulador.adicionarBitNaPosicao(inteiro,0,22);
        inteiro = manipulador.adicionarBitNaPosicao(inteiro,0,21);
        inteiro = manipulador.adicionarBitNaPosicao(inteiro,0,20);
        inteiro = manipulador.adicionarBitNaPosicao(inteiro,0,19);
        inteiro = manipulador.adicionarBitNaPosicao(inteiro,0,18);
        inteiro = manipulador.adicionarBitNaPosicao(inteiro,0,17);
        inteiro <<= 8;
        // int temp = manipulador.getPrimeiroByte(quadro[j]);
        // manipulador.imprimirBits(temp);
        if(manipulador.getPrimeiroByte2(inteiro) == 0){
          inteiro >>= 16;
          umBitaFrente = inteiro >> 1;
          umBitaFrente2 = umBitaFrente >> 1;
          while(true){
            bit = (inteiro & mask) == 0 ? 0 : 1;
            bit2 = (umBitaFrente & mask) == 0 ? 0 : 1;
            bit3 = (umBitaFrente2 & mask) == 0 ? 0 : 1;
            if(bit == 0 && bit2 == 0 && bit3 == 1){
              inteiro >>= 1;
              break;
            }else{
              inteiro >>= 1;
              umBitaFrente >>=1;
              umBitaFrente2>>=2;
            }//Fim else
          }//fim while
        }else{
          inteiro >>= 24;
        }//Fim else
        inteiro = manipulador.deslocarBits(inteiro);
      }else if(tipoDeEnquadramento == 3){
        int mask = 1 << 31;
        contador = 0;
        inteiro <<= 8;

        int novoInt = 0;

        while(contador < 8){
          bit = (inteiro & mask) == 0 ? 0 : 1;
          // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
          // System.out.println("valor bit: " + bit);
          novoInt <<= 1;
          novoInt |= bit;
          inteiro <<= 2;
          contador++;
        }//Fim while
        inteiro = novoInt;
        contador = 0;
        inteiro = manipulador.deslocarBits(inteiro);
      }//Fim else if tipo 3
      verif = false;
      if((manipulador.pegarBitNaPosicao(inteiro,0)) == 0){
        inteiro <<= 1; //comecando do primeiro bit mais redundante
        verif = true;
      }//Fim if
      contador = 0;
      while(contador < 32){
        // System.out.println("posicao 0: " + manipulador.pegarBitNaPosicao(inteiro,0));
        // System.out.println("posicao 1: " + manipulador.pegarBitNaPosicao(inteiro,1));
        // manipulador.imprimirBits(inteiro);
        bit = ((manipulador.pegarBitNaPosicao(inteiro,0)) ^ (manipulador.pegarBitNaPosicao(crc32,0))) == 0 ? 0:1;
        // System.out.println("VALOR BIT: " + bit + " valores do bit: " + manipulador.pegarBitNaPosicao(inteiro,0) + " xor " + (manipulador.pegarBitNaPosicao(crc32,0)));
        resto <<= 1;
        resto |= bit;
        // System.out.println("valor do resto: ");
        // manipulador.imprimirBits(resto);
        // System.out.println("valor inteiro: ");
        // manipulador.imprimirBits(inteiro);
        // System.out.println("valor crcd : ");
        // manipulador.imprimirBits(crc32);
        // System.out.println("valor do resto: ");
        // manipulador.imprimirBits(resto);
        crc32 <<= 1;
        inteiro <<= 1;
        contador++;
        if(verif == true && contador == 31){
          bit = manipulador.pegarBitNaPosicao(crc32,0);
          resto <<= 1;
          resto |= bit;
          for(int c = 0; c < quadroNovo.length; c++){
            if(quadroNovo[c] == 0){
              quadroNovo[c] = resto;
              break;
            }//Fim if
          }//fim for c
          break;
        }//Fim if
      }//Fim while
      if(verif == false){
        for(int c = 0; c < quadroNovo.length; c++){
          if(quadroNovo[c] == 0){
            System.out.println("aqui");
            manipulador.imprimirBits(quadroNovo[c]);
            manipulador.imprimirBits(resto);
            System.out.println("-------------------------");
            quadroNovo[c] = resto;
            break;
          }//Fim if
        }//fim for c
      }//fim if
    }//Fim for
    System.out.println("crc: ");
    for(int l = 0; l < quadroNovo.length ; l++){
      manipulador.imprimirBits(quadroNovo[l]);
    }
    return quadroNovo;
  }//fim do metodo camadaEnlaceDadosTransmissoraControledeErroCRC

  public int[] camadaEnlaceDadosTransmissoraControleDeErroBitParidadePar(int quadro []){
    int bits1Areduzir = 0;
    if(tipoDeEnquadramento == 0){
      bits1Areduzir = 3;
    }else if(tipoDeEnquadramento == 1){
      bits1Areduzir = 10;
    }else if(tipoDeEnquadramento == 2){
      bits1Areduzir = 12;
    }//fim else if

    if(tipoDeEnquadramento == 3){
      int novoQuadro [] = new int[quadro.length];
      int bit =0;
      int mask = 1 << 31;
      int inteiro = 0;
      for(int j = 0; j < quadro.length; j++){ 
        int temp = 0; 
        int contador = 0;
        inteiro = quadro[j];
        inteiro <<= 8;
        System.out.println("-------------------");
        while(contador < 32){
          bit = (inteiro & mask) == 0 ? 0 : 1;
          // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
          // System.out.println("valor bit: " + bit);
          novoQuadro[j] <<= 1;
          novoQuadro[j] = novoQuadro[j] | bit;
          inteiro <<= 2;
          contador++;
        }//Fim while
        System.out.println("eu te falei:");
        manipulador.imprimirBits(novoQuadro[j]);
      }//fim for
      for(int i = 0; i < quadro.length; i++){
        quadro[i] = manipulador.deslocarBits(quadro[i]);
        if((manipulador.quantidadeBits1Inteiro(novoQuadro[i])) % 2 == 0){
          System.out.println("paridade par ok: ");
          //insere 0 mas ja tem zero no bit posterior a mensagem logo nao precisa mexer
          manipulador.imprimirBits(quadro[i]);
        }else{
          System.out.println("paridade impar: ");
          //insere 1 na posicao apos os bits da mensagem
          quadro[i] = manipulador.adicionarBitNaPosicao(quadro[i],1,25);
          manipulador.imprimirBits(quadro[i]);
        }//Fim else
      }//Fim for
    }else{
      for(int i = 0; i < quadro.length; i++){
        quadro[i] = manipulador.deslocarBits(quadro[i]);
        if((manipulador.quantidadeBits1Inteiro(quadro[i]) - bits1Areduzir) % 2 == 0){
          System.out.println("paridade par ok: ");
          //insere 0 mas ja tem zero no bit posterior a mensagem logo nao precisa mexer
          manipulador.imprimirBits(quadro[i]);
        }else{
          System.out.println("paridade impar: ");
          //insere 1 na posicao apos os bits da mensagem
          quadro[i] = manipulador.adicionarBitNaPosicao(quadro[i],1,25);
          manipulador.imprimirBits(quadro[i]);
        }//fim else
      }//fim for
    }//fim else
    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraControledeErroBitParidadePar

  public int[] camadaEnlaceDadosTransmissoraControleDeErroBitParidadeImpar(int quadro []){
    int bits1Areduzir = 0;
    if(tipoDeEnquadramento == 0){
      bits1Areduzir = 3;
    }else if(tipoDeEnquadramento == 1){
      bits1Areduzir = 10;
    }else if(tipoDeEnquadramento == 2){
      bits1Areduzir = 12;
    }//fim else if

    if(tipoDeEnquadramento == 3){
      int novoQuadro [] = new int[quadro.length];
      int bit =0;
      int mask = 1 << 31;
      int inteiro = 0;
      for(int j = 0; j < quadro.length; j++){ 
        int temp = 0; 
        int contador = 0;
        inteiro = quadro[j];
        inteiro <<= 8;
        System.out.println("-------------------");
        while(contador < 32){
          bit = (inteiro & mask) == 0 ? 0 : 1;
          // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
          // System.out.println("valor bit: " + bit);
          novoQuadro[j] <<= 1;
          novoQuadro[j] = novoQuadro[j] | bit;
          inteiro <<= 2;
          contador++;
        }//Fim while
        System.out.println("eu te falei:");
        manipulador.imprimirBits(novoQuadro[j]);
      }//fim for
      for(int i = 0; i < quadro.length; i++){
        quadro[i] = manipulador.deslocarBits(quadro[i]);
        if((manipulador.quantidadeBits1Inteiro(novoQuadro[i])) % 2 != 0){
          System.out.println("paridade impar ok: ");
          //insere 0 mas ja tem zero no bit posterior a mensagem logo nao precisa mexer
          manipulador.imprimirBits(quadro[i]);
        }else{
          System.out.println("paridade par: ");
          //insere 1 na posicao apos os bits da mensagem
          quadro[i] = manipulador.adicionarBitNaPosicao(quadro[i],1,25);
          manipulador.imprimirBits(quadro[i]);
        }//Fim else
      }//Fim for
    }else{
      for(int i = 0; i < quadro.length; i++){
        quadro[i] = manipulador.deslocarBits(quadro[i]);
        if((manipulador.quantidadeBits1Inteiro(quadro[i]) - bits1Areduzir) % 2 != 0){
          System.out.println("paridade impar ok: ");
          //insere 0 mas ja tem zero no bit posterior a mensagem logo nao precisa mexer
          manipulador.imprimirBits(quadro[i]);
        }else{
          System.out.println("paridade par: ");
          //insere 1 na posicao apos os bits da mensagem
          quadro[i] = manipulador.adicionarBitNaPosicao(quadro[i],1,25);
          manipulador.imprimirBits(quadro[i]);
        }//Fim else
      }//Fim for
    }//fim else
    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraControledeErroBitParidadeImpar


  public int[] CamadaDeEnlaceDadosTransmissoraEnquadramentoContagemDeCaracteres(int quadro []){
    int indiceNvQ = 0;
    int cont = 0;
    int cont2 = 0;
    int inteiro = 0;
    int mask = 1 << 31;
    int bit = 0;
    int novoInteiro = 0;
    int acumulador = 0;
    int qtdIndices = 0;

    int [] informacaoDeControle = new int[quadro.length];

    for(int i = 0; i < quadro.length; i++){
      informacaoDeControle[i] = (manipulador.quantidadeDeBits(quadro[i]))/8;
      acumulador += informacaoDeControle[i];
      // System.out.println("informacao: ");
      // System.out.println(informacaoDeControle[i]);
    }//Fim for

    // System.out.println("--------------enlaceTransmissora------------");
    for(int i = 0; i < quadro.length; i++){
      manipulador.imprimirBits(quadro[i]);
    }
    // System.out.println();

    // System.out.println("valor acumulado: " + acumulador);

    /*if(acumulador > 3){
      while(acumulador > 3){
        acumulador -= 3;
        qtdIndices++;
      }//Fim while
      qtdIndices += 1;
    }else{
      qtdIndices = 1;
    }//Fim else*/

    if(acumulador > 2){
      while(acumulador > 2){
        acumulador -= 2;
        qtdIndices++;
      }//Fim while
      qtdIndices += 1;
    }else{
      qtdIndices = 1;
    }//Fim else

    int[] novoQuadro = new int[qtdIndices];

     // System.out.println("quantidade de indicies: " + qtdIndices);
     // System.out.println("valor do ultimo quadro: " + acumulador);

    for(int a = 0; a < quadro.length; a++){
      // System.out.println("quadros: ");
      manipulador.imprimirBits(quadro[a]);
    }
    // System.out.println("---------------");

    //quadro = manipulador.moverParaEsquerda(quadro);

    for(int m = 0; m < quadro.length; m++){
      quadro[m] = manipulador.deslocarBits(quadro[m]);
      // manipulador.imprimirBits(quadro[m]);
    }// fim for

    // System.out.println("---------------");

    // System.out.println("");
    // System.out.println("NO ENLACE TRANSMISSOR: ");
    // System.out.println("");

    for(int j = 0; j < quadro.length; j++){
      cont = 0;
      inteiro = quadro[j];
      // manipulador.imprimirBits(inteiro);
      while(cont < 32){
        bit = (inteiro & mask) == 0 ? 0 : 1;
        // manipulador.imprimirBits(inteiro);
        // System.out.println("valor bit: " + bit);
        novoInteiro <<= 1;
        novoInteiro = novoInteiro | bit;
        // System.out.println("");
        // System.out.println("inteiro: " + cont);
        // manipulador.imprimirBits(inteiro);
        // System.out.println("");
        // System.out.println("novoInteiro: " + cont2);
        // manipulador.imprimirBits(novoInteiro);
        // System.out.println("");
        inteiro <<= 1;
        cont++;
        cont2++;
        if(cont2 % 16 == 0 && cont2 != 0){

          // System.out.println("quadro que entrou(24): " + manipulador.imprimirBits(novoInteiro));

          //49 em decimal referencia 1 em ascll
          //50 em decimal referencia 2 em ascll
          //51 em decimal referencia 3 em ascll
          if(indiceNvQ == novoQuadro.length - 1){
            if(acumulador == 1){
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 49; //adicionando informacao de controle 1
              // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
            }else if(acumulador == 2){
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 50; //adicionando informacao de controle 2 
              // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
            }else if(acumulador == 3){
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 51; //adicionando informacao de controle 3
              // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
            }//Fim else if
          }else{
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 50; //adicionando informacao de controle 2
            // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
          }//Fim else

          int contador = 0;
          
          // novoInteiro = manipulador.moverParaEsquerdaInteiro(novoInteiro);
          novoInteiro = manipulador.deslocarBits(novoInteiro);

          // System.out.println("Valor do novo inteiro: ");
          // manipulador.imprimirBits(novoInteiro);

          while(contador < 16){
            bit = (novoInteiro & mask) == 0 ? 0 : 1;
            // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }//Fim while

          // System.out.println("quadro que saiu(24): " + manipulador.imprimirBits(novoQuadro[indiceNvQ]));

          if(indiceNvQ < qtdIndices - 1){
            // System.out.println("ENTREI E SUBI O INDICE");
            indiceNvQ += 1;
          }else{
            // System.out.println("ultimo quadro codificado break");
            break;
          }//Fim else
          novoInteiro = 0;
          cont2 = 0;
          // System.out.println("VALOR DO CONT: " + cont);
        }//Fim if
        if(cont == 32 && j == quadro.length - 1 && novoInteiro != 0){
          // System.out.println("quadro que entrou(32): " + manipulador.imprimirBits(novoInteiro));
          int contador = 0;
          if(acumulador == 1){
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 49; //adicionando informacao de controle 1
            // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
          }else if(acumulador == 2){
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 50; //adicionando informacao de controle 2 
            // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
          }else if(acumulador == 3){
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 51; //adicionando informacao de controle 3
            // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
          }//Fim else if
          novoInteiro = manipulador.deslocarBits(novoInteiro);
          // System.out.println("Valor do novo inteiro: ");
          // manipulador.imprimirBits(novoInteiro);

          while(contador < (acumulador * 8)){
            bit = (novoInteiro & mask) == 0 ? 0 : 1;
            // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }//Fim while
          // System.out.println("antes: ");
          // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
          // System.out.println("depois: ");
          if(acumulador * 8 == 8){
            novoQuadro[indiceNvQ] <<= 16;
          }else if(acumulador * 8 == 16){
            novoQuadro[indiceNvQ] <<= 8;
          }//Fim else if
          // System.out.println("quadro que saiu(32): " + manipulador.imprimirBits(novoQuadro[indiceNvQ]));
          // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
        }//Fim if
      }//Fim while
    }//Fim for
    System.out.println("novo quadro na enlace transmissora: ");
    for(int i =0; i < novoQuadro.length; i++){
       manipulador.imprimirBits(novoQuadro[i]);
    }//FIm for

   return novoQuadro;
  }//Fim metodo CamadaDeEnlaceDadosTransmissoraEnquadramentoContagemDeCaracteres

  public int[] CamadaDeEnlaceDadosTransmissoraEnquadramentoInsercaoDeBytes (int quadro []) {
    int indiceNvQ = 0;
    int cont = 0;
    int cont2 = 0;
    int inteiro = 0;
    int mask = 1 << 31;
    int bit = 0;
    int novoInteiro = 0;
    int acumulador = 0;
    int qtdIndices = 0;

    //se achar o byte de flag dentro da mensagem adiciona um escape
    //se achar o byte de escape dentro da mensagem adiciona outro escape
    // byte de flag = a
    // byte de escape = esc

    int [] informacaoDeControle = new int[quadro.length];

    for(int i = 0; i < quadro.length; i++){
      informacaoDeControle[i] = (manipulador.quantidadeDeBits(quadro[i]))/8;
      acumulador += informacaoDeControle[i];
      // System.out.println("informacao: ");
      // System.out.println(informacaoDeControle[i]);
    }//Fim for

    System.out.println("--------------enlaceTransmissora------------");
    for(int i = 0; i < quadro.length; i++){
      manipulador.imprimirBits(quadro[i]);
    }
    System.out.println();

    // System.out.println("valor acumulado: " + acumulador);

    /*if(acumulador > 2){
      while(acumulador > 2){
        acumulador -= 2;
        qtdIndices++;
      }//Fim while
      qtdIndices += 1;
    }else{
      qtdIndices = 1;
    }//Fim else*/

    qtdIndices = acumulador;

    int[] novoQuadro = new int[acumulador];

     // System.out.println("quantidade de indicies: " + qtdIndices);
     // System.out.println("valor do ultimo quadro: " + acumulador);

    for(int a = 0; a < quadro.length; a++){
      // System.out.println("quadros: ");
      manipulador.imprimirBits(quadro[a]);
    }
    // System.out.println("---------------");

    //quadro = manipulador.moverParaEsquerda(quadro);

    for(int m = 0; m < quadro.length; m++){
      quadro[m] = manipulador.deslocarBits(quadro[m]);
      // manipulador.imprimirBits(quadro[m]);
    }// fim for

    // System.out.println("---------------");

    // System.out.println("");
    // System.out.println("NO ENLACE TRANSMISSOR: ");
    // System.out.println("");

    for(int j = 0; j < quadro.length; j++){
      cont = 0;
      inteiro = quadro[j];
      // manipulador.imprimirBits(inteiro);
      while(cont < 32){
        bit = (inteiro & mask) == 0 ? 0 : 1;
        // manipulador.imprimirBits(inteiro);
        // System.out.println("valor bit: " + bit);
        novoInteiro <<= 1;
        novoInteiro = novoInteiro | bit;
        // System.out.println("");
        // System.out.println("inteiro: " + cont);
        // manipulador.imprimirBits(inteiro);
        // System.out.println("");
        // System.out.println("novoInteiro: " + cont2);
        // manipulador.imprimirBits(novoInteiro);
        // System.out.println("");
        inteiro <<= 1;
        cont++;
        cont2++;
        if(cont2 % 8 == 0 && cont2 != 0){
          // System.out.println("quadro que entrou(24): " + manipulador.imprimirBits(novoInteiro));

          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 31;

          int contador = 0;
          
          // novoInteiro = manipulador.moverParaEsquerdaInteiro(novoInteiro);
          novoInteiro = manipulador.deslocarBits(novoInteiro);

          // System.out.println("Valor do novo inteiro: ");
          // manipulador.imprimirBits(novoInteiro);

          while(contador < 8){
            bit = (novoInteiro & mask) == 0 ? 0 : 1;
            // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }//Fim while
          int flag = 31;
          contador = 0;
          // System.out.println("quadro que saiu(24): " + manipulador.imprimirBits(novoQuadro[indiceNvQ]));
          flag = manipulador.deslocarBits(flag);
          System.out.println("valor do flag: ");
          manipulador.imprimirBits(flag);
          System.out.println();
          while(contador < 8){
            bit = (flag & mask) == 0 ? 0 : 1;
            // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            flag <<= 1;
            contador++;
            System.out.println("flag final : ");
            manipulador.imprimirBits(novoQuadro[indiceNvQ]);
          }//Fim while

          novoQuadro[indiceNvQ] <<= 8;

          if(indiceNvQ < qtdIndices - 1){
            // System.out.println("ENTREI E SUBI O INDICE");
            indiceNvQ += 1;
          }else{
            // System.out.println("ultimo quadro codificado break");
            break;
          }//Fim else
          novoInteiro = 0;
          cont2 = 0;
        }//Fim else if
        if(cont == 32 && j == quadro.length - 1 && novoInteiro != 0){
          // System.out.println("quadro que entrou(32): " + manipulador.imprimirBits(novoInteiro));
          int contador = 0;
          
          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 31; // inserindo bit de flag no começo

          novoInteiro = manipulador.deslocarBits(novoInteiro);
          // System.out.println("Valor do novo inteiro: ");
          // manipulador.imprimirBits(novoInteiro);

          while(contador < 8){
            bit = (novoInteiro & mask) == 0 ? 0 : 1;
            // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }//Fim while

          int flag = 31;
          contador = 0;
          // System.out.println("quadro que saiu(24): " + manipulador.imprimirBits(novoQuadro[indiceNvQ]));
          flag = manipulador.deslocarBits(flag);
          System.out.println("valor do flag: ");
          manipulador.imprimirBits(flag);
          System.out.println();
          while(contador < 8){
            bit = (flag & mask) == 0 ? 0 : 1;
            // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            flag <<= 1;
            contador++;
            System.out.println("flag final : ");
            manipulador.imprimirBits(novoQuadro[indiceNvQ]);
          }//Fim while

          // System.out.println("antes: ");
          // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
          // System.out.println("depois: ");
          novoQuadro[indiceNvQ] <<= 8;

          System.out.println("cont 32 quadro: ");
          manipulador.imprimirBits(novoQuadro[indiceNvQ]);

          // System.out.println("quadro que saiu(32): " + manipulador.imprimirBits(novoQuadro[indiceNvQ]));
          // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
        }//Fim if
      }//Fim while
    }//Fim for
    System.out.println("novo quadro na enlace transmissora: ");

    for(int i =0; i < novoQuadro.length; i++){
       manipulador.imprimirBits(novoQuadro[i]);
    }//FIm for

    return novoQuadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraInsercaoDeBytes
  public int[] CamadaDeEnlaceDadosTransmissoraEnquadramentoInsercaoDeBits (int quadro []) {
    int indiceNvQ = 0;
    int cont = 0;
    int cont2 = 0;
    int inteiro = 0;
    int mask = 1 << 31;
    int bit = 0;
    int novoInteiro = 0;
    int acumulador = 0;
    int qtdIndices = 0;

    //se achar o byte de flag dentro da mensagem adiciona um escape
    //se achar o byte de escape dentro da mensagem adiciona outro escape
    // byte de flag = a
    // byte de escape = esc

    int [] informacaoDeControle = new int[quadro.length];

    for(int i = 0; i < quadro.length; i++){
      informacaoDeControle[i] = (manipulador.quantidadeDeBits(quadro[i]))/8;
      acumulador += informacaoDeControle[i];
      // System.out.println("informacao: ");
      // System.out.println(informacaoDeControle[i]);
    }//Fim for

    System.out.println("--------------enlaceTransmissora------------");
    for(int i = 0; i < quadro.length; i++){
      manipulador.imprimirBits(quadro[i]);
    }
    System.out.println();

    // System.out.println("valor acumulado: " + acumulador);

    /*if(acumulador > 2){
      while(acumulador > 2){
        acumulador -= 2;
        qtdIndices++;
      }//Fim while
      qtdIndices += 1;
    }else{
      qtdIndices = 1;
    }//Fim else*/

    qtdIndices = acumulador;

    int[] novoQuadro = new int[acumulador];

     // System.out.println("quantidade de indicies: " + qtdIndices);
     // System.out.println("valor do ultimo quadro: " + acumulador);

    for(int a = 0; a < quadro.length; a++){
      // System.out.println("quadros: ");
      manipulador.imprimirBits(quadro[a]);
    }
    // System.out.println("---------------");

    //quadro = manipulador.moverParaEsquerda(quadro);

    for(int m = 0; m < quadro.length; m++){
      quadro[m] = manipulador.deslocarBits(quadro[m]);
      // manipulador.imprimirBits(quadro[m]);
    }// fim for

    // System.out.println("---------------");

    // System.out.println("");
    // System.out.println("NO ENLACE TRANSMISSOR: ");
    // System.out.println("");

    for(int j = 0; j < quadro.length; j++){
      cont = 0;
      inteiro = quadro[j];
      // manipulador.imprimirBits(inteiro);
      while(cont < 32){
        bit = (inteiro & mask) == 0 ? 0 : 1;
        // manipulador.imprimirBits(inteiro);
        // System.out.println("valor bit: " + bit);
        novoInteiro <<= 1;
        novoInteiro = novoInteiro | bit;
         System.out.println("");
         System.out.println("inteiro: " + cont);
         manipulador.imprimirBits(inteiro);
         System.out.println("");
         System.out.println("novoInteiro: " + cont2);
         manipulador.imprimirBits(novoInteiro);
         System.out.println("");
        inteiro <<= 1;
        cont++;
        cont2++;
        if(cont2 % 8 == 0 && cont2 != 0){
          System.out.println("quadro que entrou(24): " + manipulador.imprimirBits(novoInteiro));

          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 126;
          int contador = 0;
          
          // novoInteiro = manipulador.moverParaEsquerdaInteiro(novoInteiro);
          novoInteiro = manipulador.deslocarBits(novoInteiro);

          // System.out.println("Valor do novo inteiro: ");
          // manipulador.imprimirBits(novoInteiro);

          int contaUm = 0;

          // novoQuadro[indiceNvQ] <<= 1;
          // novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 0;

          if(manipulador.cincoBitsSequenciais(novoInteiro,1) == true){
            novoQuadro[indiceNvQ] <<= 7;
            while(contador < 8){
              bit = (novoInteiro & mask) == 0 ? 0 : 1;
              // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
              // System.out.println("valor bit: " + bit);
              novoQuadro[indiceNvQ] <<= 1;
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
              novoInteiro <<= 1;
              contador++;
              if(bit == 1){
                contaUm++;
                if(contaUm == 5){
                  novoQuadro[indiceNvQ] <<= 1;
                  novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 0;
                  contaUm = 0;
                }//Fim if
              }//Fim if
            }//Fim while
          }else{
            while(contador < 8){
              bit = (novoInteiro & mask) == 0 ? 0 : 1;
              // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
              // System.out.println("valor bit: " + bit);
              novoQuadro[indiceNvQ] <<= 1;
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
              novoInteiro <<= 1;
              contador++;
            }//Fim while
          }//fim else

          int flag = 126;
          contador = 0;
          // System.out.println("quadro que saiu(24): " + manipulador.imprimirBits(novoQuadro[indiceNvQ]));
          flag = manipulador.deslocarBits(flag);
          System.out.println("valor do flag: ");
          manipulador.imprimirBits(flag);
          System.out.println();
          while(contador < 8){
            bit = (flag & mask) == 0 ? 0 : 1;
            // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            flag <<= 1;
            contador++;
            System.out.println("flag final : ");
            manipulador.imprimirBits(novoQuadro[indiceNvQ]);
          }//Fim while

          // manipulador.deslocarBits(novoQuadro[indiceNvQ]);

          if(indiceNvQ < qtdIndices - 1){
            // System.out.println("ENTREI E SUBI O INDICE");
            indiceNvQ += 1;
          }else{
            System.out.println("ultimo quadro codificado break");
            break;
          }//Fim else
          novoInteiro = 0;
          cont2 = 0;
        }//Fim if
        if(cont == 32 && j == quadro.length - 1 && novoInteiro != 0){
          // System.out.println("quadro que entrou(32): " + manipulador.imprimirBits(novoInteiro));
          int contador = 0;
          
          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 126; // inserindo bit de flag no começo
          novoInteiro = manipulador.deslocarBits(novoInteiro);
          // System.out.println("Valor do novo inteiro: ");
          // manipulador.imprimirBits(novoInteiro);

          int contaUm = 0;

          if(manipulador.cincoBitsSequenciais(novoInteiro,1) == true){
            novoQuadro[indiceNvQ] <<= 7;
            while(contador < 8){
              bit = (novoInteiro & mask) == 0 ? 0 : 1;
              // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
              // System.out.println("valor bit: " + bit);
              novoQuadro[indiceNvQ] <<= 1;
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
              novoInteiro <<= 1;
              
              contador++;
              if(bit == 1){
                contaUm++;
                if(contaUm == 5){
                  novoQuadro[indiceNvQ] <<= 1;
                  novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 0;
                  contaUm = 0;
                }//Fim if
              }//Fim if
            }//Fim while
          }else{
            while(contador < 8){
              bit = (novoInteiro & mask) == 0 ? 0 : 1;
              // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
              // System.out.println("valor bit: " + bit);
              novoQuadro[indiceNvQ] <<= 1;
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
              novoInteiro <<= 1;
              contador++;
            }//Fim while
          }//fim else

          int flag = 126;
          contador = 0;
          // System.out.println("quadro que saiu(24): " + manipulador.imprimirBits(novoQuadro[indiceNvQ]));
          flag = manipulador.deslocarBits(flag);
          System.out.println("valor do flag: ");
          manipulador.imprimirBits(flag);
          System.out.println();
          while(contador < 8){
            bit = (flag & mask) == 0 ? 0 : 1;
            // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            flag <<= 1;
            contador++;
            System.out.println("flag final : ");
            manipulador.imprimirBits(novoQuadro[indiceNvQ]);
          }//Fim while

          // System.out.println("antes: ");
          // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
          // System.out.println("depois: ");
          
          novoQuadro[indiceNvQ] <<= 8;

          System.out.println("cont 32 quadro: ");
          manipulador.imprimirBits(novoQuadro[indiceNvQ]);

          // System.out.println("quadro que saiu(32): " + manipulador.imprimirBits(novoQuadro[indiceNvQ]));
          // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
        }//Fim if
      }//Fim while
    }//Fim for
    System.out.println("novo quadro na enlace transmissora: ");

    for(int i =0; i < novoQuadro.length; i++){
      novoQuadro[i] = manipulador.deslocarBits(novoQuadro[i]);
      manipulador.imprimirBits(novoQuadro[i]);
    }//FIm for

    return novoQuadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraInsercaoDeBits
  public int[] CamadaDeEnlaceDadosTransmissoraEnquadramentoViolacaoDaCamadaFisica(int quadro []) {

    int indiceNvQ = 0;
    int cont = 0;
    int cont2 = 0;
    int inteiro = 0;
    int mask = 1 << 31;
    int bit = 0;
    int novoInteiro = 0;
    int acumulador = 0;
    int qtdIndices = 0;

    int [] informacaoDeControle = new int[quadro.length];

    for(int i = 0; i < quadro.length; i++){
      informacaoDeControle[i] = (manipulador.quantidadeDeBits(quadro[i]))/8;
      acumulador += informacaoDeControle[i];
      // System.out.println("informacao: ");
      // System.out.println(informacaoDeControle[i]);
    }//Fim for

    System.out.println("--------------enlaceTransmissora------------");
    for(int i = 0; i < quadro.length; i++){
      manipulador.imprimirBits(quadro[i]);
    }
    System.out.println();

    // System.out.println("valor acumulado: " + acumulador);

    /*if(acumulador > 2){
      while(acumulador > 2){
        acumulador -= 2;
        qtdIndices++;
      }//Fim while
      qtdIndices += 1;
    }else{
      qtdIndices = 1;
    }//Fim else*/

    qtdIndices = acumulador;

    int[] novoQuadro = new int[acumulador];

     // System.out.println("quantidade de indicies: " + qtdIndices);
     // System.out.println("valor do ultimo quadro: " + acumulador);

    for(int a = 0; a < quadro.length; a++){
      // System.out.println("quadros: ");
      manipulador.imprimirBits(quadro[a]);
    }
    // System.out.println("---------------");

    //quadro = manipulador.moverParaEsquerda(quadro);

    for(int m = 0; m < quadro.length; m++){
      quadro[m] = manipulador.deslocarBits(quadro[m]);
      // manipulador.imprimirBits(quadro[m]);
    }// fim for

    // System.out.println("---------------");

    // System.out.println("");
    // System.out.println("NO ENLACE TRANSMISSOR: ");
    // System.out.println("");

    for(int j = 0; j < quadro.length; j++){
      cont = 0;
      inteiro = quadro[j];
      // manipulador.imprimirBits(inteiro);
      while(cont < 32){
        bit = (inteiro & mask) == 0 ? 0 : 1;
        // manipulador.imprimirBits(inteiro);
        // System.out.println("valor bit: " + bit);
        novoInteiro <<= 1;
        novoInteiro = novoInteiro | bit;
         System.out.println("");
         System.out.println("inteiro: " + cont);
         manipulador.imprimirBits(inteiro);
         System.out.println("");
         System.out.println("novoInteiro: " + cont2);
         manipulador.imprimirBits(novoInteiro);
         System.out.println("");
        inteiro <<= 1;
        cont++;
        cont2++;
        if(cont2 % 8 == 0 && cont2 != 0){
          System.out.println("quadro que entrou(24): " + manipulador.imprimirBits(novoInteiro));

          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 3; //adiciona 11 para limitar o inicio do quadro
          int contador = 0;
          
          // novoInteiro = manipulador.moverParaEsquerdaInteiro(novoInteiro);
          novoInteiro = manipulador.deslocarBits(novoInteiro);

          System.out.println("Valor do novo inteiro: ");
          manipulador.imprimirBits(novoInteiro);

          int contaUm = 0;

          // novoQuadro[indiceNvQ] <<= 1;
          // novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 0;

          novoQuadro[indiceNvQ] <<= 6;

          while(contador < 8){
            bit = (novoInteiro & mask) == 0 ? 1 : 2;
            // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[indiceNvQ] <<= 2;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }//Fim while

          novoQuadro[indiceNvQ] <<= 8;

          // manipulador.deslocarBits(novoQuadro[indiceNvQ]);

          if(indiceNvQ < qtdIndices - 1){
            // System.out.println("ENTREI E SUBI O INDICE");
            indiceNvQ += 1;
          }else{
            System.out.println("ultimo quadro codificado break");
            break;
          }//Fim else
          novoInteiro = 0;
          cont2 = 0;
        }//Fim if
        if(cont == 32 && j == quadro.length - 1 && novoInteiro != 0){
          System.out.println("quadro que entrou(32): " + manipulador.imprimirBits(novoInteiro));

          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 3;
          int contador = 0;
          
          // novoInteiro = manipulador.moverParaEsquerdaInteiro(novoInteiro);
          novoInteiro = manipulador.deslocarBits(novoInteiro);

          // System.out.println("Valor do novo inteiro: ");
          // manipulador.imprimirBits(novoInteiro);

          int contaUm = 0;

          novoQuadro[indiceNvQ] <<= 8;

          while(contador < 8){
            bit = (novoInteiro & mask) == 0 ? 1 : 2;
            // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[indiceNvQ] <<= 2;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }//Fim while

          novoQuadro[indiceNvQ] <<= 8;

          // manipulador.deslocarBits(novoQuadro[indiceNvQ]);

          if(indiceNvQ < qtdIndices - 1){
            // System.out.println("ENTREI E SUBI O INDICE");
            indiceNvQ += 1;
          }else{
            System.out.println("ultimo quadro codificado break");
            break;
          }//Fim else
          novoInteiro = 0;
          cont2 = 0;
          System.out.println("cont 32 quadro: ");
          manipulador.imprimirBits(novoQuadro[indiceNvQ]);

          // System.out.println("quadro que saiu(32): " + manipulador.imprimirBits(novoQuadro[indiceNvQ]));
          // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
        }//Fim if
      }//Fim while
    }//Fim for
    System.out.println("novo quadro na enlace transmissora: ");

    for(int i =0; i < novoQuadro.length; i++){
      novoQuadro[i] = manipulador.deslocarBits(novoQuadro[i]);
      manipulador.imprimirBits(novoQuadro[i]);
    }//FIm for

    return novoQuadro;

  }//fim do metodo CamadaEnlaceDadosTransmissoraViolacaoDaCamadaFisica

  /*public void setControlador (Controlador controlador){
    control = controlador;
  }//fim metodo setControlador*/

}//fim classe CamadaEnlaceDadosTransmissora

/*
comentarios que podem ser uteis

if(j == quadro.length - 1){
        //aqui sera adicionado o tamanho da mensagem e os caracteres que tiverem
        while(quadro[j] > 0){
          tamanhoMensagem += 1;
          if((quadro[j] & mask) == 0){
            System.out.println("0");
            cont += 1;
          }//Fim if
          else if((quadro[j] & mask) == 1){
            System.out.println("1");
            cont += 1;
          }//Fim else if
          quadro[j] = quadro[j] >> 1;
        }//Fim while
        System.out.println("cont : " + cont + " vezes");
      }else{
        //aqui sera adicionado a informação de controle e os 3 caracteres*/