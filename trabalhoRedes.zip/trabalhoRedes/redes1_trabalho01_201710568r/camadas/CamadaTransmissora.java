package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static controlador.Controlador.tipoDeDecodificacao;

/*********************************************
Nome: Tharcio Thalles Almeida Silva
Data de inicio: 02 12 2018
data de termino: 15 12 2018
objetivo: simular a camada fisica de redes
********************************************/

public class CamadaTransmissora{
  Controlador control;

  public CamadaTransmissora(){
    
  }//Fim metodo construtor CamadaTransmissora

  /*public void CamadaDeAplicacaoTransmissora(String mensagem){ 

    CamadaFisicaTransmissora(quadro);
  }*///Fim metodo CamadaDeAplicacaoTransmissora

  /*public void CamadaFisicaTransmissora(int quadro[]) {
    int fluxoBrutoDeBits[];
    switch (tipoDeDecodificacao) {
      case 0 : //codificao binaria
        fluxoBrutoDeBits = CamadaFisicaTransmissoraCodificacaoBinaria(quadro);
        control.meioDeComunicacao(fluxoBrutoDeBits);
        break;
      case 1 : //codificacao manchester
        fluxoBrutoDeBits = CamadaFisicaTransmissoraCodificacaoManchester(quadro);
        control.meioDeComunicacao(fluxoBrutoDeBits);
        break;
      case 2 : //codificacao manchester diferencial
        fluxoBrutoDeBits = CamadaFisicaTransmissoraCodificacaoManchesterDiferencial(quadro);
        control.meioDeComunicacao(fluxoBrutoDeBits);
        break;
    }//fim do switch/case
  }//fim metodo CamadaFisicaTransmissora

  public int[] CamadaFisicaTransmissoraCodificacaoBinaria(int quadro[]){

  }//fim do metodo CamadaFisicaTransmissoraCodificacaoBinaria

  public int[] CamadaFisicaTransmissoraCodificacaoManchester (int quadro []) {
    //implementacao do algoritmo para CODIFICAR

  }//fim do metodo CamadaFisicaTransmissoraCodificacaoManchester
  
  public int[] CamadaFisicaTransmissoraCodificacaoManchesterDiferencial(int quadro[]){
    //implementacao do algoritmo para CODIFICAR
    
  }//fim do metodo CamadaFisicaTransmissoraCodificacaoManchesterDiferencial*/

  public void setControlador(Controlador controle){
    control = controle;
  }//Fim setControlador
}//Fim classe