package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static controlador.Controlador.tipoDeDecodificacao;

public class CamadaDeAplicacaoReceptora{

  AplicacaoReceptora aplicacaoReceptora = new AplicacaoReceptora();
  ManipuladorDeBit manipulador = new ManipuladorDeBit();

  public void camadaAplicacaoReceptora(int quadro[]){
    System.out.println("NA CAMADA DE APLICACAO RECEPTORA");
    int n = 0;
    int c = 0;
    int j = 0;
    
    String mensagem = "";
    String mensagemf = "";
    int inteiro = 0;

    while(n < quadro.length * 4){
      inteiro = manipulador.getPrimeiroByte(quadro[j]);
      if(inteiro != 0){
        manipulador.imprimirBits(inteiro);
        quadro[j] <<= 8;
        mensagem += (char) inteiro;
        System.out.println("mensagem: " + mensagem);
        System.out.println("valor n: " + n);
        n++;
        if(n != 0 && n % 4 == 0){
          System.out.println("entrei e subi o valor j : " + mensagemf );
          if(j < quadro.length - 1){
            j++;
          }//Fim if
        }//Fim if
      }//Fim if
      else{
        quadro[j] <<= 8;
        n++;
        if(n != 0 && n % 4 == 0){
          System.out.println("entrei e subi o valor j : " + mensagemf );
          if(j < quadro.length - 1){
            j++;
          }//Fim if
        }//Fim if
      }//Fim else
    }//Fim while
    System.out.println("VALOR N:" + n);
    aplicacaoReceptora.aplicacaoReceptora(mensagem);      
  }//Fim metodo camadaAplicacaoReceptora

}//Fim classe CamadaDeAplicacaoReceptora