package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
// import static controlador.Controlador.tipoDeDecodificacao;

public class CamadaDeAplicacaoReceptora{

  AplicacaoReceptora aplicacaoReceptora = new AplicacaoReceptora();
  //AplicacaoTransmissora aplicacaoTrans  = new AplicacaoTransmissora();
  MetodosBit manipulador = new MetodosBit();
  Controlador control;

  public void camadaAplicacaoReceptora(int quadro[]){
    System.out.println("NA CAMADA DE APLICACAO RECEPTORA");
    int n = 0;
    int c = 0;
    int j = 0;
    
    String mensagem = "";
    String mensagemf = "";
    int inteiro = 0;

    for(int i = 0; i < quadro.length; i++){
      manipulador.imprimirBits(quadro[i]);
    }//fim for
    System.out.println();
    System.out.println("----------------");

    while(n < quadro.length * 4){
      inteiro = manipulador.getPrimeiroByte(quadro[j]);
      if(inteiro != 0){
        manipulador.imprimirBits(inteiro);
        quadro[j] <<= 8;
        mensagem += (char) inteiro;
        n++;
        System.out.println("mensagem: " + mensagem);
        System.out.println("valor n: " + n);
        if(n != 0 && n % 4 == 0){
          System.out.println("entrei e subi o valor j : " + mensagemf );
          if(j < quadro.length - 1){
            j++;
          }//Fim if
        }//Fim if
      }//Fim if
      else{
        quadro[j] <<= 8;
        n++;
        System.out.println("valor n2: " + n);
        if(n != 0 && n % 4 == 0){
          System.out.println("entrei e subi o valor j2 : " + mensagemf );
          if(j < quadro.length - 1){
            j++;
          }//Fim if
        }//Fim if
      }//Fim else
    }//Fim while
    System.out.println("VALOR N:" + n);
    aplicacaoReceptora.aplicacaoReceptora(mensagem);      
  }//Fim metodo camadaAplicacaoReceptora

  /*public void aplicacaoReceptora(String mensagem){
    System.out.println("CAMADA DE APLICACAO");
    System.out.println(mensagem);
    control.mensagem.getText();
    // control.mensagemRecebida.setText(mensagem);
    // control.mensagemRecebidaTela.setText(mensagem);//fica na tv do gato
  }//Fim metodo aplicacaoReceptora*/

  public void setControlador(Controlador controlador){
    control = controlador;
  }//Fim metodo setControlador

}//Fim classe CamadaDeAplicacaoReceptora