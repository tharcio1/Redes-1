package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static controlador.Controlador.tipoDeDecodificacao;


/*********************************************
Nome: Tharcio Thalles Almeida Silva
Data de inicio: 02 12 2018
data de termino: 15 12 2018
objetivo: simular a camada fisica de redes
********************************************/

public class CamadaReceptora{
  Controlador control;

  public CamadaReceptora(){
    
  }//Fim metodo construtor CamadaReceptora

  /*public void camadaFisicaReceptora(int quadro[]) {
    int fluxoBrutoDeBits[];
    switch (tipoDeDecodificacao) {
      case 0 : //decodificao binaria
        fluxoBrutoDeBits = camadaFisicaReceptoraDecodificacaoBinaria(quadro);
        camadaDeAplicacaoReceptora(fluxoBrutoDeBits);
        break;
      case 1 : //decodificacao manchester
        fluxoBrutoDeBits = camadaFisicaReceptoraDecodificacaoManchester(quadro);
        camadaDeAplicacaoReceptora(fluxoBrutoDeBits);
        break;
      case 2 : //codificacao manchester diferencial
        fluxoBrutoDeBits = camadaFisicaReceptoraDecodificacaoManchesterDiferencial(quadro);
        camadaDeAplicacaoReceptora(fluxoBrutoDeBits);
        break;
    }//fim do switch case
  }//fim metodo CamadaFisicaReceptora*/

  /*public void camadaDeAplicacaoReceptora(int quadro[]){ 
    
    aplicacaoReceptora(mensagem);
  }//Fim metodo camadaDeAplicacaoReceptora

  public void aplicacaoReceptora(String mensagem){
    control.mensagemRecebida.setText(mensagem);
    control.mensagemRecebidaTela.setText(mensagem);
  }//Fim metodo aplicacaoReceptora

  public int[] camadaFisicaReceptoraDecodificacaoBinaria(int quadro[]){
    //implementacao do algoritmo para decodificar
  
  }//Fim metodo CamadaFisicaReceptoraCodificacaoBinaria
 
  public int[] camadaFisicaReceptoraDecodificacaoManchester(int quadro[]){
    //implementacao do algoritmo para decodificar

  }//Fim metodo camadaFisicaReceptoraDecodificacaoManchester

  public int[] camadaFisicaReceptoraDecodificacaoManchesterDiferencial(int quadro[]){
    //implementacao do algoritmo para decodificar
  }//Fim metodo camadaFisicaReceptoraDecodificacaoManchesterDiferencial*/

  public void setControlador(Controlador controle){
    control = controle;
  }//Fim setControlador

}//Fim classe CamadaReceptora