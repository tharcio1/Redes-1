package camadas;
import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;

public class CamadaEnlaceDadosReceptora{
  // Controlador control;
  CamadaDeAplicacaoReceptora camadaApliReceptora = new CamadaDeAplicacaoReceptora(); 
  MetodosBit manipulador = new MetodosBit();
  int tipoDeEnquadramento = 3; //alterar de acordo com o teste
  int tipoDeControleDeErro = 2; //alterar de acordo com o teste

  public CamadaEnlaceDadosReceptora(){
    
  }//Fim metodo construtor

  public void CamadaEnlaceDadosReceptora(int quadro[]){
    int quadroEnquadrado [];

    quadroEnquadrado = camadaEnlaceDadosReceptoraEnquadramento(quadro); 
    quadroEnquadrado = camadaEnlaceDadosReceptoraControleDeErro(quadroEnquadrado);
    //CamadaDeEnlaceDadosReceptoraControleDeFluxo(quadro);

    camadaApliReceptora.camadaAplicacaoReceptora(quadroEnquadrado);
  }//fim metodo CamadaEnlanceDadosTransmissora
  
  public int[] camadaEnlaceDadosReceptoraEnquadramento(int quadro[]){
    int[] quadroEnquadrado;
    switch (tipoDeEnquadramento) {
      case 0 : //contagem de caracteres
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoContagemDeCaracteres(quadro);
        return quadroEnquadrado;
      case 1 : //insercao de bytes
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBytes(quadro);
        return quadroEnquadrado;
      case 2 : //insercao de bits
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBits(quadro);
        return quadroEnquadrado;
      case 3 : //violacao da camada fisica
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoViolacaoDaCamadaFisica(quadro);
        return quadroEnquadrado;
    }//fim do switch/case
    return quadro;
  }//fim do metodo CamadaEnlaceTransmissoraEnquadramento

  public int[] camadaEnlaceDadosReceptoraControleDeErro (int quadro []) {
    int quadroNovo [];
    switch (tipoDeControleDeErro) {
      case 0 : //bit de paridade par
        quadroNovo = camadaEnlaceDadosReceptoraControleDeErroBitDeParidadePar(quadro);
        return quadroNovo;
      case 1 : //bit de paridade impar
        quadroNovo = camadaEnlaceDadosReceptoraControleDeErroBitDeParidadeImpar(quadro);
        return quadroNovo;
      case 2 : //CRC
        quadroNovo = camadaEnlaceDadosReceptoraControleDeErroCRC(quadro);
        return quadroNovo;
      case 3 : //codigo de hamming
        return quadro; // colocar quadro novo
    }//fim do switch/case
      return quadro; 
  }//fim do metodo CamadaEnlaceDadosReceptoraControleDeErro


 public int[] camadaEnlaceDadosReceptoraControleDeErroCRC(int quadro[]){
  System.out.println("dentro da camada de crc: ");
  for(int i = 0; i < quadro.length; i++){
    manipulador.imprimirBits(quadro[i]);
  }
  System.out.println("-------------------------------");
   int crc32 = manipulador.devolveCrc(); // correspondente ao valor decimal do binario do crc32
   int resto = 0;
   int inteiro = 0;
   int bit = 0;
   boolean verif = false;
   int cont = 0;
   int quadrosCRC [] = new int[quadro.length/2];

   for(int i = 0; i < quadro.length; i++){
    if(i % 2 == 0){
      resto = 0;
      crc32 = manipulador.devolveCrc(); // correspondente ao valor decimal do binario do crc32
      int contador = 0;
      inteiro = quadro[i];
      verif = false;
      if((manipulador.pegarBitNaPosicao(inteiro,0)) == 0){
        inteiro <<= 1; //comecando do primeiro bit mais redundante
        verif = true;
      }//Fim if
      contador = 0;
      while(contador < 32){
        // System.out.println("posicao 0: " + manipulador.pegarBitNaPosicao(inteiro,0));
        // System.out.println("posicao 1: " + manipulador.pegarBitNaPosicao(inteiro,1));
        // manipulador.imprimirBits(inteiro);
        bit = ((manipulador.pegarBitNaPosicao(inteiro,0)) ^ (manipulador.pegarBitNaPosicao(crc32,0))) == 0 ? 0:1;
        // System.out.println("VALOR BIT: " + bit + " valores do bit: " + manipulador.pegarBitNaPosicao(inteiro,0) + " xor " + (manipulador.pegarBitNaPosicao(crc32,0)));
        resto <<= 1;
        resto |= bit;
        // System.out.println("valor do resto: ");
        // manipulador.imprimirBits(resto);
        // System.out.println("valor inteiro: ");
        // manipulador.imprimirBits(inteiro);
        // System.out.println("valor crcd : ");
        // manipulador.imprimirBits(crc32);
        // System.out.println("valor do resto: ");
        // manipulador.imprimirBits(resto);
        crc32 <<= 1;
        inteiro <<= 1;
        contador++;
        if(verif == true && contador == 31){
          bit = manipulador.pegarBitNaPosicao(crc32,0);
          resto <<= 1;
          resto |= bit;
          quadrosCRC[cont] = resto;
          cont++;
          break;
        }//Fim if
      }//Fim while
      if(verif == false){ 
        System.out.println("aqui");
        // manipulador.imprimirBits(quadrosCRC[c]);
        // manipulador.imprimirBits(resto);
        System.out.println("-------------------------");
        quadrosCRC[i] = resto;
        break;
      }//fim if
    }//Fim if
  }//Fim for
  int quadrosCrcOriginal [] = new int [quadrosCRC.length];
  int contCrc = 0;
  System.out.println("crc: ");
  for(int l = 0; l < quadrosCRC.length ; l++){
    manipulador.imprimirBits(quadrosCRC[l]);
  }//Fim for
  System.out.println("----------------------------- separacao de crcs -----------------------------");
  for(int i =0; i < quadro.length; i++){
    if(i % 2 != 0){
      manipulador.imprimirBits(quadro[i]);
      quadrosCrcOriginal[contCrc] = quadro[i]; //resto gerado na divisao do transmissor
      contCrc++;
    }//fim if
  }//Fim for

  int inteiroCrc1 = 0; //crc gerado na transmissora
  int inteiroCrc2 = 0; //crc gerado na receptora
  int contaIndice = 0;
  int indiceQuadro= 0;
  int quadrosAtransmitir [] = new int[quadro.length];
  for(int i = 0; i < quadrosCRC.length;i++){
    int contador = 0;
    resto        = 0;
    inteiroCrc1  = quadrosCrcOriginal[i];
    inteiroCrc2  = quadrosCRC[i];
    while(contador < 32){
      // System.out.println("posicao 0: " + manipulador.pegarBitNaPosicao(inteiro,0));
      // System.out.println("posicao 1: " + manipulador.pegarBitNaPosicao(inteiro,1));
      // manipulador.imprimirBits(inteiro);
      bit = ((manipulador.pegarBitNaPosicao(inteiroCrc1,0)) ^ (manipulador.pegarBitNaPosicao(inteiroCrc2,0))) == 0 ? 0:1;
      resto <<= 1;
      resto |= bit;
      // System.out.println("valor inteiro: ");
      // manipulador.imprimirBits(inteiro);
      // System.out.println("valor crcd : ");
      // manipulador.imprimirBits(crc32);
      // System.out.println("valor do resto: ");
      // manipulador.imprimirBits(resto);
      inteiroCrc1 <<= 1;
      inteiroCrc2 <<= 1;
      contador++;
    }//Fim while
    if(resto == 0){
      System.out.println("RESTO DEU ZERO OK");
      quadrosAtransmitir[contaIndice] = quadro[indiceQuadro];
      manipulador.imprimirBits(quadro[indiceQuadro]);
      System.out.println("-------------------------- valor do indice quadro: " + indiceQuadro);
      contaIndice++;
      indiceQuadro += 2;
      System.out.println("depois da soma: " + indiceQuadro);
    }//fim if
    else{
      System.out.println("deu merdaaaaaaaa");
      quadrosAtransmitir[contaIndice] = manipulador.devolveERRO();
      contaIndice++;
      indiceQuadro += 2;
    }//Fim else
  }//fim for
  return quadrosAtransmitir;
 }//fim metodo camadaEnlanceDadosReceptoraControleDeErroCRC

 public int[] camadaEnlaceDadosReceptoraControleDeErroBitDeParidadePar(int quadro []){
  System.out.println("paridade par");
  int quadrosAtransmitir [] = new int[quadro.length];
  for(int i = 0; i < quadro.length; i++){
    if((manipulador.quantidadeBits1Inteiro(quadro[i])) % 2 == 0){
      System.out.println("paridade par ok");
      quadro[i] >>= 16; 
      quadro[i] = manipulador.deslocarBits(quadro[i]);
      quadrosAtransmitir[i] = quadro[i];
    }else{
      System.out.println("paridade impar erro");
      quadrosAtransmitir[i] = manipulador.devolveERRO();
    }//Fim else
  }//Fim for
  return quadrosAtransmitir;
 }//fim do metodo CamadaEnlaceDadosReceptoraControleDeErroBitDeParidadePar

 public int[] camadaEnlaceDadosReceptoraControleDeErroBitDeParidadeImpar(int quadro []) {
  int quadrosAtransmitir [] = new int[quadro.length];
  for(int i = 0; i < quadro.length; i++){
    if((manipulador.quantidadeBits1Inteiro(quadro[i])) % 2 != 0){
      System.out.println("paridade impar ok");
      quadro[i] >>= 16; 
      quadro[i] = manipulador.deslocarBits(quadro[i]);
      quadrosAtransmitir[i] = quadro[i];
    }else{
      System.out.println("paridade par erro");
      quadrosAtransmitir[i] = manipulador.devolveERRO();
    }//Fim else
  }//Fim for
  return quadrosAtransmitir;
 }//fim do metodo CamadaEnlaceDadosReceptoraControleDeErroBitDeParidadeImpar
 
 public void camadaEnlaceDadosReceptoraControleDeErroCodigoDeHamming (int quadro []) {
 //implementacao do algoritmo para VERIFICAR SE HOUVE ERRO
 }//fim do metodo CamadaEnlaceDadosReceptoraControleDeErroCodigoDeHamming

  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoContagemDeCaracteres(int quadro []) {
    System.out.println();
    System.out.println("ENLACE RECEPTORA: ");
    if(tipoDeControleDeErro == 2){  
      for(int j = 0; j < quadro.length; j++){
        if(j % 2 == 0){
          quadro[j] <<= 8;
          manipulador.imprimirBits(quadro[j]);
        }//fim if
      }//Fim for
    }else{
      for(int j = 0; j < quadro.length; j++){
        quadro[j] <<= 8;
        manipulador.imprimirBits(quadro[j]);
      }//Fim for
    }//fim else
    System.out.println("--------------enlancereceptora------------");
    for(int i = 0; i < quadro.length; i++){
      manipulador.imprimirBits(quadro[i]);
    }
    System.out.println("------------------------------------------");
    System.out.println();
    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraContagemDeCaracteres

  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBytes (int quadro []) {
    System.out.println("ENLACE RECEPTORA BYTES: ");
    if(tipoDeControleDeErro == 2){
      for(int j = 0; j < quadro.length; j++){
        if(j % 2 == 0){
          quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,24);
          quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,23);
          quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,22);
          quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,21);
          quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,20);
          quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,19);
          quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,18);
          quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,17);
          quadro[j] <<= 8;
          manipulador.imprimirBits(quadro[j]);
        }//fim if
      }//Fim for
    }else{
      for(int j = 0; j < quadro.length; j++){
        quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,24);
        quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,23);
        quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,22);
        quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,21);
        quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,20);
        quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,19);
        quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,18);
        quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,17);
        quadro[j] <<= 8;
        manipulador.imprimirBits(quadro[j]);
      }//Fim for
    }//fim else

    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraInsercaoDeBytes

  //manipulador.cincoBitsSequenciais(quadro[j]);
      // manipulador.imprimirBits(quadro[j]);
  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBits (int quadro []) {
    System.out.println("ENLACE RECEPTORA BITS: ");
    int mask    = 1;
    int bit     = 0;
    int bit2    = 0;
    int bit3    = 0;
    int bitUm   = 0;
    int inteiro = 0;
    int umBitaFrente = 0;
    int umBitaFrente2 = 0;

    if(tipoDeControleDeErro == 2){
      for(int j = 0; j < quadro.length; j++){
        if(j % 2 == 0){
          quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,24);
          quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,23);
          quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,22);
          quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,21);
          quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,20);
          quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,19);
          quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,18);
          quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,17);
          quadro[j] <<= 8;
          manipulador.imprimirBits(quadro[j]);
          System.out.println("--------------");
          // int temp = manipulador.getPrimeiroByte(quadro[j]);
          // manipulador.imprimirBits(temp);
          if(manipulador.getPrimeiroByte2(quadro[j]) == 0){
            quadro[j] >>= 16;
            manipulador.imprimirBits(quadro[j]);
            inteiro = quadro[j];
            umBitaFrente = inteiro >> 1;
            umBitaFrente2 = umBitaFrente >> 1;
            System.out.println("ok");
            while(true){
              bit = (inteiro & mask) == 0 ? 0 : 1;
              bit2 = (umBitaFrente & mask) == 0 ? 0 : 1;
              bit3 = (umBitaFrente2 & mask) == 0 ? 0 : 1;
              if(bit == 0 && bit2 == 0 && bit3 == 1){
                inteiro >>= 1;
                quadro[j] = inteiro;
                manipulador.imprimirBits(quadro[j]);
                break;
              }else{
                inteiro >>= 1;
                umBitaFrente >>=1;
                umBitaFrente2>>=2;
              }//Fim else
            }//fim while
          }else{
            quadro[j] >>= 24;
            manipulador.imprimirBits(quadro[j]);
          }//Fim else
        }//fim if
      }//Fim for
    }else{
      for(int j = 0; j < quadro.length; j++){
        quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,24);
        quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,23);
        quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,22);
        quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,21);
        quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,20);
        quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,19);
        quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,18);
        quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,17);
        quadro[j] <<= 8;
        manipulador.imprimirBits(quadro[j]);
        System.out.println("--------------");
        // int temp = manipulador.getPrimeiroByte(quadro[j]);
        // manipulador.imprimirBits(temp);
        if(manipulador.getPrimeiroByte2(quadro[j]) == 0){
          quadro[j] >>= 16;
          manipulador.imprimirBits(quadro[j]);
          inteiro = quadro[j];
          umBitaFrente = inteiro >> 1;
          umBitaFrente2 = umBitaFrente >> 1;
          System.out.println("ok");
          while(true){
            bit = (inteiro & mask) == 0 ? 0 : 1;
            bit2 = (umBitaFrente & mask) == 0 ? 0 : 1;
            bit3 = (umBitaFrente2 & mask) == 0 ? 0 : 1;
            if(bit == 0 && bit2 == 0 && bit3 == 1){
              inteiro >>= 1;
              quadro[j] = inteiro;
              manipulador.imprimirBits(quadro[j]);
              break;
            }else{
              inteiro >>= 1;
              umBitaFrente >>=1;
              umBitaFrente2>>=2;
            }//Fim else
          }//fim while
        }//fim if
      }//Fim for
    }//fim else
    System.out.println("novo quadro na enlace RECEPTORA: ");
    if(tipoDeControleDeErro == 2){
      for(int i =0; i < quadro.length; i++){
        if(i % 2 == 0){
          quadro[i] = manipulador.deslocarBits(quadro[i]);
          manipulador.imprimirBits(quadro[i]);
        }//fim if
        else{
          manipulador.imprimirBits(quadro[i]);
        }//fim else
      }//Fim for
    }else{
      for(int i =0; i < quadro.length; i++){
        quadro[i] = manipulador.deslocarBits(quadro[i]);
        manipulador.imprimirBits(quadro[i]);
      }//fim for
    }//fim else
    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraInsercaoDeBits


  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoViolacaoDaCamadaFisica(int quadro []) {
    int[] novoQuadro = new int [quadro.length];
    int contador = 0;
    int bit = 0;
    int mask = 1 << 31;

    System.out.println("ENLACE VIOLACAO CAMADA FISICA: ");

    if(tipoDeControleDeErro == 2){
      for(int j = 0; j < quadro.length; j++){
        if(j % 2 == 0){  
          contador = 0;
          quadro[j] <<= 8;
          manipulador.imprimirBits(quadro[j]);
          System.out.println("-------------------");
          while(contador < 8){
            bit = (quadro[j] & mask) == 0 ? 0 : 1;
            // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
            // System.out.println("valor bit: " + bit);
            novoQuadro[j] <<= 1;
            novoQuadro[j] = novoQuadro[j] | bit;
            quadro[j] <<= 2;
            contador++;
          }//Fim while
        }//Fim if  
      }//Fim for
    }else{
      for(int j = 0; j < quadro.length; j++){ 
        int temp = 0; 
        contador = 0;
        quadro[j] <<= 8;
        manipulador.imprimirBits(quadro[j]);
        temp = manipulador.pegarBitNaPosicao(quadro[j],16);
        System.out.println("-------------------");
        while(contador < 32){
          bit = (quadro[j] & mask) == 0 ? 0 : 1;
          // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
          // System.out.println("valor bit: " + bit);
          novoQuadro[j] <<= 1;
          novoQuadro[j] = novoQuadro[j] | bit;
          quadro[j] <<= 2;
          contador++;
        }//Fim while
        novoQuadro[j] = manipulador.adicionarBitNaPosicao(novoQuadro[j],0,9);
        novoQuadro[j] = manipulador.adicionarBitNaPosicao(novoQuadro[j],temp,17);
      }//Fim for
    }//fim else
    if(tipoDeControleDeErro == 2){
      for(int i =0; i < quadro.length; i++){
        if(i % 2 == 0){
          novoQuadro[i] = manipulador.deslocarBits(novoQuadro[i]);
          manipulador.imprimirBits(novoQuadro[i]);
        }//fim if
        else{
          novoQuadro[i] = quadro[i];
          manipulador.imprimirBits(novoQuadro[i]);
        }//Fim else
      }//Fim for
    }else{
      for(int i =0; i < quadro.length; i++){
        novoQuadro[i] = manipulador.deslocarBits(novoQuadro[i]);
        manipulador.imprimirBits(novoQuadro[i]);
      }//Fim for
    }//Fim else
    System.out.println("--------------------------teste--------------------------");
    for(int i =0; i< novoQuadro.length; i++){
      manipulador.imprimirBits(novoQuadro[i]); 
    }
    System.out.println("----------------------fim teste--------------------------");
    return novoQuadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraViolacaoDaCamadaFisica

  /*public void setControlador (Controlador controlador){
    control = controlador;
  }//fim metodo setControlador*/
}//fim classe CamadaEnlaceDadosTransmissora