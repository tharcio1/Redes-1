package camadas;
import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;

public class CamadaEnlaceDadosReceptora{
  // Controlador control;
  CamadaDeAplicacaoReceptora camadaApliReceptora = new CamadaDeAplicacaoReceptora(); 
  MetodosBit manipulador = new MetodosBit();
  int tipoDeEnquadramento = 0; //alterar de acordo com o teste

  public CamadaEnlaceDadosReceptora(){
    
  }//Fim metodo construtor

  public void CamadaEnlaceDadosReceptora(int quadro[]){
    int quadroEnquadrado [];

    quadroEnquadrado = camadaEnlaceDadosReceptoraEnquadramento(quadro); 
    quadroEnquadrado = camadaEnlaceDadosReceptoraControleDeErro(quadroEnquadrado);
    //CamadaDeEnlaceDadosReceptoraControleDeFluxo(quadro);

    camadaApliReceptora.camadaAplicacaoReceptora(quadroEnquadrado);
  }//fim metodo CamadaEnlanceDadosTransmissora
  
  public int[] camadaEnlaceDadosReceptoraEnquadramento(int quadro[]){
    int[] quadroEnquadrado;
    switch (tipoDeEnquadramento) {
      case 0 : //contagem de caracteres
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoContagemDeCaracteres(quadro);
        return quadroEnquadrado;
      case 1 : //insercao de bytes
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBytes(quadro);
        return quadroEnquadrado;
      case 2 : //insercao de bits
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBits(quadro);
        return quadroEnquadrado;
      case 3 : //violacao da camada fisica
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoViolacaoDaCamadaFisica(quadro);
        return quadroEnquadrado;
    }//fim do switch/case
    return quadro;
  }//fim do metodo CamadaEnlaceTransmissoraEnquadramento

  public int[] camadaEnlaceDadosReceptoraControleDeErro (int quadro []) {
    int quadroNovo [];

    int tipoDeControleDeErro = 0; //alterar de acordo com o teste
    switch (tipoDeControleDeErro) {
      case 0 : //bit de paridade par
        quadroNovo = camadaEnlaceDadosReceptoraControleDeErroBitDeParidadePar(quadro);
        return quadroNovo;
      case 1 : //bit de paridade impar
        quadroNovo = camadaEnlaceDadosReceptoraControleDeErroBitDeParidadeImpar(quadro);
        return quadroNovo;
      case 2 : //CRC
        return quadro; // colocar quadro novo
      case 3 : //codigo de hamming
        return quadro; // colocar quadro novo
    }//fim do switch/case
      return quadro; 
  }//fim do metodo CamadaEnlaceDadosReceptoraControleDeErro

 public int[] camadaEnlaceDadosReceptoraControleDeErroBitDeParidadePar(int quadro []) {
  for(int i = 0; i < quadro.length; i++){
    quadro[i] >>= 16; 
    quadro[i] = manipulador.deslocarBits(quadro[i]);
    System.out.println("dentro da paridade");
    manipulador.imprimirBits(quadro[i]);
  }//Fim for
  return quadro;
 }//fim do metodo CamadaEnlaceDadosReceptoraControleDeErroBitDeParidadePar

 public int[] camadaEnlaceDadosReceptoraControleDeErroBitDeParidadeImpar(int quadro []) {
  for(int i = 0; i < quadro.length; i++){
    quadro[i] >>= 16; 
    quadro[i] = manipulador.deslocarBits(quadro[i]);
    System.out.println("dentro da paridade");
    manipulador.imprimirBits(quadro[i]);
  }//Fim for
  return quadro;
 }//fim do metodo CamadaEnlaceDadosReceptoraControleDeErroBitDeParidadeImpar
 

 public void camadaEnlaceDadosReceptoraControleDeErroCRC (int quadro []) {
 //implementacao do algoritmo para VERIFICAR SE HOUVE ERRO
 //usar polinomio CRC-32(IEEE 802)
 }//fim do metodo CamadaEnlaceDadosReceptoraControleDeErroCRC
 public void camadaEnlaceDadosReceptoraControleDeErroCodigoDeHamming (int quadro []) {
 //implementacao do algoritmo para VERIFICAR SE HOUVE ERRO
 }//fim do metodo CamadaEnlaceDadosReceptoraControleDeErroCodigoDeHamming

  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoContagemDeCaracteres(int quadro []) {
    System.out.println();
    System.out.println("ENLACE RECEPTORA: ");
    for(int j = 0; j < quadro.length; j++){
      quadro[j] <<= 8;
      manipulador.imprimirBits(quadro[j]);
    }//Fim for
    System.out.println("--------------enlancereceptora------------");
    for(int i = 0; i < quadro.length; i++){
      manipulador.imprimirBits(quadro[i]);
    }
    System.out.println();
    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraContagemDeCaracteres

  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBytes (int quadro []) {
    System.out.println("ENLACE RECEPTORA BYTES: ");
    for(int j = 0; j < quadro.length; j++){
      quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,24);
      quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,23);
      quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,22);
      quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,21);
      quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,20);
      quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,19);
      quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,18);
      quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,17);
      quadro[j] <<= 8;
      manipulador.imprimirBits(quadro[j]);
    }//Fim for

    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraInsercaoDeBytes

  //manipulador.cincoBitsSequenciais(quadro[j]);
      // manipulador.imprimirBits(quadro[j]);
  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBits (int quadro []) {
    System.out.println("ENLACE RECEPTORA BITS: ");
    int mask    = 1;
    int bit     = 0;
    int bit2    = 0;
    int bit3    = 0;
    int bitUm   = 0;
    int inteiro = 0;
    int umBitaFrente = 0;
    int umBitaFrente2 = 0;

    for(int j = 0; j < quadro.length; j++){
      quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,24);
      quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,23);
      quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,22);
      quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,21);
      quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,20);
      quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,19);
      quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,18);
      quadro[j] = manipulador.adicionarBitNaPosicao(quadro[j],0,17);
      quadro[j] <<= 8;
      manipulador.imprimirBits(quadro[j]);
      System.out.println("--------------");
      // int temp = manipulador.getPrimeiroByte(quadro[j]);
      // manipulador.imprimirBits(temp);
      if(manipulador.getPrimeiroByte2(quadro[j]) == 0){
        quadro[j] >>= 16;
        manipulador.imprimirBits(quadro[j]);
        inteiro = quadro[j];
        umBitaFrente = inteiro >> 1;
        umBitaFrente2 = umBitaFrente >> 1;
        System.out.println("ok");
        while(true){
          bit = (inteiro & mask) == 0 ? 0 : 1;
          bit2 = (umBitaFrente & mask) == 0 ? 0 : 1;
          bit3 = (umBitaFrente2 & mask) == 0 ? 0 : 1;
          if(bit == 0 && bit2 == 0 && bit3 == 1){
            inteiro >>= 1;
            quadro[j] = inteiro;
            manipulador.imprimirBits(quadro[j]);
            break;
          }else{
            inteiro >>= 1;
            umBitaFrente >>=1;
            umBitaFrente2>>=2;
          }//Fim else
        }//fim while
      }else{
        quadro[j] >>= 24;
        manipulador.imprimirBits(quadro[j]);
      }//Fim else
    }//Fim for
    System.out.println("novo quadro na enlace RECEPTORA: ");
    for(int i =0; i < quadro.length; i++){
      quadro[i] = manipulador.deslocarBits(quadro[i]);
      manipulador.imprimirBits(quadro[i]);
    }//Fim for

    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraInsercaoDeBits
  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoViolacaoDaCamadaFisica(int quadro []) {
    int[] novoQuadro = new int [quadro.length];
    int contador = 0;
    int bit = 0;
    int mask = 1 << 31;

    System.out.println("ENLACE VIOLACAO CAMADA FISICA: ");

    for(int j = 0; j < quadro.length; j++){
      contador = 0;
      quadro[j] <<= 8;
      manipulador.imprimirBits(quadro[j]);
      System.out.println("-------------------");
      while(contador < 8){
        bit = (quadro[j] & mask) == 0 ? 0 : 1;
        // manipulador.imprimirBits(novoQuadro[indiceNvQ]);
        // System.out.println("valor bit: " + bit);
        novoQuadro[j] <<= 1;
        novoQuadro[j] = novoQuadro[j] | bit;
        quadro[j] <<= 2;
        contador++;
      }//Fim while
    }//Fim for
    for(int i =0; i < quadro.length; i++){
      novoQuadro[i] = manipulador.deslocarBits(novoQuadro[i]);
      manipulador.imprimirBits(novoQuadro[i]);
    }//Fim for
    return novoQuadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraViolacaoDaCamadaFisica

  /*public void setControlador (Controlador controlador){
    control = controlador;
  }//fim metodo setControlador*/
}//fim classe CamadaEnlaceDadosTransmissora