package camadas;
import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;

public class CamadaEnlaceDadosReceptora{
  // Controlador control;
  CamadaDeAplicacaoReceptora camadaApliReceptora = new CamadaDeAplicacaoReceptora(); 
  ManipuladorDeBit manipulador = new ManipuladorDeBit();
  
  public CamadaEnlaceDadosReceptora(){
    
  }//Fim metodo construtor

  public void CamadaEnlaceDadosReceptora(int quadro[]){
    CamadaEnlaceDadosReceptoraEnquadramento(quadro); 
    //CamadaDeEnlaceDadosReceptoraControleDeErro(quadro);
    //CamadaDeEnlaceDadosReceptoraControleDeFluxo(quadro);
  }//fim metodo CamadaEnlanceDadosTransmissora
  
  public void CamadaEnlaceDadosReceptoraEnquadramento(int quadro[]){
    int tipoDeEnquadramento = 0; //alterar de acordo com o teste
    int[] quadroEnquadrado;
    switch (tipoDeEnquadramento) {
      case 0 : //contagem de caracteres
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoContagemDeCaracteres(quadro);
        camadaApliReceptora.camadaAplicacaoReceptora(quadroEnquadrado);
        break;
      /*case 1 : //insercao de bytes
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBytes(quadro);
        camadaApliReceptora.camadaAplicacaoReceptora(quadroEnquadrado);
        break;
      case 2 : //insercao de bits
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBits(quadro);
        camadaApliReceptora.camadaAplicacaoReceptora(quadroEnquadrado);
        break;
      case 3 : //violacao da camada fisica
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoViolacaoCamadaFisica(quadro);
        camadaApliReceptora.camadaAplicacaoReceptora(quadroEnquadrado);
        break;*/
    }//fim do switch/case
  }//fim do metodo CamadaEnlaceTransmissoraEnquadramento

  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoContagemDeCaracteres(int quadro []) {
    System.out.println("ENLACE RECEPTORA: ");
    for(int j = 0; j < quadro.length; j++){
      quadro[j] <<= 8;
      manipulador.imprimirBits(quadro[j]);
    }//Fim for
    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraContagemDeCaracteres
  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBytes (int quadro []) {

    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraInsercaoDeBytes
  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBits (int quadro []) {

    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraInsercaoDeBits
  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoViolacaoDaCamadaFisica (int quadro []) {

    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraViolacaoDaCamadaFisica

  /*public void setControlador (Controlador controlador){
    control = controlador;
  }//fim metodo setControlador*/
}//fim classe CamadaEnlaceDadosTransmissora