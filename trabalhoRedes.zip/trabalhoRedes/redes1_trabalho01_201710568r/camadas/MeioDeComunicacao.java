package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;

public class MeioDeComunicacao{
	
  CamadaFisicaReceptora camadaFisReceptora = new CamadaFisicaReceptora();

  public void meioDeComunicacao(int fluxoBrutoDeBits []){
    int[] fluxoBrutoDeBitsPontoA, fluxoBrutoDeBitsPontoB;

    MetodosBit manipulador = new MetodosBit();


    fluxoBrutoDeBitsPontoA = fluxoBrutoDeBits;
    fluxoBrutoDeBitsPontoB = new int[fluxoBrutoDeBitsPontoA.length];
    System.out.println("no meio: ");
    for(int i =0; i < fluxoBrutoDeBitsPontoA.length; i++){
       manipulador.imprimirBits(fluxoBrutoDeBitsPontoA[i]);
    }

    int mask = 1 << 31;
    int bit = 0;
    int temporarioA = 0;
    int temporarioB = 0;
    int cont = 0;
    //int qtdBits = 0;

    for(int j = 0; j < fluxoBrutoDeBitsPontoA.length; j++){
    	cont = 0;
    	temporarioA = fluxoBrutoDeBitsPontoA[j];
    	// manipulador.imprimirBits(temporarioA);
	    while(cont < 32){
	    	bit = (temporarioA & mask) == 0 ? 0 : 1;
	    	// manipulador.imprimirBits(temporarioA);
	    	// System.out.println("valor bit: " + bit);
	    	//manipulador.imprimirBits(temporarioB);
	    	temporarioB <<= 1;
	    	temporarioB = temporarioB | bit;
	    	temporarioA <<= 1;
	    	cont++;
	    }//Fim while incluso
	    fluxoBrutoDeBitsPontoB[j] = temporarioB;
	    temporarioB = 0;
	  }//Fim for

    /*for(int j = 0; j < fluxoBrutoDeBitsPontoA.length; j++){
	    while(fluxoBrutoDeBitsPontoA[j] > 0){
		    if((fluxoBrutoDeBitsPontoA[j] & mask) == 0){
		      bit = 1;
		    	fluxoBrutoDeBitsPontoB[j] = fluxoBrutoDeBitsPontoB[j] << 1;
		      fluxoBrutoDeBitsPontoB[j] = fluxoBrutoDeBitsPontoB[j] | bit;
		      fluxoBrutoDeBitsPontoA[j] = fluxoBrutoDeBitsPontoA[j] << 1;
		    }//Fim if
		    else if((fluxoBrutoDeBitsPontoA[j] & mask) == 1){
		      bit = 1;
		    	fluxoBrutoDeBitsPontoB[j] = fluxoBrutoDeBitsPontoB[j] << 1;
		      fluxoBrutoDeBitsPontoB[j] = fluxoBrutoDeBitsPontoB[j] | bit;
		      fluxoBrutoDeBitsPontoA[j] = fluxoBrutoDeBitsPontoA[j] << 1;
		    }//Fim else if
		  }//Fim while
    }//Fim for*/

    System.out.println("dentro do meio: ");
    for(int k = 0; k < fluxoBrutoDeBitsPontoB.length; k++){
      manipulador.imprimirBits(fluxoBrutoDeBitsPontoB[k]);
    }
    
    camadaFisReceptora.camadaFisicaReceptora(fluxoBrutoDeBitsPontoB);
  }//Fim metodo meioDeComunicacao

}//Fim classe MeioDeComunicacao