package ondas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;

public class Ondas extends Thread{
  Controlador control;

	public Ondas(){

  }//Fim metodo Construtor Ondas

  public void run(){
    while(true){
      
      if(control.verificacao == 1){
        control.nivelAlto();
      }//Fim if
      else if(control.verificacao == 0){
        control.nivelBaixo();
      }//Fim else if

    }//Fim while
  }//Fim metodo run

  public void ondaAlta(){
    control.nivelBaixo();
  }//Fim metodo ondaAlta

  public void ondaBaixa(){
    control.nivelAlto();
  }//Fim metodo ondaBaixa

  public void setControlador(Controlador controle){
    control = controle;
  }//Fim setControlador
}//Fim classe Ondas