package camadas;
import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;

public class CamadaEnlaceDadosTransmissora{
  Controlador control;
  CamadaTransmissora camadatransmissora;

  public CamadaEnlaceDadosTransmissora(){
  
  }//Fim metodo construtor
  
  public void CamadaEnlaceDadosTransmissora(int quadro[]){
    CamadaEnlaceDadosTransmissoraEnquadramento(quadro); 
    //CamadaDeEnlaceDadosTransmissoraControleDeErro(quadro);
    //CamadaDeEnlaceDadosTransmissoraControleDeFluxo(quadro);
  }//fim metodo CamadaEnlanceDadosTransmissora
  
  public void CamadaEnlaceDadosTransmissoraEnquadramento(int quadro[]){
    int tipoDeEnquadramento = 0; //alterar de acordo com o teste
    int quadroEnquadrado [];
    switch (tipoDeEnquadramento) {
      case 0 : //contagem de caracteres
        quadroEnquadrado = CamadaDeEnlaceDadosTransmissoraEnquadramentoContagemDeCaracteres(quadro);
        camadatransmissora.CamadaFisicaTransmissora(quadroEnquadrado);
        break;
      /*case 1 : //insercao de bytes
        quadroEnquadrado = CamadaDeEnlaceDadosTransmissoraEnquadramentoInsercaoDeBytes(quadro);
        camadatransmissora.CamadaFisicaTransmissora(quadroEnquadrado);
        break;
      case 2 : //insercao de bits
        quadroEnquadrado = CamadaDeEnlaceDadosTransmissoraEnquadramentoInsercaoDeBits(quadro);
        camadatransmissora.CamadaFisicaTransmissora(quadroEnquadrado);
        break;
      case 3 : //violacao da camada fisica
        quadroEnquadrado = CamadaDeEnlaceDadosTransmissoraEnquadramentoViolacaoCamadaFisica(quadro);
        camadatransmissora.CamadaFisicaTransmissora(quadroEnquadrado);
        break;*/
    }//fim do switch/case
  }//fim do metodo CamadaEnlaceTransmissoraEnquadramento

  public int[] CamadaDeEnlaceDadosTransmissoraEnquadramentoContagemDeCaracteres(int quadro []){
    
    int tamanhoMensagem = 0;
    int novoTamanho = quadro.length + 1;
    int[] novoQuadro = new int[novoTamanho];
    int mask = 1;
    int ultimoQuadro = quadro[quadro.length - 1];
    int cont = 0;
    int indiceNQ = 0;
    //System.out.println("tamanho do quadro: " + quadro.length);


    if(quadro.length == 1){
        while(quadro[0] > 0){
          tamanhoMensagem += 1;
          quadro[0] = quadro[0] >> 1;
        }//Fim while
        System.out.println("tamanho mensagem: " + tamanhoMensagem);
        //aqui ele ira armazenar o tamanho da mensagem como informacao de controle e tambem ira usar o ultimo quadro para
        //percorrer de novo o quadro mas agora armazenando informacoes no novoQuadro
        if(tamanhoMensagem < 31){
          int infoControle = (tamanhoMensagem + 1) / 8;
          System.out.println("info controle: " + infoControle);

          if(infoControle == 3){
            novoQuadro[indiceNQ] = novoQuadro[indiceNQ] | 51; //equivalente ao valor 3 que eh a informacao de controle
            System.out.println(novoQuadro[indiceNQ]);
          }else if(infoControle == 2){
            novoQuadro[indiceNQ] = novoQuadro[indiceNQ] | 50; //equivalente ao valor 2 que eh a informacao de controle
            System.out.println(novoQuadro[indiceNQ]);
          }else if(infoControle == 1){
            novoQuadro[indiceNQ] = novoQuadro[indiceNQ] | 49; //equivalente ao valor 1 que eh a informacao de controle
            System.out.println(novoQuadro[indiceNQ]);
          }//fim else if
          novoQuadro[indiceNQ] = novoQuadro[indiceNQ] << 1;
        }//fim if
        else{
          novoQuadro[indiceNQ] = novoQuadro[indiceNQ] | 51; //equivalente ao valor 3 que eh a informacao de controle
          //System.out.println(novoQuadro[indiceNQ]);
          novoQuadro[indiceNQ] = novoQuadro[indiceNQ] << 1;
          System.out.println(novoQuadro[indiceNQ]);
          indiceNQ++;
          novoQuadro[indiceNQ] = novoQuadro[indiceNQ] | 49; //equivalente ao valor 1 que eh a informacao de controle
          System.out.println(novoQuadro[indiceNQ]);
          indiceNQ--;
        }//fim else
        while(ultimoQuadro > 0){
          if((ultimoQuadro & mask) == 0){
            cont += 1;
          }//Fim if
          else if((ultimoQuadro & mask) == 1){
            novoQuadro[indiceNQ] = novoQuadro[indiceNQ] | 1;
            cont += 1;
          }//Fim else if
          if(cont == 23){
            System.out.println(Integer.toBinaryString(novoQuadro[indiceNQ]));
            indiceNQ++;
            System.out.println("depois : " + Integer.toBinaryString(novoQuadro[indiceNQ]));
            ultimoQuadro = ultimoQuadro >> 1;
          }//Fim if
          ultimoQuadro = ultimoQuadro >> 1;
          novoQuadro[indiceNQ] = novoQuadro[indiceNQ] << 1;
        }//Fim while
        System.out.println(Integer.toBinaryString(novoQuadro[indiceNQ]));
        return novoQuadro;
      }//Fim if
      else{
        novoQuadro[indiceNQ] = novoQuadro[indiceNQ] | 51; //equivalente ao valor 3 que eh a informacao de controle
        novoQuadro[indiceNQ] = novoQuadro[indiceNQ] << 1;
      }//fim else

    for(int j = 0; j < quadro.length; j++){
      while(quadro[j] > 0){
        if((quadro[j] & mask) == 0){
          cont += 1;
        }//Fim if
        else if((quadro[j] & mask) == 1){
          novoQuadro[indiceNQ] = novoQuadro[indiceNQ] | 1;
          cont += 1;
        }//Fim else if
        if(cont == 23){
          //sobe o indice armazena informação de controle e zera o cont
          System.out.println(Integer.toBinaryString(novoQuadro[indiceNQ]));
          cont = 0;
          indiceNQ++;
          novoQuadro[indiceNQ] = novoQuadro[indiceNQ] | 51; //equivalente ao valor 3 que eh a informacao de controle
          quadro[j] = quadro[j] >> 1;
          System.out.println("valor 23: " + Integer.toBinaryString(novoQuadro[indiceNQ]));
        }//Fim if
        novoQuadro[indiceNQ] = novoQuadro[indiceNQ] << 1;
        quadro[j] = quadro[j] >> 1;
      }//Fim while
      System.out.println("cont : " + cont + " vezes");
    }//Fim for

    if(tamanhoMensagem < 8){
      tamanhoMensagem = 8;
    }//Fim if

    //System.out.println("tamanho do quadro novo: " + (indiceNQ + 1));
    System.out.println(Integer.toBinaryString(novoQuadro[indiceNQ]));
    return novoQuadro;
  }//Fim metodo CamadaDeEnlaceDadosTransmissoraEnquadramentoContagemDeCaracteres

  public int[] CamadaDeEnlaceDadosTransmissoraEnquadramentoInsercaoDeBytes (int quadro []) {

    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraInsercaoDeBytes
  public int[] CamadaDeEnlaceDadosTransmissoraEnquadramentoInsercaoDeBits (int quadro []) {

    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraInsercaoDeBits
  public int[] CamadaDeEnlaceDadosTransmissoraEnquadramentoViolacaoDaCamadaFisica (int quadro []) {

    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraViolacaoDaCamadaFisica

  public void setTransmissora(CamadaTransmissora transmissao){
    camadatransmissora = transmissao;
  }//Fim setEnlaceReceptora

  public void setControlador (Controlador controlador){
    control = controlador;
  }//fim metodo setControlador

}//fim classe CamadaEnlaceDadosTransmissora

/*
comentarios que podem ser uteis

if(j == quadro.length - 1){
        //aqui sera adicionado o tamanho da mensagem e os caracteres que tiverem
        while(quadro[j] > 0){
          tamanhoMensagem += 1;
          if((quadro[j] & mask) == 0){
            System.out.println("0");
            cont += 1;
          }//Fim if
          else if((quadro[j] & mask) == 1){
            System.out.println("1");
            cont += 1;
          }//Fim else if
          quadro[j] = quadro[j] >> 1;
        }//Fim while
        System.out.println("cont : " + cont + " vezes");
      }else{
        //aqui sera adicionado a informação de controle e os 3 caracteres*/