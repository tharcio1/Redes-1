package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static controlador.Controlador.tipoDeDecodificacao;


/*********************************************
Nome: Tharcio Thalles Almeida Silva
Data de inicio: 02 12 2018
data de termino: 15 12 2018
objetivo: simular a camada fisica de redes
********************************************/

public class CamadaReceptora{
  Controlador control;
  CamadaEnlaceDadosReceptora camadaEnlaceReceptora = new CamadaEnlaceDadosReceptora();

  public CamadaReceptora(){
    camadaEnlaceReceptora.setReceptora(this);
  }//Fim metodo construtor CamadaReceptora

  public void camadaFisicaReceptora(int quadro[]) {
    int fluxoBrutoDeBits[];
    switch (tipoDeDecodificacao) {
      case 0 : //decodificao binaria
        fluxoBrutoDeBits = camadaFisicaReceptoraDecodificacaoBinaria(quadro);
        //camadaDeAplicacaoReceptora(fluxoBrutoDeBits);
        camadaEnlaceReceptora.CamadaEnlaceDadosReceptora(fluxoBrutoDeBits);
        break;
      case 1 : //decodificacao manchester
        fluxoBrutoDeBits = camadaFisicaReceptoraDecodificacaoManchester(quadro);
        camadaEnlaceReceptora.CamadaEnlaceDadosReceptora(fluxoBrutoDeBits);
        break;
      case 2 : //codificacao manchester diferencial
        fluxoBrutoDeBits = camadaFisicaReceptoraDecodificacaoManchesterDiferencial(quadro);
        camadaEnlaceReceptora.CamadaEnlaceDadosReceptora(fluxoBrutoDeBits);
        break;
    }//fim do switch case
  }//fim metodo CamadaFisicaTransmissora

  public void camadaDeAplicacaoReceptora(int quadro[]){ 
    String mensagem = "";
    int c = 0;
    String desinverter = "";
    int j = 0;
    int n = 0;
    String result = "";
    String teste = "";
    String mensagem2= "";
    if(tipoDeDecodificacao == 1 || tipoDeDecodificacao == 2){
      while(n < quadro.length * 4){
        c = quadro[j] & 255; //compara usando o and com o valor 11111111
        quadro[j] = quadro[j] >> 8;
        mensagem += (char)c;
        n++;
        if(n % 2 == 0){
          for(int m = mensagem.length() - 1; m >= 0; m--){
            desinverter += mensagem.charAt(m);
          }//Fim for k          
          mensagem2 += desinverter;
          desinverter = "";
          mensagem = "";
        }//Fim if
        if(n != 0 && n % 4 == 0 && j < quadro.length - 1){
          j++;
        }//Fim if
        if(n != 0 && n % 4 == 0 || n == quadro.length * 4){
          result = mensagem + result;
          mensagem = "";
        }//Fim if
      }//Fim while      
      mensagem = mensagem2;
      aplicacaoReceptora(mensagem);
    }//Fim if
    else if(tipoDeDecodificacao == 0){
      while(n < quadro.length * 4){
        System.out.println("dentro da receptora: " + Integer.toBinaryString(quadro[j]));
        c = quadro[j] & 255; //compara usando o and com o valor 11111111
        System.out.println("");
        System.out.println("Valor do c: " + Integer.toBinaryString(c));
        System.out.println("");
        quadro[j] = quadro[j] >> 8;
        mensagem += (char)c;
        n++;
        if(n != 0 && n % 4 == 0 && j < quadro.length - 1){
          j++;
        }//Fim if
        if(n != 0 && n % 4 == 0 || n == quadro.length * 4){
          for(int k = mensagem.length() - 1; k >= 0; k--){
            desinverter += mensagem.charAt(k);
          }//Fim for
          result = desinverter + result;
          mensagem = "";
          desinverter = "";
        }//Fim if
      }//Fim while
      /*for(int k = result.length() - 1; k >= 0; k--){
        desinverter += result.charAt(k);
      }//Fim for k*/
      //mensagem = desinverter;
      mensagem = result;
      aplicacaoReceptora(mensagem);
    }//Fim elseif
  }//Fim metodo camadaDeAplicacaoReceptora

  public void aplicacaoReceptora(String mensagem){
    control.mensagemRecebida.setText(mensagem);
    control.mensagemRecebidaTela.setText(mensagem);
  }//Fim metodo aplicacaoReceptora

  public int[] camadaFisicaReceptoraDecodificacaoBinaria(int quadro[]){
    int[] temp = new int[quadro.length];
    control.mensagemDecodificada.setText("");
    for(int i=0;i<quadro.length;i++){
      temp[i] = quadro[i];
    }//Fim for

    for(int j = 0; j < quadro.length; j++){
      
      int mask = 1;

      while(quadro[j] > 0){
        if((quadro[j] & mask) == 0){
          control.mensagemDecodificada.setText('0' + control.mensagemDecodificada.getText());
        }//Fim if
        else if((quadro[j] & mask) == 1){
          control.mensagemDecodificada.setText('1' + control.mensagemDecodificada.getText());
        }//Fim else if
        quadro[j] = quadro[j] >> 1;
      }//Fim while

    }//Fim for j
    return temp;
  }//Fim metodo CamadaFisicaReceptoraCodificacaoBinaria
 
  public int[] camadaFisicaReceptoraDecodificacaoManchester(int quadro[]){
    int[] conversao = new int[quadro.length/2];
    int indConv = 0;
    int contador = 0;
    control.mensagemDecodificada.setText("");
    String numero = "";

    for(int j = 0; j < quadro.length; j++){

      int mask = 1;

      int vezes = 16;
      
      contador = 0;
      //boolean controle = false;

      if(j % 2 == 0 && j != 0){
        indConv++;
      }//Fim if if if

      while(vezes > 0){
        contador++;
        numero = control.retornaBinario(conversao[indConv]);
        if(contador % 8 == 0){
          if((quadro[j] & mask) == 1){
            quadro[j] = quadro[j] >> 1;
            if((quadro[j] & mask) == 0){
              conversao[indConv] = conversao[indConv] << 1; 
            }//Fim if3
            else{
              conversao[indConv] = conversao[indConv] << 1;
            }//Fim else
          }//Fim if2
          else{
            if((quadro[j] & mask) == 0){
              quadro[j] = quadro[j] >> 1;
              int tempor = quadro[j] >> 1; 
              if((quadro[j] & mask) == 1){
                conversao[indConv] = conversao[indConv] << 2;
                conversao[indConv] = conversao[indConv] | 1; 
              }//Fim if if
              else if((quadro[j] & mask) == 0 && (tempor & mask) == 0 && vezes - 1 > 0){
                break;
              }//Fim else if
              else if(contador == 16 && numero.length() < 30 && j+1 != quadro.length && quadro[j+1] > 0){
                conversao[indConv] = conversao[indConv] << 1;
              }//Fim else if
            }//Fim if
          }//Fim else
        }//Fim if1
        else{
          if((quadro[j] & mask) == 0){
            quadro[j] = quadro[j] >> 1;
            if((quadro[j] & mask) == 1){
              conversao[indConv] = conversao[indConv] << 1;
              conversao[indConv] = conversao[indConv] | 1; 
            }//Fim if if
            control.mensagemDecodificada.setText('1' + control.mensagemDecodificada.getText());
          }//Fim if
          else if((quadro[j] & mask) == 1){
            quadro[j] = quadro[j] >> 1;
            if((quadro[j] & mask) == 0){
              conversao[indConv] = conversao[indConv] << 1;
              //conversao[indConv] = conversao[indConv] | 0;
              if(contador == 1){
                contador--;
                vezes++;
              }//Fim if 
            }//Fim if if
            control.mensagemDecodificada.setText('0' + control.mensagemDecodificada.getText());
          }//Fim else if
        }//Fim else
        quadro[j] = quadro[j] >> 1;
        vezes--;
      }//Fim while
    }//Fim for j
    return conversao;
  }//Fim metodo camadaFisicaReceptoraDecodificacaoManchester

  public int[] camadaFisicaReceptoraDecodificacaoManchesterDiferencial(int quadro[]){
    int[] conversao = new int[quadro.length/2];
    int execucoes = 0;
    int indConv = 0;
    int mask = 1;
    //quadro[0] = quadro[0] >> 2;
    control.mensagemDecodificada.setText("");

    for(int j = 0; j < quadro.length; j++){
      execucoes = 0;

      if(j % 2 == 0 && j != 0){
        indConv++;        
      }//Fim if if if

      if((quadro[j] & mask) != 0){
        conversao[indConv] = conversao[indConv] << 1;
      }//Fim if

      while(execucoes != 16){
        execucoes++;        
        if((quadro[j] & mask) == 1){
          quadro[j] = quadro[j] >> 1;
          if((quadro[j] & mask) == 1){
            conversao[indConv] = conversao[indConv] << 1;
            conversao[indConv] = conversao[indConv] | 1; 
          }//Fim if if
        }//Fim if
        else if((quadro[j] & mask) == 0){
          quadro[j] = quadro[j] >> 1;
          if((quadro[j] & mask) == 1){
            conversao[indConv] = conversao[indConv] << 1;
          }//Fim if
        }//Fim else if

        quadro[j] = quadro[j] >> 1;
     
      }//Fim while 
    }//Fim for
    return conversao;
  }//Fim metodo camadaFisicaReceptoraDecodificacaoManchesterDiferencial

  public void setControlador(Controlador controle){
    control = controle;
  }//Fim setControlador

}//Fim classe CamadaReceptora