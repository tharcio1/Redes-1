package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static controlador.Controlador.tipoDeDecodificacao;

/*********************************************
Nome: Tharcio Thalles Almeida Silva
Data de inicio: 02 12 2018
data de termino: 15 12 2018
objetivo: simular a camada fisica de redes
********************************************/

public class CamadaTransmissora{
  Controlador control;
  CamadaEnlaceDadosTransmissora camadaEnlaceTransmissora = new CamadaEnlaceDadosTransmissora();

  public CamadaTransmissora(){
    camadaEnlaceTransmissora.setTransmissora(this);
  }//Fim metodo construtor CamadaTransmissora

  public void CamadaDeAplicacaoTransmissora(String mensagem){
    mensagem += " ";
    int indice = 0;
    //o if e o else define o tamanho do vetor
    if(mensagem.length() % 4 == 0){
      indice = mensagem.length()/4;
    }else{
      indice = ((int)mensagem.length()/4) + 1;
    }//Fim else
    int quadro [] = new int[indice];
    int n = 1;
    int i = 0;
    int aux = 0;
    int v = 0;

    while(i < mensagem.length()){
      aux = mensagem.charAt(i); //recebe o valor em decimal da letra
      quadro[v] = (quadro[v] << 8);
      quadro[v] = quadro[v] | aux;
      i++;
      if(i != 0 && i % 4 == 0 && v < quadro.length - 1){
        v++;
        //quadro[v] = quadro[v] | 2;
      }//Fim if
    }//Fim while  

    camadaEnlaceTransmissora.CamadaEnlaceDadosTransmissora(quadro);
  }//Fim metodo CamadaDeAplicacaoTransmissora

  public void CamadaFisicaTransmissora(int quadro[]) {
    int fluxoBrutoDeBits[];
    switch (tipoDeDecodificacao) {
      case 0 : //codificao binaria
        fluxoBrutoDeBits = CamadaFisicaTransmissoraCodificacaoBinaria(quadro);
        control.meioDeComunicacao(fluxoBrutoDeBits);
        break;
      case 1 : //codificacao manchester
        fluxoBrutoDeBits = CamadaFisicaTransmissoraCodificacaoManchester(quadro);
        control.meioDeComunicacao(fluxoBrutoDeBits);
        break;
      case 2 : //codificacao manchester diferencial
        fluxoBrutoDeBits = CamadaFisicaTransmissoraCodificacaoManchesterDiferencial(quadro);
        control.meioDeComunicacao(fluxoBrutoDeBits);
        break;
    }//fim do switch/case
  }//fim metodo CamadaFisicaTransmissora

  public int[] CamadaFisicaTransmissoraCodificacaoBinaria(int quadro[]){
    int[] temp = new int[quadro.length];

    int mask = 1;

    String formaDeOnda = "";

    for(int i=0;i<quadro.length;i++){
    	temp[i] = quadro[i];
    }//Fim for i

    for(int j = 0; j < quadro.length; j++){
      while(quadro[j] > 0){
        if((quadro[j] & mask) == 0){
          formaDeOnda = "0" + formaDeOnda;
        }//Fim if
        else if((quadro[j] & mask) == 1){
          formaDeOnda = "1" + formaDeOnda;
        }//Fim else if
        quadro[j] = quadro[j] >> 1;
      }//Fim while
    }//Fim for j
    formaDeOnda = "0" + formaDeOnda;
    control.gerarOnda(formaDeOnda);
    return temp;
  }//fim do metodo CamadaFisicaTransmissoraCodificacaoBinaria

  public int[] CamadaFisicaTransmissoraCodificacaoManchester (int quadro []) {
    //implementacao do algoritmo para CODIFICAR

    int novoTamanho = quadro.length * 2;
    int[] novoQuadro = new int[novoTamanho];
    int mask = 1;
    int zeroOUum = 0;
    int indiceNQ = 0;
    int cont = 1;
    String formaDeOnda = "";

    //[01100110,01100110,01100110,01100110]

    for(int j = 0; j < quadro.length; j++){
      if(j > 0){
        indiceNQ++;
        cont = 0;
      }//Fim if
      while(quadro[j] > 0){
        novoQuadro[indiceNQ] = novoQuadro[indiceNQ] << 2;
        if((quadro[j] & mask) == 0){
          formaDeOnda = "01" + formaDeOnda;
          zeroOUum = 1; // equivalente a 01 que representa 0
          novoQuadro[indiceNQ] = novoQuadro[indiceNQ] | zeroOUum;
          cont++;
        }//Fim if
        else if((quadro[j] & mask) == 1){
          formaDeOnda = "10" + formaDeOnda;
          zeroOUum = 2; // equivalente a 10 que representa 1
          novoQuadro[indiceNQ] = novoQuadro[indiceNQ] | zeroOUum;
          cont++;
        }//Fim else if

        quadro[j] = quadro[j] >> 1;

        if(cont == 16){
          indiceNQ++;
          String a = control.retornaBinario(quadro[j]);
          if((quadro[j] & mask) == 0 && a.length() > 15){
            quadro[j] = quadro[j] >> 1;
          }//Fim if incluso
          a = control.retornaBinario(quadro[j]);          
          cont = 0;
        }//Fim if
      }//Fim while
    }//Fim for j
    formaDeOnda = "01" + formaDeOnda;
    control.gerarOnda(formaDeOnda);
    return novoQuadro;
  }//fim do metodo CamadaFisicaTransmissoraCodificacaoManchester
  
  public int[] CamadaFisicaTransmissoraCodificacaoManchesterDiferencial(int quadro[]){
    //implementacao do algoritmo para CODIFICAR
    int novoTamanho = quadro.length * 2;
    int[] novoQuadro = new int[novoTamanho];
    int mask = 1;
    int zeroOUum = 0;
    int indiceNQ = 0;
    int cont = 1;
    String formaDeOnda = "";

    for(int j = 0; j < quadro.length; j++){
      if(j > 0){
        novoQuadro[indiceNQ] = novoQuadro[indiceNQ] << 1;
        novoQuadro[indiceNQ] = novoQuadro[indiceNQ] | zeroOUum;
        novoQuadro[indiceNQ] = novoQuadro[indiceNQ] << 1;
        indiceNQ++;
        cont = 1;
      }//Fim if
      zeroOUum = 1;
      while(quadro[j] > 0){
        novoQuadro[indiceNQ] = novoQuadro[indiceNQ] << 1;
        if((quadro[j] & mask) == 0){
          formaDeOnda = "10" + formaDeOnda;
          zeroOUum = 1; // equivalente a 1 que representa 1
          novoQuadro[indiceNQ] = novoQuadro[indiceNQ] | zeroOUum;
          novoQuadro[indiceNQ] = novoQuadro[indiceNQ] << 1;
          cont++;
        }//Fim if
        else if((quadro[j] & mask) == 1){
          formaDeOnda = "11" + formaDeOnda;
          zeroOUum = 1; // equivalente a 1 que representa 1
          novoQuadro[indiceNQ] = novoQuadro[indiceNQ] | zeroOUum;
          novoQuadro[indiceNQ] = novoQuadro[indiceNQ] << 1;
          novoQuadro[indiceNQ] = novoQuadro[indiceNQ] | zeroOUum;
          cont++;
        }//Fim else if        
        quadro[j] = quadro[j] >> 1;

        if(cont == 17){
          indiceNQ++;
          cont = 1;
        }//Fim if
      }//Fim while
    }//Fim for
    formaDeOnda = "10" + formaDeOnda;    
    control.gerarOnda(formaDeOnda);
    return novoQuadro;
  }//fim do metodo CamadaFisicaTransmissoraCodificacaoManchesterDiferencial

  public void setControlador(Controlador controle){
    control = controle;
  }//Fim setControlador
}//Fim classe