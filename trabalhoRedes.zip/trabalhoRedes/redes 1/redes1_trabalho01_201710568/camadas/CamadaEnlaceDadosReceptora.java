package camadas;
import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;

public class CamadaEnlaceDadosReceptora{
  Controlador control;
  CamadaReceptora camadareceptora; 
  
  public CamadaEnlaceDadosReceptora(){
    
  }//Fim metodo construtor

  public void CamadaEnlaceDadosReceptora(int quadro[]){
    CamadaEnlaceDadosReceptoraEnquadramento(quadro); 
    //CamadaDeEnlaceDadosReceptoraControleDeErro(quadro);
    //CamadaDeEnlaceDadosReceptoraControleDeFluxo(quadro);
  }//fim metodo CamadaEnlanceDadosTransmissora
  
  public void CamadaEnlaceDadosReceptoraEnquadramento(int quadro[]){
    int tipoDeEnquadramento = 0; //alterar de acordo com o teste
    int[] quadroEnquadrado;
    switch (tipoDeEnquadramento) {
      case 0 : //contagem de caracteres
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoContagemDeCaracteres(quadro);
        camadareceptora.camadaDeAplicacaoReceptora(quadroEnquadrado);
        break;
      /*case 1 : //insercao de bytes
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBytes(quadro);
        camadareceptora.camadaDeAplicacaoReceptora(quadroEnquadrado);
        break;
      case 2 : //insercao de bits
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBits(quadro);
        camadareceptora.camadaDeAplicacaoReceptora(quadroEnquadrado);
        break;
      case 3 : //violacao da camada fisica
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoViolacaoCamadaFisica(quadro);
        camadareceptora.camadaDeAplicacaoReceptora(quadroEnquadrado);
        break;*/
    }//fim do switch/case
  }//fim do metodo CamadaEnlaceTransmissoraEnquadramento

  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoContagemDeCaracteres(int quadro []) {
    int novoTamanho = quadro.length;
    int[] novoQuadro = new int[novoTamanho];
    int mask = 1;
    int cont = 0;
    int indiceNQ = 0;
    int ultimoQuadro = quadro[quadro.length - 1];
    int tamanhoMensagem = 0;
    int iteracao = quadro.length - 1;

    while(quadro[iteracao] == 0){
      iteracao--;
    }//Fim while

    ultimoQuadro = quadro[iteracao];

    if(ultimoQuadro == 0 && quadro.length < 3){
      ultimoQuadro = quadro[0];
      while(ultimoQuadro > 0){
        tamanhoMensagem++;
        ultimoQuadro = ultimoQuadro >> 1;
      }//Fim while
      System.out.println("NA ENLACE RECEPTORA: " + tamanhoMensagem);
      while(cont < (tamanhoMensagem - 6)){
        if((quadro[0] & mask) == 0){
            
        }//Fim if
        else if((quadro[0] & mask) == 1){
          novoQuadro[0] = novoQuadro[0] | 1;
        }//Fim else if
        cont++;
        quadro[0] = quadro[0] >> 1;
        System.out.println(Integer.toBinaryString(quadro[0]));
        if(cont == (tamanhoMensagem - 6)){
          break;
        }//Fim if
        novoQuadro[0] = novoQuadro[0] << 1;
      }//Fim while
    }//Fim if
    else{
      while(ultimoQuadro > 0){
        tamanhoMensagem++;
        ultimoQuadro = ultimoQuadro >> 1;
      }//Fim while

      System.out.println("NA ENLACE RECEPTORA: " + tamanhoMensagem);

      for(int j = 0; j < quadro.length - 1; j++){
        if(quadro[j+1] == 0){
          cont = 0;
          break;
        }//Fim if
        while(cont < 23){
          if((quadro[j] & mask) == 0){
            
          }//Fim if
          else if((quadro[j] & mask) == 1){
            novoQuadro[j] = novoQuadro[j] | 1;
          }//Fim else if
          cont++;
          quadro[j] = quadro[j] >> 1;
          System.out.println(Integer.toBinaryString(quadro[j]));
          if(cont == 23){
            break;
          }//Fim if
          novoQuadro[j] = novoQuadro[j] << 1;
        }//Fim while
        System.out.println("");
        cont = 0;
      }//Fim for

      System.out.println("ultimo quadro: " + cont);
      /*int iteracao = quadro.length - 1;
      while(quadro[iteracao] == 0){
        iteracao--;
      }//Fim while*/
      while(cont < (tamanhoMensagem - 6)){
        if((quadro[iteracao] & mask) == 0){
            
        }//Fim if
        else if((quadro[iteracao] & mask) == 1){
          novoQuadro[iteracao] = novoQuadro[iteracao] | 1;
        }//Fim else if
        cont++;
        quadro[iteracao] = quadro[iteracao] >> 1;
        System.out.println(Integer.toBinaryString(quadro[iteracao]));
        if(cont == (tamanhoMensagem - 6)){
          break;
        }//Fim if
        novoQuadro[iteracao] = novoQuadro[iteracao] << 1;
      }//Fim while
    }//Fim else


    System.out.println("no final0: "+ Integer.toBinaryString(novoQuadro[0]));
    System.out.println("no final1: "+ Integer.toBinaryString(novoQuadro[1]));

    /*System.out.println("Informacoes que ficaram armazenadas: ");

    for(int j = 0; j < novoQuadro.length; j++){
      while(novoQuadro[j] > 0){
        if((novoQuadro[j] & mask) == 0){
          System.out.print("0");
          //cont += 1;
        }//Fim if
        else if((novoQuadro[j] & mask) == 1){
          System.out.print("1");
          //cont += 1;
        }//Fim else if
        
        //novoQuadro[indiceNQ] = novoQuadro[indiceNQ] << 1;
        novoQuadro[j] = novoQuadro[j] >> 1;
      }//Fim while
      System.out.println("");
    }//fim for*/

    return novoQuadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraContagemDeCaracteres
  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBytes (int quadro []) {

    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraInsercaoDeBytes
  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBits (int quadro []) {

    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraInsercaoDeBits
  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoViolacaoDaCamadaFisica (int quadro []) {

    return quadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraViolacaoDaCamadaFisica

  public void setReceptora(CamadaReceptora recepcao){
    camadareceptora = recepcao;
  }//Fim setEnlaceReceptora

  public void setControlador (Controlador controlador){
    control = controlador;
  }//fim metodo setControlador
}//fim classe CamadaEnlaceDadosTransmissora