package controlador;

import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Line;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.ScrollPane;
import camadas.*;
import ondas.*;

/*********************************************
Nome: Tharcio Thalles Almeida Silva
Data de inicio: 02 12 2018
data de termino: 15 12 2018
objetivo: simular a camada fisica de redes
********************************************/


/*********************************************************************
* Classe: Controlador
* Funcao: controla todas as funcoes da tela
******************************************************************* */
public class Controlador implements Initializable {

  CamadaTransmissora camadaTransmissora;
  CamadaReceptora camadaReceptora;
  Ondas ondasClasse;
  CamadaEnlaceDadosTransmissora enlaceTransmissora;
  CamadaEnlaceDadosReceptora enlaceReceptora;

  int x = 0;

  public int largura = 0;
  public int largura2 = 0;

  public int verificacao = 30;

  @FXML public TextField mensagem;
  @FXML public TextField mensagemDecodificada;
  @FXML public TextField mensagemRecebida;
  @FXML public TextField mensagemRecebidaTela;
  @FXML public AnchorPane anchor;
  @FXML public ScrollPane scroll;
  private String mensagemCopiada;

  public static int tipoDeDecodificacao = 0;

  @FXML private ImageView nivelBaixo;
  @FXML private ImageView nivelAlto;

	public Controlador(){
    camadaTransmissora = new CamadaTransmissora();
    camadaReceptora = new CamadaReceptora();
    enlaceTransmissora = new CamadaEnlaceDadosTransmissora();
    enlaceReceptora = new CamadaEnlaceDadosReceptora();
    ondasClasse = new Ondas();
    nivelBaixo = new ImageView();
    nivelAlto = new ImageView();
    scroll = new ScrollPane();
    anchor = new AnchorPane();
    //scroll.getChildren().add(anchor);
  }//Fim metodo construtor

  @FXML
  public void binaria(ActionEvent event){
    tipoDeDecodificacao = 0;
    mensagemCopiada = mensagem.getText();
    camadaTransmissora.CamadaDeAplicacaoTransmissora(mensagemCopiada);
  }//Fim metodo binaria

  @FXML
  public void manchester(ActionEvent event){
    tipoDeDecodificacao = 1;
    mensagemCopiada = mensagem.getText();
    camadaTransmissora.CamadaDeAplicacaoTransmissora(mensagemCopiada);
  }//Fim metodo manchester

  @FXML
  public void manchesterDif(ActionEvent event){
    tipoDeDecodificacao = 2;
    mensagemCopiada = mensagem.getText();
    camadaTransmissora.CamadaDeAplicacaoTransmissora(mensagemCopiada);
  }//Fim metodo manchesterDif

  public void meioDeComunicacao(int fluxoBrutoDeBits []){
    int[] fluxoBrutoDeBitsPontoA, fluxoBrutoDeBitsPontoB;

    fluxoBrutoDeBitsPontoA = fluxoBrutoDeBits;
    fluxoBrutoDeBitsPontoB = new int[fluxoBrutoDeBitsPontoA.length];
    int mask = 1;

    /*System.out.println("Dentro do meio de meioDeComunicacao: ");

    for(int j = 0; j < fluxoBrutoDeBits.length; j++){
      while(fluxoBrutoDeBits[j] > 0){
        if((fluxoBrutoDeBits[j] & mask) == 0){
          System.out.print("0");
          //cont += 1;
        }//Fim if
        else if((fluxoBrutoDeBits[j] & mask) == 1){
          System.out.print("1");
          //cont += 1;
        }//Fim else if
        
        //novofluxoBrutoDeBits[indiceNQ] = novofluxoBrutoDeBits[indiceNQ] << 1;
        fluxoBrutoDeBits[j] = fluxoBrutoDeBits[j] >> 1;
      }//Fim while
      System.out.println("");
      //System.out.println("cont : " + cont + " vezes");
    }//Fim for*/

    System.out.println("");

    for(int i = 0; i < fluxoBrutoDeBitsPontoA.length ; i++){
      fluxoBrutoDeBitsPontoB[i] = (fluxoBrutoDeBitsPontoB[i] << 32);
      fluxoBrutoDeBitsPontoB[i] = fluxoBrutoDeBitsPontoB[i] | fluxoBrutoDeBitsPontoA[i];
    }//Fim for
    camadaReceptora.camadaFisicaReceptora(fluxoBrutoDeBitsPontoB);
  }//Fim metodo meioDeComunicacao

  public void ondaBaixa(){
    if(largura2 > 0){
      Line line = new Line();
      line.setStartX(0.0f);
      line.setStartY(80.0f);
      line.setEndX(0.0f);        //alto
      line.setEndY(100.0f);
      line.setLayoutX(0);
      line.setLayoutY(510);

      Line line2 = new Line();
      line2.setStartX(80.0f);
      line2.setStartY(0.0f);
      line2.setEndX(100.0f);    //baixo
      line2.setEndY(0.0f);
      line2.setLayoutX(-79);
      line2.setLayoutY(610);

      x += 21;

      line.setLayoutX((line.getLayoutX()) + x);
      line2.setLayoutX((line.getLayoutX()) - 79);
      anchor.getChildren().add(line);
      anchor.getChildren().add(line2);
    }else if(largura2 == 0){
      Line line2 = new Line();
      line2.setStartX(80.0f);
      line2.setStartY(0.0f);
      line2.setEndX(100.0f);    //baixo
      line2.setEndY(0.0f);
      line2.setLayoutX(-79);
      line2.setLayoutY(610);

      x += 21;

      line2.setLayoutX((line2.getLayoutX()) + x);
      anchor.getChildren().add(line2);
    }//Fim else if

  }//Fim metodo ondaBaixa

  public void ondaAlta(){
    if(largura > 0){
      Line line = new Line();
      line.setStartX(0.0f);
      line.setStartY(80.0f);
      line.setEndX(0.0f);        //alto
      line.setEndY(100.0f);
      line.setLayoutX(0);
      line.setLayoutY(510);
      
      Line line2 = new Line();
      line2.setStartX(80.0f);
      line2.setStartY(0.0f);
      line2.setEndX(100.0f);    //1 continuo
      line2.setEndY(0.0f);
      line2.setLayoutX(-80);
      line2.setLayoutY(589);

      /*Line line3 = new Line();
      line3.setStartX(0.0f);
      line3.setStartY(80.0f);
      line3.setEndX(0.0f);     // alto
      line3.setEndY(100.0f);
      line3.setLayoutX(219);
      line3.setLayoutY(510);*/

      x += 21;

      line.setLayoutX((line.getLayoutX()) + x);
      line2.setLayoutX((line.getLayoutX()) - 80);
      //line3.setLayoutX((line.getLayoutX()) + 20);
      anchor.getChildren().add(line);
      anchor.getChildren().add(line2);
      //anchor.getChildren().add(line3);
    }else if(largura == 0){
      Line line2 = new Line();
      line2.setStartX(80.0f);
      line2.setStartY(0.0f);
      line2.setEndX(100.0f);    //1 continuo
      line2.setEndY(0.0f);
      line2.setLayoutX(-80);
      line2.setLayoutY(589);
      x += 21;
      line2.setLayoutX((line2.getLayoutX()) + x);

      anchor.getChildren().add(line2);
    }//Fim else if
  }//Fim metodo ondaAlta

  public void gerarOnda(String formaDeOnda){
    for(int i = 0; i < formaDeOnda.length(); i++){
      if(formaDeOnda.charAt(i) == '0'){
        largura += 1;
        ondaBaixa();
        largura2 = 0;
      }else if(formaDeOnda.charAt(i) == '1'){
        largura2 += 1;
        ondaAlta();
        largura = 0;
      }//Fim else if
    }//Fim for
  }//Fim metodo gerarOnda

  public void nivelBaixo(){
    Platform.runLater(() -> {
      nivelAlto.setVisible(false);
      nivelBaixo.setVisible(true);
    });//Fim Platform
    try{
      Thread.sleep(1000);
    }catch(InterruptedException e){
      e.printStackTrace();
    }//fim catch
  }//Fim metodo nivelBaixo

  public void nivelAlto(){
    Platform.runLater(() -> {
      nivelBaixo.setVisible(false);
      nivelAlto.setVisible(true);
    });//Fim Platform
    try{
      Thread.sleep(1000);
    }catch(InterruptedException e){
      e.printStackTrace();
    }//fim catch
  }//Fim metodo nivelBaixo

  public String retornaBinario(int inteiro){
    String stringb = "";
    while(inteiro >= 1){
      if(inteiro % 2 == 0){
        stringb += "0"; 
      }else{
        stringb += "1";
      }
      inteiro = inteiro / 2;      
    }//Fim while
    return stringb;
  }//Fim metodo retornaBinario

  @Override
  public void initialize(URL url, ResourceBundle rb) {
    camadaTransmissora.setControlador(this);
    camadaReceptora.setControlador(this);
    ondasClasse.setControlador(this);
    //enlaceTransmissora.setControlador(this);
    //enlaceReceptora.setControlador(this);
    ondasClasse.start();
  }//Fim metodo initialize

}//Fim classe controlador