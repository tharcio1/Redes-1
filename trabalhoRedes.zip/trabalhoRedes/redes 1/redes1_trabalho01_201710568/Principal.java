import controlador.Controlador;
import camadas.*;
import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/*********************************************
Nome: Tharcio Thalles Almeida Silva
Data de inicio: 02 12 2018
data de termino: 15 12 2018
objetivo: simular a camada fisica de redes
********************************************/

public class Principal extends Application{

	public static Scene aplicacao;

  @Override
  public void start(Stage primaryStage) throws IOException {
    Parent fxmlAplicacao = FXMLLoader.load(getClass().getResource("/tela/Aplicacao.fxml"));
    aplicacao = new Scene(fxmlAplicacao);
    primaryStage.setScene(aplicacao);
    primaryStage.show();
  }//Fim metodo start

  public static void main(String args[]){
    launch(args);
  }//Fim main

}//Fim classe Principal